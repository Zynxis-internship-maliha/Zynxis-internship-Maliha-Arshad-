import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Toaster, toast } from "sonner";
import {
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Check,
  ChevronRight,
  Circle,
  Command,
  CreditCard,
  Eye,
  EyeOff,
  Gauge,
  Github,
  Info,
  Layers,
  Lock,
  Mail,
  MoreHorizontal,
  Phone,
  Search,
  Settings,
  Sparkles,
  Star,
  Trash2,
  TrendingUp,
  User,
  Users,
  X,
  Zap,
} from "lucide-react";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  component: ComponentsShowcase,
});

/* ---------------- Zynxis primitives ---------------- */

type ZButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "success";
type ZButtonSize = "sm" | "md" | "lg";

interface ZButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ZButtonVariant;
  size?: ZButtonSize;
  loading?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  fullWidth?: boolean;
}

const variantClasses: Record<ZButtonVariant, string> = {
  primary:
    "bg-primary text-primary-foreground shadow-[0_1px_0_0_rgba(255,255,255,0.15)_inset,0_8px_24px_-8px_rgba(59,130,246,0.5)] hover:bg-[color:var(--primary-hover)]",
  secondary:
    "bg-card text-foreground border border-border hover:bg-secondary/80",
  outline:
    "bg-transparent text-foreground border border-border hover:border-primary/50 hover:bg-primary/5",
  ghost: "bg-transparent text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
  danger:
    "bg-destructive text-destructive-foreground shadow-[0_8px_24px_-8px_rgba(239,68,68,0.5)] hover:brightness-110",
  success:
    "bg-success text-success-foreground shadow-[0_8px_24px_-8px_rgba(34,197,94,0.5)] hover:brightness-110",
};

const sizeClasses: Record<ZButtonSize, string> = {
  sm: "h-8 px-3 text-xs rounded-lg gap-1.5",
  md: "h-10 px-4 text-sm rounded-xl gap-2",
  lg: "h-12 px-6 text-[15px] rounded-xl gap-2",
};

function ZButton({
  variant = "primary",
  size = "md",
  loading,
  disabled,
  iconLeft,
  iconRight,
  fullWidth,
  className,
  children,
  ...rest
}: ZButtonProps) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={cn(
        "relative inline-flex items-center justify-center font-medium transition-all duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        "disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]",
        variantClasses[variant],
        sizeClasses[size],
        fullWidth && "w-full",
        className,
      )}
    >
      {loading ? (
        <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
      ) : (
        iconLeft
      )}
      <span>{children}</span>
      {!loading && iconRight}
    </button>
  );
}

/* ---------------- Section shell ---------------- */

function Section({
  id,
  title,
  description,
  children,
}: {
  id: string;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h2>
          {description && (
            <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
          )}
        </div>
        <Badge variant="outline" className="hidden md:inline-flex border-border text-muted-foreground">
          <Sparkles className="mr-1 h-3 w-3" /> stable
        </Badge>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        {children}
      </motion.div>
    </section>
  );
}

function Panel({
  title,
  children,
  className,
}: {
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("glass-panel rounded-2xl p-6 shadow-elegant", className)}>
      {title && (
        <div className="mb-4 flex items-center justify-between">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{title}</p>
          <MoreHorizontal className="h-4 w-4 text-muted-foreground/60" />
        </div>
      )}
      {children}
    </div>
  );
}

/* ---------------- Page ---------------- */

const nav = [
  { id: "buttons", label: "Buttons" },
  { id: "cards", label: "Cards" },
  { id: "inputs", label: "Inputs & Forms" },
  { id: "badges", label: "Badges" },
  { id: "alerts", label: "Alerts" },
  { id: "modals", label: "Modals" },
  { id: "dropdowns", label: "Dropdowns" },
  { id: "avatars", label: "Avatars" },
  { id: "tabs", label: "Tabs" },
  { id: "tooltips", label: "Tooltips" },
  { id: "loaders", label: "Loaders" },
  { id: "progress", label: "Progress" },
  { id: "accordion", label: "Accordion" },
  { id: "breadcrumbs", label: "Breadcrumbs" },
  { id: "pagination", label: "Pagination" },
  { id: "table", label: "Data Table" },
  { id: "toasts", label: "Toasts" },
];

function ComponentsShowcase() {
  const [active, setActive] = useState<string>("buttons");
  const [pwVisible, setPwVisible] = useState(false);
  const [progress, setProgress] = useState(24);
  const [switchOn, setSwitchOn] = useState(true);
  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    const t = setInterval(
      () => setProgress((p) => (p >= 100 ? 24 : p + 6)),
      1200,
    );
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 },
    );
    nav.forEach((n) => {
      const el = document.getElementById(n.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  const tableRows = useMemo(
    () => [
      { id: "INV-2041", customer: "Acme, Inc.", status: "paid", amount: "$4,200.00", date: "Jul 12" },
      { id: "INV-2042", customer: "Globex", status: "pending", amount: "$1,120.00", date: "Jul 11" },
      { id: "INV-2043", customer: "Umbrella", status: "failed", amount: "$780.00", date: "Jul 10" },
      { id: "INV-2044", customer: "Initech", status: "paid", amount: "$9,410.00", date: "Jul 09" },
      { id: "INV-2045", customer: "Soylent", status: "paid", amount: "$540.00", date: "Jul 08" },
    ],
    [],
  );

  return (
    <TooltipProvider delayDuration={150}>
      <div className="min-h-screen bg-background text-foreground">
        <Toaster theme="dark" richColors position="top-right" />

        {/* Ambient background */}
        <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-primary/20 blur-[140px]" />
          <div className="absolute bottom-0 right-0 h-[400px] w-[600px] rounded-full bg-info/10 blur-[120px]" />
          <div className="absolute inset-0 grid-bg opacity-[0.15]" />
        </div>

        {/* Navbar */}
        <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
          <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-6">
            <div className="flex items-center gap-8">
              <a href="#top" className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-[color:var(--primary-hover)] shadow-glow">
                  <Layers className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-[15px] font-semibold tracking-tight">Zynxis</span>
                  <span className="hidden text-xs text-muted-foreground sm:inline">/ components</span>
                </div>
              </a>
              <nav className="hidden items-center gap-1 md:flex">
                {["Components", "Docs", "Templates", "Changelog"].map((item, i) => (
                  <a
                    key={item}
                    href="#"
                    className={cn(
                      "rounded-lg px-3 py-1.5 text-sm transition-colors",
                      i === 0
                        ? "bg-secondary/70 text-foreground"
                        : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {item}
                  </a>
                ))}
              </nav>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative hidden md:block">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  className="h-9 w-72 rounded-lg border border-border bg-card/60 pl-9 pr-16 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/25"
                  placeholder="Search components…"
                />
                <kbd className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1 rounded-md border border-border bg-secondary/60 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                  <Command className="h-3 w-3" />K
                </kbd>
              </div>
              <ZButton variant="ghost" size="sm" iconLeft={<Bell className="h-4 w-4" />}>
                <span className="sr-only">Notifications</span>
              </ZButton>
              <ZButton variant="secondary" size="sm" iconLeft={<Github className="h-4 w-4" />}>
                Star
              </ZButton>
              <Avatar className="h-8 w-8 border border-border">
                <AvatarImage src="https://i.pravatar.cc/64?img=68" alt="Alex Rivera" />
                <AvatarFallback>AR</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Hero */}
        <div id="top" className="mx-auto max-w-[1400px] px-6 pt-16 pb-10">
          <div className="max-w-3xl">
            <Badge variant="outline" className="border-border/80 bg-card/60 text-muted-foreground">
              <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-success shadow-[0_0_8px_var(--color-success)]" />
              v1.0 · Enterprise-ready
            </Badge>
            <h1 className="mt-5 text-5xl font-bold leading-[1.05] tracking-tight md:text-6xl">
              <span className="text-gradient">The Zynxis</span>
              <br />
              Component Library.
            </h1>
            <p className="mt-5 max-w-2xl text-[17px] leading-relaxed text-muted-foreground">
              A premium, accessible, and beautifully composed design system for building modern SaaS
              interfaces. Crafted with React, TypeScript, Tailwind, and Framer Motion — inspired by
              the products you already love.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <ZButton size="lg" iconRight={<ArrowRight className="h-4 w-4" />}>
                Browse components
              </ZButton>
              <ZButton size="lg" variant="secondary" iconLeft={<Github className="h-4 w-4" />}>
                View on GitHub
              </ZButton>
              <div className="ml-2 hidden items-center gap-3 text-sm text-muted-foreground sm:flex">
                <div className="flex -space-x-2">
                  {[65, 47, 12, 32].map((i) => (
                    <Avatar key={i} className="h-7 w-7 border-2 border-background">
                      <AvatarImage src={`https://i.pravatar.cc/56?img=${i}`} />
                      <AvatarFallback>U</AvatarFallback>
                    </Avatar>
                  ))}
                </div>
                <span>Trusted by 12k+ engineers</span>
              </div>
            </div>
          </div>
        </div>

        {/* Body: sidebar + content */}
        <div className="mx-auto grid max-w-[1400px] grid-cols-1 gap-10 px-6 pb-24 lg:grid-cols-[240px_1fr]">
          {/* Sidebar */}
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <p className="mb-3 px-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Components
              </p>
              <nav className="flex flex-col gap-0.5">
                {nav.map((n) => {
                  const isActive = active === n.id;
                  return (
                    <a
                      key={n.id}
                      href={`#${n.id}`}
                      className={cn(
                        "group relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors",
                        isActive
                          ? "bg-primary/10 text-foreground"
                          : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground",
                      )}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="sidebar-active"
                          className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r bg-primary"
                          transition={{ type: "spring", stiffness: 400, damping: 30 }}
                        />
                      )}
                      <ChevronRight
                        className={cn(
                          "h-3.5 w-3.5 transition-transform",
                          isActive ? "text-primary" : "text-muted-foreground/50",
                        )}
                      />
                      {n.label}
                    </a>
                  );
                })}
              </nav>

              <div className="mt-8 rounded-2xl border border-border bg-card/60 p-5">
                <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <Zap className="h-4 w-4 text-primary" /> Pro tips
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Every component is fully typed, tree-shakable, and built on top of accessible
                  primitives. Copy, compose, ship.
                </p>
              </div>
            </div>
          </aside>

          {/* Content */}
          <main className="min-w-0 space-y-20">
            {/* BUTTONS */}
            <Section id="buttons" title="Buttons" description="Six variants · three sizes · loading, icons, and full-width states.">
              <Panel>
                <div className="space-y-8">
                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Variants</p>
                    <div className="flex flex-wrap gap-3">
                      <ZButton variant="primary">Primary</ZButton>
                      <ZButton variant="secondary">Secondary</ZButton>
                      <ZButton variant="outline">Outline</ZButton>
                      <ZButton variant="ghost">Ghost</ZButton>
                      <ZButton variant="danger">Danger</ZButton>
                      <ZButton variant="success">Success</ZButton>
                    </div>
                  </div>
                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Sizes</p>
                    <div className="flex flex-wrap items-center gap-3">
                      <ZButton size="sm">Small</ZButton>
                      <ZButton size="md">Medium</ZButton>
                      <ZButton size="lg">Large</ZButton>
                    </div>
                  </div>
                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      With icons, loading & disabled
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <ZButton iconLeft={<Sparkles className="h-4 w-4" />}>Generate</ZButton>
                      <ZButton variant="secondary" iconRight={<ArrowUpRight className="h-4 w-4" />}>
                        Open dashboard
                      </ZButton>
                      <ZButton loading>Saving…</ZButton>
                      <ZButton disabled>Disabled</ZButton>
                      <ZButton variant="danger" iconLeft={<Trash2 className="h-4 w-4" />}>Delete</ZButton>
                    </div>
                  </div>
                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Full width</p>
                    <ZButton fullWidth iconRight={<ArrowRight className="h-4 w-4" />}>Continue to billing</ZButton>
                  </div>
                </div>
              </Panel>
            </Section>

            {/* CARDS */}
            <Section id="cards" title="Cards" description="Composable surfaces for analytics, pricing, teams, and features.">
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {/* Analytics */}
                <Card className="border-border/80 bg-card/70 backdrop-blur">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0">
                    <div>
                      <CardDescription>Monthly revenue</CardDescription>
                      <CardTitle className="mt-1 text-3xl">$128,430</CardTitle>
                    </div>
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
                      <TrendingUp className="h-5 w-5" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm">
                      <Badge className="bg-success/15 text-success hover:bg-success/20">+12.4%</Badge>
                      <span className="text-muted-foreground">vs last month</span>
                    </div>
                    <div className="mt-4 flex h-16 items-end gap-1">
                      {[30, 45, 38, 60, 52, 78, 66, 90, 72, 84, 96, 88].map((h, i) => (
                        <div
                          key={i}
                          className="flex-1 rounded-sm bg-gradient-to-t from-primary/40 to-primary"
                          style={{ height: `${h}%` }}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Profile */}
                <Card className="border-border/80 bg-card/70 backdrop-blur">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <Avatar className="h-14 w-14 border border-border">
                        <AvatarImage src="https://i.pravatar.cc/128?img=32" />
                        <AvatarFallback>MK</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle>Mira Kapoor</CardTitle>
                        <CardDescription>Staff Product Designer · Zynxis</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 divide-x divide-border rounded-xl border border-border bg-surface/60 py-3 text-center">
                      {[
                        ["142", "Projects"],
                        ["8.9k", "Followers"],
                        ["4.9", "Rating"],
                      ].map(([v, l]) => (
                        <div key={l}>
                          <div className="text-lg font-semibold">{v}</div>
                          <div className="text-xs text-muted-foreground">{l}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="gap-2">
                    <ZButton fullWidth>Follow</ZButton>
                    <ZButton variant="secondary" fullWidth>Message</ZButton>
                  </CardFooter>
                </Card>

                {/* Feature */}
                <Card className="relative overflow-hidden border-border/80 bg-gradient-to-br from-card to-surface">
                  <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary/20 blur-3xl" />
                  <CardHeader>
                    <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-surface/80">
                      <Gauge className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Blazing performance</CardTitle>
                    <CardDescription>
                      Ship interfaces that feel instant, everywhere. Tree-shakable primitives with
                      zero runtime cost.
                    </CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <a href="#" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline">
                      Read the benchmarks <ArrowRight className="h-3.5 w-3.5" />
                    </a>
                  </CardFooter>
                </Card>

                {/* Pricing */}
                <Card className="border-primary/40 bg-gradient-to-b from-primary/10 to-card/70 md:col-span-1">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Team</CardTitle>
                      <Badge className="bg-primary/20 text-primary hover:bg-primary/25">Popular</Badge>
                    </div>
                    <div className="flex items-baseline gap-1 pt-2">
                      <span className="text-4xl font-bold">$29</span>
                      <span className="text-muted-foreground">/ user / mo</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    {["Unlimited components", "Priority support", "SSO & audit logs", "Advanced theming"].map((f) => (
                      <div key={f} className="flex items-center gap-2 text-foreground/90">
                        <Check className="h-4 w-4 text-success" /> {f}
                      </div>
                    ))}
                  </CardContent>
                  <CardFooter>
                    <ZButton fullWidth iconRight={<ArrowRight className="h-4 w-4" />}>Start free trial</ZButton>
                  </CardFooter>
                </Card>

                {/* Stat */}
                <Card className="border-border/80 bg-card/70">
                  <CardHeader className="pb-2">
                    <CardDescription>Active users</CardDescription>
                    <CardTitle className="text-3xl">18,204</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Progress value={68} className="h-2" />
                    <p className="mt-2 text-xs text-muted-foreground">68% of monthly target</p>
                  </CardContent>
                </Card>

                {/* Team member card */}
                <Card className="border-border/80 bg-card/70">
                  <CardHeader className="pb-3">
                    <CardDescription>Team</CardDescription>
                    <CardTitle className="flex items-center gap-2">
                      Platform Engineering <Users className="h-4 w-4 text-muted-foreground" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { name: "Diego Alvarez", role: "Engineering Lead", img: 12 },
                      { name: "Sana Ito", role: "Senior Engineer", img: 47 },
                      { name: "Wren Osei", role: "Design Engineer", img: 65 },
                    ].map((m) => (
                      <div key={m.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9 border border-border">
                            <AvatarImage src={`https://i.pravatar.cc/64?img=${m.img}`} />
                            <AvatarFallback>{m.name[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm font-medium">{m.name}</div>
                            <div className="text-xs text-muted-foreground">{m.role}</div>
                          </div>
                        </div>
                        <ZButton variant="ghost" size="sm">View</ZButton>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </Section>

            {/* INPUTS */}
            <Section id="inputs" title="Inputs & Forms" description="Text, password, search, textarea, checkbox, radio, and switch primitives.">
              <Panel>
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="email">Work email</Label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input id="email" placeholder="you@company.com" className="h-11 rounded-xl pl-9" />
                    </div>
                    <p className="text-xs text-success flex items-center gap-1"><Check className="h-3 w-3" /> Looks good</p>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="pw">Password</Label>
                    <div className="relative">
                      <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="pw"
                        type={pwVisible ? "text" : "password"}
                        placeholder="Enter a strong password"
                        className="h-11 rounded-xl pl-9 pr-10"
                        defaultValue="s3cret-passphrase"
                      />
                      <button
                        type="button"
                        onClick={() => setPwVisible((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        aria-label={pwVisible ? "Hide password" : "Show password"}
                      >
                        {pwVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="phone">Phone</Label>
                    <div className="relative">
                      <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input id="phone" placeholder="+1 (555) 000-0000" className="h-11 rounded-xl pl-9" />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="search">Search</Label>
                    <div className="relative">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input id="search" placeholder="Search customers, invoices…" className="h-11 rounded-xl pl-9" />
                    </div>
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <Label htmlFor="msg">Message</Label>
                    <Textarea id="msg" rows={4} placeholder="Tell us what you're building…" className="rounded-xl" />
                  </div>

                  <div className="space-y-1.5">
                    <Label>Error state</Label>
                    <Input
                      placeholder="username"
                      defaultValue="!!not-valid"
                      className="h-11 rounded-xl border-destructive/70 focus-visible:ring-destructive/40"
                    />
                    <p className="flex items-center gap-1 text-xs text-destructive">
                      <AlertTriangle className="h-3 w-3" /> Only letters, numbers and underscores.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <Label>Disabled</Label>
                    <Input disabled placeholder="Locked field" className="h-11 rounded-xl" />
                  </div>
                </div>

                <div className="mt-8 grid gap-6 md:grid-cols-3">
                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Checkbox</p>
                    <div className="space-y-3">
                      <label className="flex items-center gap-3 text-sm">
                        <Checkbox defaultChecked /> Enable two-factor auth
                      </label>
                      <label className="flex items-center gap-3 text-sm">
                        <Checkbox /> Subscribe to product updates
                      </label>
                    </div>
                  </div>

                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Radio</p>
                    <RadioGroup defaultValue="pro" className="space-y-3">
                      <label className="flex items-center gap-3 text-sm">
                        <RadioGroupItem value="free" /> Free
                      </label>
                      <label className="flex items-center gap-3 text-sm">
                        <RadioGroupItem value="pro" /> Pro
                      </label>
                      <label className="flex items-center gap-3 text-sm">
                        <RadioGroupItem value="team" /> Team
                      </label>
                    </RadioGroup>
                  </div>

                  <div>
                    <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Switch</p>
                    <div className="space-y-3">
                      <label className="flex items-center justify-between gap-3 text-sm">
                        Marketing emails <Switch checked={switchOn} onCheckedChange={setSwitchOn} />
                      </label>
                      <label className="flex items-center justify-between gap-3 text-sm">
                        Beta features <Switch />
                      </label>
                      <label className="flex items-center justify-between gap-3 text-sm text-muted-foreground">
                        Disabled <Switch disabled />
                      </label>
                    </div>
                  </div>
                </div>
              </Panel>
            </Section>

            {/* BADGES */}
            <Section id="badges" title="Badges" description="Status pills across every semantic tone.">
              <Panel>
                <div className="flex flex-wrap gap-2.5">
                  <Badge className="bg-primary/15 text-primary hover:bg-primary/20">Primary</Badge>
                  <Badge className="bg-secondary text-foreground hover:bg-secondary/80">Secondary</Badge>
                  <Badge className="bg-destructive/15 text-destructive hover:bg-destructive/20">Danger</Badge>
                  <Badge className="bg-warning/15 text-warning hover:bg-warning/20">Warning</Badge>
                  <Badge className="bg-success/15 text-success hover:bg-success/20">Success</Badge>
                  <Badge className="bg-info/15 text-info hover:bg-info/20">Info</Badge>
                  <Badge variant="outline" className="border-border text-muted-foreground">Outline</Badge>
                  <Badge className="bg-primary text-primary-foreground">
                    <Star className="mr-1 h-3 w-3" /> Featured
                  </Badge>
                </div>
              </Panel>
            </Section>

            {/* ALERTS */}
            <Section id="alerts" title="Alerts" description="Semantic messaging with optional dismiss.">
              <div className="grid gap-4">
                {[
                  { tone: "success", icon: Check, title: "Deployment successful", body: "Your latest build is live in production.", color: "success" },
                  { tone: "danger", icon: AlertTriangle, title: "Payment failed", body: "We couldn't process your card ending in 4242.", color: "destructive" },
                  { tone: "warning", icon: AlertTriangle, title: "Approaching quota", body: "You've used 82% of your monthly API requests.", color: "warning" },
                  { tone: "info", icon: Info, title: "New release available", body: "Zynxis v1.4 introduces async command palette actions.", color: "info" },
                ].map((a) => (
                  <Alert
                    key={a.tone}
                    className={cn(
                      "flex items-start gap-3 border-l-4 bg-card/60 backdrop-blur",
                      a.color === "success" && "border-l-success",
                      a.color === "destructive" && "border-l-destructive",
                      a.color === "warning" && "border-l-warning",
                      a.color === "info" && "border-l-info",
                    )}
                  >
                    <a.icon
                      className={cn(
                        "mt-0.5 h-5 w-5",
                        a.color === "success" && "text-success",
                        a.color === "destructive" && "text-destructive",
                        a.color === "warning" && "text-warning",
                        a.color === "info" && "text-info",
                      )}
                    />
                    <div className="flex-1">
                      <AlertTitle>{a.title}</AlertTitle>
                      <AlertDescription>{a.body}</AlertDescription>
                    </div>
                    <button className="rounded-md p-1 text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label="Dismiss">
                      <X className="h-4 w-4" />
                    </button>
                  </Alert>
                ))}
              </div>
            </Section>

            {/* MODALS */}
            <Section id="modals" title="Modals" description="Confirm, delete, and celebratory dialogs — backdrop, ESC, and focus trap included.">
              <Panel>
                <div className="flex flex-wrap gap-3">
                  <Dialog>
                    <DialogTrigger asChild>
                      <ZButton variant="secondary">Open confirm</ZButton>
                    </DialogTrigger>
                    <DialogContent className="border-border bg-card/95 backdrop-blur-xl sm:rounded-2xl">
                      <DialogHeader>
                        <DialogTitle>Publish workspace</DialogTitle>
                        <DialogDescription>
                          This will make your workspace visible to invited teammates. You can revert this at any time.
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <ZButton variant="ghost">Cancel</ZButton>
                        <ZButton>Publish</ZButton>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Dialog>
                    <DialogTrigger asChild>
                      <ZButton variant="danger" iconLeft={<Trash2 className="h-4 w-4" />}>Delete workspace</ZButton>
                    </DialogTrigger>
                    <DialogContent className="border-border bg-card/95 backdrop-blur-xl sm:rounded-2xl">
                      <DialogHeader>
                        <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-xl bg-destructive/15 text-destructive">
                          <AlertTriangle className="h-5 w-5" />
                        </div>
                        <DialogTitle>Delete this workspace?</DialogTitle>
                        <DialogDescription>
                          This action is permanent. All projects, files, and members will be removed.
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <ZButton variant="ghost">Cancel</ZButton>
                        <ZButton variant="danger">Yes, delete</ZButton>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={openModal} onOpenChange={setOpenModal}>
                    <DialogTrigger asChild>
                      <ZButton variant="success" iconLeft={<Check className="h-4 w-4" />}>Success dialog</ZButton>
                    </DialogTrigger>
                    <DialogContent className="border-border bg-card/95 backdrop-blur-xl sm:rounded-2xl">
                      <DialogHeader>
                        <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-xl bg-success/15 text-success">
                          <Check className="h-5 w-5" />
                        </div>
                        <DialogTitle>You're all set</DialogTitle>
                        <DialogDescription>
                          Your account has been upgraded to the Team plan. Enjoy the new features.
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <ZButton onClick={() => setOpenModal(false)} fullWidth>Continue</ZButton>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </Panel>
            </Section>

            {/* DROPDOWNS */}
            <Section id="dropdowns" title="Dropdowns" description="Menus with keyboard navigation and gorgeous transitions.">
              <Panel>
                <div className="flex flex-wrap gap-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <ZButton variant="secondary" iconRight={<ChevronRight className="h-4 w-4 rotate-90" />}>Options</ZButton>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="min-w-52 border-border bg-card/95 backdrop-blur-xl">
                      <DropdownMenuLabel>My account</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem><User className="mr-2 h-4 w-4" />Profile</DropdownMenuItem>
                      <DropdownMenuItem><CreditCard className="mr-2 h-4 w-4" />Billing</DropdownMenuItem>
                      <DropdownMenuItem><Settings className="mr-2 h-4 w-4" />Settings</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive focus:text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />Delete account
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </Panel>
            </Section>

            {/* AVATARS */}
            <Section id="avatars" title="Avatars" description="Sizes, initials, and presence indicators.">
              <Panel>
                <div className="flex flex-wrap items-end gap-8">
                  {[
                    { size: "h-8 w-8", label: "sm" },
                    { size: "h-10 w-10", label: "md" },
                    { size: "h-14 w-14", label: "lg" },
                    { size: "h-20 w-20", label: "xl" },
                  ].map((s) => (
                    <div key={s.label} className="flex flex-col items-center gap-2">
                      <Avatar className={cn(s.size, "border border-border")}>
                        <AvatarImage src="https://i.pravatar.cc/128?img=15" />
                        <AvatarFallback>ZX</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{s.label}</span>
                    </div>
                  ))}

                  {[
                    { color: "bg-success", label: "online" },
                    { color: "bg-muted-foreground", label: "offline" },
                    { color: "bg-warning", label: "busy" },
                  ].map((p) => (
                    <div key={p.label} className="flex flex-col items-center gap-2">
                      <div className="relative">
                        <Avatar className="h-14 w-14 border border-border">
                          <AvatarFallback>{p.label[0].toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <span className={cn("absolute bottom-0.5 right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card", p.color)} />
                      </div>
                      <span className="text-xs text-muted-foreground">{p.label}</span>
                    </div>
                  ))}

                  <div className="flex -space-x-3">
                    {[12, 32, 47, 65].map((i) => (
                      <Avatar key={i} className="h-10 w-10 border-2 border-background">
                        <AvatarImage src={`https://i.pravatar.cc/64?img=${i}`} />
                        <AvatarFallback>U</AvatarFallback>
                      </Avatar>
                    ))}
                    <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-background bg-secondary text-xs font-medium">
                      +12
                    </div>
                  </div>
                </div>
              </Panel>
            </Section>

            {/* TABS */}
            <Section id="tabs" title="Tabs" description="Animated indicator with smooth transitions between panels.">
              <Panel>
                <Tabs defaultValue="overview">
                  <TabsList className="bg-secondary/60">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="activity">Activity</TabsTrigger>
                    <TabsTrigger value="billing">Billing</TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                  </TabsList>
                  <TabsContent value="overview" className="mt-5 rounded-xl border border-border bg-surface/60 p-6">
                    <p className="text-sm text-muted-foreground">A high-level view of your workspace performance and key metrics.</p>
                  </TabsContent>
                  <TabsContent value="activity" className="mt-5 rounded-xl border border-border bg-surface/60 p-6">
                    <p className="text-sm text-muted-foreground">Recent activity from your team, live.</p>
                  </TabsContent>
                  <TabsContent value="billing" className="mt-5 rounded-xl border border-border bg-surface/60 p-6">
                    <p className="text-sm text-muted-foreground">Manage invoices, payment methods, and tax settings.</p>
                  </TabsContent>
                  <TabsContent value="settings" className="mt-5 rounded-xl border border-border bg-surface/60 p-6">
                    <p className="text-sm text-muted-foreground">Configure workspace preferences and integrations.</p>
                  </TabsContent>
                </Tabs>
              </Panel>
            </Section>

            {/* TOOLTIPS */}
            <Section id="tooltips" title="Tooltips" description="Placement in all four directions.">
              <Panel>
                <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                  {(["top", "right", "bottom", "left"] as const).map((side) => (
                    <Tooltip key={side}>
                      <TooltipTrigger asChild>
                        <ZButton variant="secondary" fullWidth>{side}</ZButton>
                      </TooltipTrigger>
                      <TooltipContent side={side} className="border-border bg-card">
                        Tooltip on {side}
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              </Panel>
            </Section>

            {/* LOADERS */}
            <Section id="loaders" title="Loaders" description="Spinners, dots, and skeleton screens.">
              <div className="grid gap-5 md:grid-cols-3">
                <Panel title="Spinner">
                  <div className="flex items-center justify-center py-6">
                    <div className="h-10 w-10 animate-spin rounded-full border-[3px] border-primary/25 border-t-primary" />
                  </div>
                </Panel>
                <Panel title="Dots">
                  <div className="flex items-center justify-center gap-2 py-6">
                    {[0, 0.15, 0.3].map((d) => (
                      <span
                        key={d}
                        className="h-3 w-3 rounded-full bg-primary"
                        style={{ animation: `pulse 1s ease-in-out ${d}s infinite` }}
                      />
                    ))}
                  </div>
                </Panel>
                <Panel title="Skeleton">
                  <div className="space-y-3">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-24 w-full" />
                  </div>
                </Panel>
              </div>
            </Section>

            {/* PROGRESS */}
            <Section id="progress" title="Progress" description="Bars for background jobs and quotas.">
              <Panel>
                <div className="space-y-6">
                  <div>
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Uploading assets…</span>
                      <span className="font-medium">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                  <div>
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Storage</span>
                      <span className="font-medium">7.2 / 10 GB</span>
                    </div>
                    <Progress value={72} className="h-2" />
                  </div>
                  <div>
                    <div className="mb-2 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Rate limit</span>
                      <span className="font-medium text-warning">92%</span>
                    </div>
                    <Progress value={92} className="h-2 [&>div]:bg-warning" />
                  </div>
                </div>
              </Panel>
            </Section>

            {/* ACCORDION */}
            <Section id="accordion" title="Accordion" description="Progressive disclosure for FAQs and settings.">
              <Panel>
                <Accordion type="single" collapsible defaultValue="a">
                  {[
                    { id: "a", q: "Is Zynxis production-ready?", a: "Yes. Every component is battle-tested, fully typed, and used across enterprise deployments." },
                    { id: "b", q: "Can I customize the theme?", a: "Absolutely. All colors, radii, and typography are exposed as CSS variables in a single design token file." },
                    { id: "c", q: "Do you support SSR frameworks?", a: "Zynxis works with Next.js, Remix, TanStack Start, and any modern React SSR framework." },
                  ].map((f) => (
                    <AccordionItem key={f.id} value={f.id} className="border-border">
                      <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </Panel>
            </Section>

            {/* BREADCRUMBS */}
            <Section id="breadcrumbs" title="Breadcrumbs" description="Contextual navigation for deep hierarchies.">
              <Panel>
                <Breadcrumb>
                  <BreadcrumbList>
                    <BreadcrumbItem><BreadcrumbLink href="#">Workspace</BreadcrumbLink></BreadcrumbItem>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem><BreadcrumbLink href="#">Projects</BreadcrumbLink></BreadcrumbItem>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem><BreadcrumbLink href="#">Zynxis Web</BreadcrumbLink></BreadcrumbItem>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem><BreadcrumbPage>Settings</BreadcrumbPage></BreadcrumbItem>
                  </BreadcrumbList>
                </Breadcrumb>
              </Panel>
            </Section>

            {/* PAGINATION */}
            <Section id="pagination" title="Pagination" description="Simple, accessible page navigation.">
              <Panel>
                <Pagination>
                  <PaginationContent>
                    <PaginationItem><PaginationPrevious href="#" /></PaginationItem>
                    <PaginationItem><PaginationLink href="#">1</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationLink href="#" isActive>2</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationLink href="#">3</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationEllipsis /></PaginationItem>
                    <PaginationItem><PaginationLink href="#">12</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationNext href="#" /></PaginationItem>
                  </PaginationContent>
                </Pagination>
              </Panel>
            </Section>

            {/* TABLE */}
            <Section id="table" title="Data Table" description="Search, status badges, actions — the essentials.">
              <Panel>
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="relative w-full max-w-xs">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input placeholder="Search invoices…" className="h-9 rounded-lg pl-9" />
                  </div>
                  <div className="flex items-center gap-2">
                    <ZButton variant="ghost" size="sm">Filter</ZButton>
                    <ZButton size="sm" iconLeft={<Sparkles className="h-4 w-4" />}>New invoice</ZButton>
                  </div>
                </div>

                <div className="overflow-hidden rounded-xl border border-border">
                  <Table>
                    <TableHeader className="bg-surface/70">
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead>Invoice</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead className="w-10" />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tableRows.map((r) => (
                        <TableRow key={r.id} className="border-border">
                          <TableCell className="font-medium">{r.id}</TableCell>
                          <TableCell>{r.customer}</TableCell>
                          <TableCell>
                            {r.status === "paid" && <Badge className="bg-success/15 text-success hover:bg-success/20"><Circle className="mr-1 h-2 w-2 fill-current" /> Paid</Badge>}
                            {r.status === "pending" && <Badge className="bg-warning/15 text-warning hover:bg-warning/20"><Circle className="mr-1 h-2 w-2 fill-current" /> Pending</Badge>}
                            {r.status === "failed" && <Badge className="bg-destructive/15 text-destructive hover:bg-destructive/20"><Circle className="mr-1 h-2 w-2 fill-current" /> Failed</Badge>}
                          </TableCell>
                          <TableCell className="text-muted-foreground">{r.date}</TableCell>
                          <TableCell className="text-right font-medium">{r.amount}</TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="rounded-md p-1 text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label="Row actions">
                                  <MoreHorizontal className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="border-border bg-card/95 backdrop-blur-xl">
                                <DropdownMenuItem>View</DropdownMenuItem>
                                <DropdownMenuItem>Duplicate</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive focus:text-destructive">Delete</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Panel>
            </Section>

            {/* TOASTS */}
            <Section id="toasts" title="Toast Notifications" description="Non-blocking messages for background events.">
              <Panel>
                <div className="flex flex-wrap gap-3">
                  <ZButton variant="success" onClick={() => toast.success("Changes saved", { description: "Your workspace is up to date." })}>
                    Success toast
                  </ZButton>
                  <ZButton variant="danger" onClick={() => toast.error("Something went wrong", { description: "Please try again in a moment." })}>
                    Error toast
                  </ZButton>
                  <ZButton onClick={() => toast("New message", { description: "Mira sent you a design review." })}>
                    Info toast
                  </ZButton>
                  <ZButton variant="secondary" onClick={() => toast.warning("Storage almost full", { description: "You've used 92% of your quota." })}>
                    Warning toast
                  </ZButton>
                </div>
              </Panel>
            </Section>

            <footer className="border-t border-border pt-8 text-sm text-muted-foreground">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Layers className="h-4 w-4 text-primary" />
                  <span>Zynxis Design System · v1.0</span>
                </div>
                <div className="flex gap-5">
                  <a href="#" className="hover:text-foreground">Documentation</a>
                  <a href="#" className="hover:text-foreground">Changelog</a>
                  <a href="#" className="hover:text-foreground">Support</a>
                </div>
              </div>
            </footer>
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}
