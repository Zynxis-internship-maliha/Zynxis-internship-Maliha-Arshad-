import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

export type ThemeMode = "light" | "dark";

export interface ThemeState {
  mode: ThemeMode;
}

export const initialThemeState: ThemeState = { mode: "light" };

const themeSlice = createSlice({
  name: "theme",
  initialState: initialThemeState,
  reducers: {
    hydrateTheme(_state, action: PayloadAction<ThemeState>) {
      return action.payload;
    },
    toggleTheme(state) {
      state.mode = state.mode === "light" ? "dark" : "light";
    },
    setTheme(state, action: PayloadAction<ThemeMode>) {
      state.mode = action.payload;
    },
  },
});

export const { hydrateTheme, toggleTheme, setTheme } = themeSlice.actions;
export default themeSlice.reducer;
