import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { Product } from "@/services/products";

export interface CartItem {
  id: string;
  name: string;
  brand: string;
  price: number;
  image: string;
  quantity: number;
  stock: number;
}

export interface CartState {
  items: CartItem[];
  /** Percentage discount (0-100) applied by a coupon */
  discount: number;
  coupon: string | null;
  shippingCost: number;
}

export const initialCartState: CartState = {
  items: [],
  discount: 0,
  coupon: null,
  shippingCost: 12,
};

/** Coupons available in the demo. */
export const COUPONS: Record<string, number> = {
  SMART10: 10,
  REDUX20: 20,
  WEEK6: 15,
};

const cartSlice = createSlice({
  name: "cart",
  initialState: initialCartState,
  reducers: {
    hydrateCart(_state, action: PayloadAction<CartState>) {
      return action.payload;
    },
    addProduct: {
      reducer(state, action: PayloadAction<{ product: Product; quantity: number }>) {
        const { product, quantity } = action.payload;
        const existing = state.items.find((i) => i.id === product.id);
        if (existing) {
          existing.quantity = Math.min(existing.quantity + quantity, product.stock);
        } else {
          state.items.push({
            id: product.id,
            name: product.name,
            brand: product.brand,
            price: product.price,
            image: product.image,
            quantity: Math.min(quantity, product.stock),
            stock: product.stock,
          });
        }
      },
      prepare(product: Product, quantity = 1) {
        return { payload: { product, quantity } };
      },
    },
    removeProduct(state, action: PayloadAction<string>) {
      state.items = state.items.filter((i) => i.id !== action.payload);
      if (state.items.length === 0) {
        state.discount = 0;
        state.coupon = null;
      }
    },
    increaseQuantity(state, action: PayloadAction<string>) {
      const item = state.items.find((i) => i.id === action.payload);
      if (item) item.quantity = Math.min(item.quantity + 1, item.stock);
    },
    decreaseQuantity(state, action: PayloadAction<string>) {
      const item = state.items.find((i) => i.id === action.payload);
      if (!item) return;
      item.quantity -= 1;
      if (item.quantity <= 0) {
        state.items = state.items.filter((i) => i.id !== action.payload);
      }
    },
    setQuantity(state, action: PayloadAction<{ id: string; quantity: number }>) {
      const item = state.items.find((i) => i.id === action.payload.id);
      if (item) item.quantity = Math.max(1, Math.min(action.payload.quantity, item.stock));
    },
    applyCoupon(state, action: PayloadAction<string>) {
      const code = action.payload.trim().toUpperCase();
      if (COUPONS[code]) {
        state.coupon = code;
        state.discount = COUPONS[code];
      }
    },
    removeCoupon(state) {
      state.coupon = null;
      state.discount = 0;
    },
    setShipping(state, action: PayloadAction<number>) {
      state.shippingCost = action.payload;
    },
    clearCart() {
      return initialCartState;
    },
  },
});

export const {
  hydrateCart,
  addProduct,
  removeProduct,
  increaseQuantity,
  decreaseQuantity,
  setQuantity,
  applyCoupon,
  removeCoupon,
  setShipping,
  clearCart,
} = cartSlice.actions;

export default cartSlice.reducer;
