import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { Currency } from "@/services/products";

export type Language = "en" | "es" | "fr" | "de" | "hi";

export interface PreferencesState {
  language: Language;
  currency: Currency;
  notifications: {
    orderUpdates: boolean;
    promotions: boolean;
    priceDrops: boolean;
  };
}

export const initialPreferencesState: PreferencesState = {
  language: "en",
  currency: "USD",
  notifications: {
    orderUpdates: true,
    promotions: false,
    priceDrops: true,
  },
};

const preferencesSlice = createSlice({
  name: "preferences",
  initialState: initialPreferencesState,
  reducers: {
    hydratePreferences(_state, action: PayloadAction<PreferencesState>) {
      return action.payload;
    },
    updateSettings(state, action: PayloadAction<Partial<PreferencesState>>) {
      Object.assign(state, action.payload);
    },
    toggleNotification(state, action: PayloadAction<keyof PreferencesState["notifications"]>) {
      state.notifications[action.payload] = !state.notifications[action.payload];
    },
    resetSettings() {
      return initialPreferencesState;
    },
  },
});

export const { hydratePreferences, updateSettings, toggleNotification, resetSettings } =
  preferencesSlice.actions;

export default preferencesSlice.reducer;
