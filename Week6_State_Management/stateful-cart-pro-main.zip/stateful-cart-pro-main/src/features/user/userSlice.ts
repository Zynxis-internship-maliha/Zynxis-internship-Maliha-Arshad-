import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

export interface UserProfile {
  username: string;
  email: string;
  avatar: string;
}

export interface UserState extends UserProfile {
  isLoggedIn: boolean;
}

export const initialUserState: UserState = {
  username: "",
  email: "",
  avatar: "",
  isLoggedIn: false,
};

/** Deterministic avatar so the demo never ships a broken image. */
const avatarFor = (seed: string) =>
  `https://api.dicebear.com/9.x/notionists/svg?seed=${encodeURIComponent(seed)}&backgroundColor=f2d7b6`;

const userSlice = createSlice({
  name: "user",
  initialState: initialUserState,
  reducers: {
    hydrateUser(_state, action: PayloadAction<UserState>) {
      return action.payload;
    },
    login(state, action: PayloadAction<{ email: string; username?: string }>) {
      const { email } = action.payload;
      state.email = email;
      state.username = action.payload.username || email.split("@")[0] || "shopper";
      state.avatar = avatarFor(state.username);
      state.isLoggedIn = true;
    },
    logout() {
      return initialUserState;
    },
    updateProfile(state, action: PayloadAction<Partial<UserProfile>>) {
      Object.assign(state, action.payload);
    },
  },
});

export const { hydrateUser, login, logout, updateProfile } = userSlice.actions;
export default userSlice.reducer;
