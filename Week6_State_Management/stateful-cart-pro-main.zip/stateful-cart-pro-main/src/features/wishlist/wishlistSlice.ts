import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { Product } from "@/services/products";

export interface WishlistItem {
  id: string;
  name: string;
  brand: string;
  price: number;
  image: string;
  rating: number;
}

export interface WishlistState {
  items: WishlistItem[];
}

export const initialWishlistState: WishlistState = { items: [] };

const wishlistSlice = createSlice({
  name: "wishlist",
  initialState: initialWishlistState,
  reducers: {
    hydrateWishlist(_state, action: PayloadAction<WishlistState>) {
      return action.payload;
    },
    addToWishlist(state, action: PayloadAction<Product>) {
      const p = action.payload;
      if (state.items.some((i) => i.id === p.id)) return;
      state.items.unshift({
        id: p.id,
        name: p.name,
        brand: p.brand,
        price: p.price,
        image: p.image,
        rating: p.rating,
      });
    },
    removeFromWishlist(state, action: PayloadAction<string>) {
      state.items = state.items.filter((i) => i.id !== action.payload);
    },
    clearWishlist() {
      return initialWishlistState;
    },
  },
});

export const { hydrateWishlist, addToWishlist, removeFromWishlist, clearWishlist } =
  wishlistSlice.actions;

export default wishlistSlice.reducer;
