import { Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";

import { categories } from "@/services/products";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-surface">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="space-y-3">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
            <span className="flex size-8 items-center justify-center rounded-xl gradient-accent text-accent-foreground">
              <Sparkles size={16} />
            </span>
            SmartCart<span className="text-gradient">Pro</span>
          </Link>
          <p className="max-w-xs text-sm text-muted-foreground">
            A production-grade demo of global state management with Redux Toolkit, persisted to
            Local Storage.
          </p>
        </div>

        <nav aria-label="Categories">
          <h2 className="mb-3 text-sm font-semibold">Categories</h2>
          <ul className="space-y-2 text-sm text-muted-foreground">
            {categories.slice(0, 5).map((c) => (
              <li key={c.id}>
                <Link to="/" search={{ category: c.id }} hash="catalog" className="hover:text-foreground">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Shop">
          <h2 className="mb-3 text-sm font-semibold">Your account</h2>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/cart" className="hover:text-foreground">Cart</Link>
            </li>
            <li>
              <Link to="/wishlist" className="hover:text-foreground">Wishlist</Link>
            </li>
            <li>
              <Link to="/checkout" className="hover:text-foreground">Checkout</Link>
            </li>
            <li>
              <Link to="/settings" className="hover:text-foreground">Settings</Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-foreground">Sign in</Link>
            </li>
          </ul>
        </nav>

        <div>
          <h2 className="mb-3 text-sm font-semibold">Under the hood</h2>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/architecture" className="hover:text-foreground">State flow diagram</Link>
            </li>
            <li>Redux Toolkit slices</li>
            <li>Memoised selectors</li>
            <li>Local Storage persistence</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} SmartCart Pro — built as a global state management showcase.
      </div>
    </footer>
  );
}
