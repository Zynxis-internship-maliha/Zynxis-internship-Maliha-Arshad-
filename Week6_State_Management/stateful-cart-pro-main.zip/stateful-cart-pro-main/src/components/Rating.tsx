import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface RatingProps {
  value: number;
  reviews?: number;
  size?: "sm" | "md";
  className?: string;
}

export function Rating({ value, reviews, size = "sm", className }: RatingProps) {
  const px = size === "sm" ? 13 : 16;
  return (
    <div
      className={cn("flex items-center gap-1.5", className)}
      aria-label={`Rated ${value} out of 5`}
    >
      <div className="flex items-center gap-0.5" aria-hidden="true">
        {[0, 1, 2, 3, 4].map((i) => (
          <Star
            key={i}
            size={px}
            className={cn(
              "transition-colors",
              i < Math.round(value) ? "fill-accent text-accent" : "text-muted-foreground/40",
            )}
          />
        ))}
      </div>
      <span className="text-xs font-medium text-muted-foreground">
        {value.toFixed(1)}
        {reviews !== undefined && ` (${reviews.toLocaleString()})`}
      </span>
    </div>
  );
}
