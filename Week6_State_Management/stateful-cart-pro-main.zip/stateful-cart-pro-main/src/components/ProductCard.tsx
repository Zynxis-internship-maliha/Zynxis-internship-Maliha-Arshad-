import { memo } from "react";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Heart, ShoppingBag } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Rating } from "@/components/Rating";
import { PriceTag } from "@/components/PriceTag";
import { useAppSelector } from "@/app/hooks";
import { selectIsWishlisted } from "@/app/selectors";
import { useProductActions } from "@/hooks/useProductActions";
import type { Product } from "@/services/products";
import { cn } from "@/lib/utils";

/** Memoised so unrelated store updates never re-render the whole grid. */
export const ProductCard = memo(function ProductCard({
  product,
  index = 0,
}: {
  product: Product;
  index?: number;
}) {
  const saved = useAppSelector(selectIsWishlisted(product.id));
  const { addToCart, toggleWishlist } = useProductActions();

  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: Math.min(index * 0.05, 0.3), ease: [0.22, 1, 0.36, 1] }}
      className="card-hover group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-soft"
    >
      <Link
        to="/products/$productId"
        params={{ productId: product.id }}
        className="relative block aspect-4/3 overflow-hidden bg-surface"
        aria-label={`View ${product.name}`}
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {product.badge && (
          <span className="absolute left-3 top-3 rounded-full bg-card/90 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide backdrop-blur">
            {product.badge}
          </span>
        )}
      </Link>

      <Button
        type="button"
        variant="glass"
        size="icon-sm"
        aria-pressed={saved}
        aria-label={saved ? `Remove ${product.name} from wishlist` : `Save ${product.name}`}
        onClick={() => toggleWishlist(product)}
        className="absolute right-3 top-3 rounded-full"
      >
        <Heart className={cn("size-4", saved && "fill-destructive text-destructive")} />
      </Button>

      <div className="flex flex-1 flex-col gap-2 p-5">
        <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {product.brand}
        </span>
        <h3 className="text-base leading-snug font-semibold">
          <Link to="/products/$productId" params={{ productId: product.id }} className="hover:underline">
            {product.name}
          </Link>
        </h3>
        <Rating value={product.rating} reviews={product.reviews} />
        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <PriceTag price={product.price} compareAt={product.compareAt} />
          <Button
            size="icon"
            variant="hero"
            aria-label={`Add ${product.name} to cart`}
            onClick={() => addToCart(product)}
          >
            <ShoppingBag />
          </Button>
        </div>
      </div>
    </motion.article>
  );
});
