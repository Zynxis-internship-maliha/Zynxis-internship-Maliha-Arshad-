import { useAppSelector } from "@/app/hooks";
import { selectCoupon, selectOrderSummary, selectTotalItems } from "@/app/selectors";
import { useCurrency } from "@/hooks/useCurrency";
import { Progress } from "@/components/ui/progress";

/** Reads the memoised summary selector — subtotal, tax, discount, shipping. */
export function OrderSummary({ compact = false }: { compact?: boolean }) {
  const summary = useAppSelector(selectOrderSummary);
  const coupon = useAppSelector(selectCoupon);
  const count = useAppSelector(selectTotalItems);
  const { format } = useCurrency();

  const Row = ({ label, value, muted }: { label: string; value: string; muted?: boolean }) => (
    <div className="flex items-center justify-between text-sm">
      <span className={muted ? "text-muted-foreground" : ""}>{label}</span>
      <span className="font-medium tabular-nums">{value}</span>
    </div>
  );

  return (
    <div className="space-y-4 rounded-3xl border border-border bg-card p-6 shadow-soft">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Order summary</h2>
        <span className="text-xs text-muted-foreground">
          {count} item{count === 1 ? "" : "s"}
        </span>
      </div>

      {!compact && summary.freeShippingRemaining > 0 && count > 0 && (
        <div className="space-y-2 rounded-2xl bg-secondary/70 p-4">
          <p className="text-xs text-muted-foreground">
            Add <strong className="text-foreground">{format(summary.freeShippingRemaining)}</strong>{" "}
            more for free shipping
          </p>
          <Progress
            value={Math.min(100, (summary.subtotal / (summary.subtotal + summary.freeShippingRemaining)) * 100)}
            className="h-1.5"
          />
        </div>
      )}

      <div className="space-y-2.5 border-t border-border pt-4">
        <Row label="Subtotal" value={format(summary.subtotal)} muted />
        <Row
          label={coupon ? `Discount (${coupon})` : "Discount"}
          value={`−${format(summary.discount)}`}
          muted
        />
        <Row label="Estimated tax (8%)" value={format(summary.tax)} muted />
        <Row
          label="Shipping"
          value={summary.shipping === 0 ? "Free" : format(summary.shipping)}
          muted
        />
      </div>

      <div className="flex items-baseline justify-between border-t border-border pt-4">
        <span className="font-semibold">Grand total</span>
        <span className="font-display text-2xl font-semibold tabular-nums">
          {format(summary.total)}
        </span>
      </div>
    </div>
  );
}
