import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { categories } from "@/services/products";
import { useCurrency } from "@/hooks/useCurrency";
import { cn } from "@/lib/utils";

export interface Filters {
  category: string;
  maxPrice: number;
  minRating: number;
  sort: "featured" | "price-asc" | "price-desc" | "rating";
}

export const defaultFilters: Filters = {
  category: "all",
  maxPrice: 1000,
  minRating: 0,
  sort: "featured",
};

const sorts: { id: Filters["sort"]; label: string }[] = [
  { id: "featured", label: "Featured" },
  { id: "price-asc", label: "Price ↑" },
  { id: "price-desc", label: "Price ↓" },
  { id: "rating", label: "Top rated" },
];

export function FilterPanel({
  filters,
  onChange,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
}) {
  const { format } = useCurrency();
  const set = <K extends keyof Filters>(key: K, value: Filters[K]) =>
    onChange({ ...filters, [key]: value });

  return (
    <aside
      aria-label="Product filters"
      className="sticky top-24 space-y-7 rounded-3xl border border-border bg-card p-6 shadow-soft"
    >
      <div>
        <h3 className="mb-3 text-sm font-semibold">Category</h3>
        <div className="flex flex-col gap-1">
          {[{ id: "all", name: "All products" }, ...categories].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => set("category", c.id)}
              aria-pressed={filters.category === c.id}
              className={cn(
                "rounded-xl px-3 py-2 text-left text-sm transition-colors",
                filters.category === c.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground",
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-3 flex items-center justify-between">
          <Label htmlFor="price-filter" className="text-sm font-semibold">
            Max price
          </Label>
          <span className="text-sm text-muted-foreground">{format(filters.maxPrice)}</span>
        </div>
        <Slider
          id="price-filter"
          min={100}
          max={1000}
          step={50}
          value={[filters.maxPrice]}
          onValueChange={([v]) => set("maxPrice", v ?? 1000)}
        />
      </div>

      <div>
        <h3 className="mb-3 text-sm font-semibold">Minimum rating</h3>
        <div className="flex flex-wrap gap-2">
          {[0, 4, 4.5, 4.8].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => set("minRating", r)}
              aria-pressed={filters.minRating === r}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                filters.minRating === r
                  ? "border-transparent bg-accent text-accent-foreground"
                  : "border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {r === 0 ? "Any" : `${r}+`}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-3 text-sm font-semibold">Sort by</h3>
        <div className="grid grid-cols-2 gap-2">
          {sorts.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => set("sort", s.id)}
              aria-pressed={filters.sort === s.id}
              className={cn(
                "rounded-xl border px-3 py-2 text-xs font-medium transition-colors",
                filters.sort === s.id
                  ? "border-transparent bg-secondary text-foreground"
                  : "border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <Button variant="ghost" className="w-full" onClick={() => onChange(defaultFilters)}>
        Reset filters
      </Button>
    </aside>
  );
}
