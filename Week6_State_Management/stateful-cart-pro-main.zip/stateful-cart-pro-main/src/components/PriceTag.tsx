import { useCurrency } from "@/hooks/useCurrency";
import { cn } from "@/lib/utils";

export function PriceTag({
  price,
  compareAt,
  className,
  size = "md",
}: {
  price: number;
  compareAt?: number | undefined;
  className?: string | undefined;
  size?: "md" | "lg" | undefined;
}) {
  const { format } = useCurrency();
  return (
    <div className={cn("flex items-baseline gap-2", className)}>
      <span
        className={cn(
          "font-display font-semibold tracking-tight",
          size === "lg" ? "text-3xl" : "text-lg",
        )}
      >
        {format(price)}
      </span>
      {compareAt && (
        <span className="text-sm text-muted-foreground line-through">{format(compareAt)}</span>
      )}
    </div>
  );
}
