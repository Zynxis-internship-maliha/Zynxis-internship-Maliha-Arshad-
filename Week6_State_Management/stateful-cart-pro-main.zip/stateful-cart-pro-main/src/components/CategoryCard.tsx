import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import * as Icons from "lucide-react";

import { categories } from "@/services/products";

export function CategoryCard({
  category,
  index = 0,
}: {
  category: (typeof categories)[number];
  index?: number;
}) {
  const Icon = (Icons[category.icon as keyof typeof Icons] ?? Icons.Package) as Icons.LucideIcon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.45, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link
        to="/"
        search={{ category: category.id }}
        hash="catalog"
        className="card-hover flex h-full flex-col gap-3 rounded-3xl border border-border bg-card p-5 shadow-soft"
      >
        <span className="flex size-11 items-center justify-center rounded-2xl bg-secondary text-foreground">
          <Icon size={20} aria-hidden="true" />
        </span>
        <span className="font-semibold">{category.name}</span>
        <span className="text-xs text-muted-foreground">{category.blurb}</span>
      </Link>
    </motion.div>
  );
}
