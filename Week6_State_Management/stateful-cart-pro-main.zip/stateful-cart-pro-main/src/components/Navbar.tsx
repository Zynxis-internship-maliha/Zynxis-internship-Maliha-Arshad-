import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import {
  Heart,
  LogIn,
  LogOut,
  Menu,
  Moon,
  Settings,
  ShoppingBag,
  Sparkles,
  Sun,
  User as UserIcon,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SearchBar } from "@/components/SearchBar";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { selectTotalItems, selectWishlistCount } from "@/app/selectors";
import { toggleTheme } from "@/features/theme/themeSlice";
import { logout } from "@/features/user/userSlice";
import { categories } from "@/services/products";

const navLinks = [
  { to: "/", label: "Shop" },
  { to: "/wishlist", label: "Wishlist" },
  { to: "/cart", label: "Cart" },
  { to: "/architecture", label: "Architecture" },
] as const;

export function Navbar() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const cartCount = useAppSelector(selectTotalItems);
  const wishCount = useAppSelector(selectWishlistCount);
  const theme = useAppSelector((s) => s.theme.mode);
  const user = useAppSelector((s) => s.user);
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  const submitSearch = (value: string) => {
    setQuery(value);
    navigate({ to: "/", search: { q: value || undefined }, hash: "catalog" });
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/70 glass">
      <nav
        aria-label="Main navigation"
        className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8"
      >
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="flex size-8 items-center justify-center rounded-xl gradient-accent text-accent-foreground">
            <Sparkles size={16} />
          </span>
          SmartCart<span className="text-gradient">Pro</span>
        </Link>

        <div className="hidden items-center gap-1 lg:flex">
          {navLinks.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              className="rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "text-foreground font-medium" }}
            >
              {l.label}
            </Link>
          ))}
        </div>

        <form
          className="ml-auto hidden max-w-sm flex-1 md:block"
          onSubmit={(e) => {
            e.preventDefault();
            submitSearch(query);
          }}
          role="search"
        >
          <SearchBar value={query} onChange={submitSearch} id="global-search" />
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Switch to ${theme === "light" ? "dark" : "light"} theme`}
            onClick={() => dispatch(toggleTheme())}
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={theme}
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="flex"
              >
                {theme === "light" ? <Sun size={18} /> : <Moon size={18} />}
              </motion.span>
            </AnimatePresence>
          </Button>

          <Button variant="ghost" size="icon" asChild aria-label={`Wishlist, ${wishCount} items`}>
            <Link to="/wishlist" className="relative">
              <Heart size={18} />
              {wishCount > 0 && <Badge count={wishCount} />}
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild aria-label={`Cart, ${cartCount} items`}>
            <Link to="/cart" className="relative">
              <ShoppingBag size={18} />
              {cartCount > 0 && <Badge count={cartCount} />}
            </Link>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Account menu">
                {user.isLoggedIn && user.avatar ? (
                  <img src={user.avatar} alt="" className="size-7 rounded-full bg-secondary" />
                ) : (
                  <UserIcon size={18} />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-2xl">
              <DropdownMenuLabel>
                {user.isLoggedIn ? (
                  <div className="flex flex-col">
                    <span className="font-semibold">{user.username}</span>
                    <span className="text-xs font-normal text-muted-foreground">{user.email}</span>
                  </div>
                ) : (
                  "Not signed in"
                )}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/settings">
                  <Settings size={15} /> Settings
                </Link>
              </DropdownMenuItem>
              {user.isLoggedIn ? (
                <DropdownMenuItem
                  onSelect={() => {
                    dispatch(logout());
                    toast("Signed out");
                  }}
                >
                  <LogOut size={15} /> Sign out
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem asChild>
                  <Link to="/login">
                    <LogIn size={15} /> Sign in
                  </Link>
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open menu">
                <Menu size={18} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 border-border bg-card p-6">
              <SheetTitle className="font-display text-xl">Menu</SheetTitle>
              <div className="mt-6 space-y-6">
                <form
                  role="search"
                  onSubmit={(e) => {
                    e.preventDefault();
                    submitSearch(query);
                    setMobileOpen(false);
                  }}
                >
                  <SearchBar value={query} onChange={setQuery} id="mobile-search" />
                </form>
                <div className="flex flex-col gap-1">
                  {navLinks.map((l) => (
                    <Link
                      key={l.to}
                      to={l.to}
                      onClick={() => setMobileOpen(false)}
                      className="rounded-xl px-3 py-2.5 text-sm font-medium transition-colors hover:bg-secondary"
                    >
                      {l.label}
                    </Link>
                  ))}
                </div>
                <div>
                  <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Categories
                  </p>
                  <div className="flex flex-wrap gap-2 px-3">
                    {categories.map((c) => (
                      <Link
                        key={c.id}
                        to="/"
                        search={{ category: c.id }}
                        hash="catalog"
                        onClick={() => setMobileOpen(false)}
                        className="rounded-full border border-border px-3 py-1.5 text-xs"
                      >
                        {c.name}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}

function Badge({ count }: { count: number }) {
  return (
    <motion.span
      key={count}
      initial={{ scale: 0.6 }}
      animate={{ scale: 1 }}
      className="absolute -right-0.5 -top-0.5 flex min-w-4.5 items-center justify-center rounded-full gradient-accent px-1 text-[10px] font-bold text-accent-foreground"
    >
      {count > 99 ? "99+" : count}
    </motion.span>
  );
}
