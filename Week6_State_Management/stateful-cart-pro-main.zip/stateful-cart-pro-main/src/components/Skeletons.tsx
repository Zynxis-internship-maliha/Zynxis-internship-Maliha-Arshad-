import { cn } from "@/lib/utils";

/** Skeleton block used while product data settles. */
export function SkeletonBlock({ className }: { className?: string }) {
  return <div className={cn("shimmer rounded-xl bg-muted", className)} />;
}

export function ProductCardSkeleton() {
  return (
    <div className="rounded-3xl border border-border bg-card p-3">
      <SkeletonBlock className="aspect-4/3 w-full rounded-2xl" />
      <div className="space-y-2 p-3">
        <SkeletonBlock className="h-3 w-20" />
        <SkeletonBlock className="h-4 w-4/5" />
        <SkeletonBlock className="h-3 w-24" />
        <SkeletonBlock className="h-6 w-28" />
      </div>
    </div>
  );
}
