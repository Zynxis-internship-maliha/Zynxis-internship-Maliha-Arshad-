import { memo } from "react";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Minus, Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useAppDispatch } from "@/app/hooks";
import { decreaseQuantity, increaseQuantity, removeProduct, type CartItem } from "@/features/cart/cartSlice";
import { useCurrency } from "@/hooks/useCurrency";

export const CartItemRow = memo(function CartItemRow({ item }: { item: CartItem }) {
  const dispatch = useAppDispatch();
  const { format } = useCurrency();

  return (
    <motion.li
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -24 }}
      transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
      className="flex gap-4 rounded-3xl border border-border bg-card p-4 shadow-soft"
    >
      <Link
        to="/products/$productId"
        params={{ productId: item.id }}
        className="size-24 shrink-0 overflow-hidden rounded-2xl bg-surface"
      >
        <img src={item.image} alt={item.name} className="size-full object-cover" loading="lazy" />
      </Link>

      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {item.brand}
        </span>
        <Link
          to="/products/$productId"
          params={{ productId: item.id }}
          className="truncate font-semibold hover:underline"
        >
          {item.name}
        </Link>
        <span className="text-sm text-muted-foreground">{format(item.price)} each</span>

        <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-1 rounded-xl border border-border p-1">
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label={`Decrease quantity of ${item.name}`}
              onClick={() => dispatch(decreaseQuantity(item.id))}
            >
              <Minus />
            </Button>
            <span className="w-8 text-center text-sm font-semibold tabular-nums" aria-live="polite">
              {item.quantity}
            </span>
            <Button
              variant="ghost"
              size="icon-sm"
              disabled={item.quantity >= item.stock}
              aria-label={`Increase quantity of ${item.name}`}
              onClick={() => dispatch(increaseQuantity(item.id))}
            >
              <Plus />
            </Button>
          </div>

          <div className="flex items-center gap-3">
            <span className="font-display text-lg font-semibold">
              {format(item.price * item.quantity)}
            </span>
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label={`Remove ${item.name} from cart`}
              onClick={() => dispatch(removeProduct(item.id))}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 />
            </Button>
          </div>
        </div>
      </div>
    </motion.li>
  );
});
