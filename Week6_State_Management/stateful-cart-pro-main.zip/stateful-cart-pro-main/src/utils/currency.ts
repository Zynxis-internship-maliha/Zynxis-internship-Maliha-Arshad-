import type { Currency } from "@/services/products";

/** Static demo FX rates — a real app would fetch these. */
export const RATES: Record<Currency, number> = {
  USD: 1,
  EUR: 0.92,
  GBP: 0.79,
  INR: 83.2,
};

export const CURRENCY_LABELS: Record<Currency, string> = {
  USD: "US Dollar ($)",
  EUR: "Euro (€)",
  GBP: "British Pound (£)",
  INR: "Indian Rupee (₹)",
};

const LOCALES: Record<Currency, string> = {
  USD: "en-US",
  EUR: "de-DE",
  GBP: "en-GB",
  INR: "en-IN",
};

export function formatPrice(usd: number, currency: Currency = "USD") {
  const value = usd * RATES[currency];
  return new Intl.NumberFormat(LOCALES[currency], {
    style: "currency",
    currency,
    maximumFractionDigits: currency === "INR" ? 0 : 2,
  }).format(value);
}
