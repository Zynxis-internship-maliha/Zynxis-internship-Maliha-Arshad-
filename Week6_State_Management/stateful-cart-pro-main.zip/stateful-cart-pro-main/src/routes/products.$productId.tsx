import { useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, ChevronLeft, Heart, Minus, Plus, ShieldCheck, ShoppingBag, Truck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Rating } from "@/components/Rating";
import { PriceTag } from "@/components/PriceTag";
import { ProductCard } from "@/components/ProductCard";
import { useAppSelector } from "@/app/hooks";
import { selectIsWishlisted } from "@/app/selectors";
import { useProductActions } from "@/hooks/useProductActions";
import { getProduct, products } from "@/services/products";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/products/$productId")({
  loader: ({ params }) => {
    const product = getProduct(params.productId);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Product unavailable — SmartCart Pro" }, { name: "robots", content: "noindex" }],
      };
    }
    const { product } = loaderData;
    return {
      meta: [
        { title: `${product.name} — SmartCart Pro` },
        { name: "description", content: product.description.slice(0, 155) },
        { property: "og:title", content: `${product.name} — SmartCart Pro` },
        { property: "og:description", content: product.description.slice(0, 155) },
      ],
    };
  },
  component: ProductDetail,
});

function ProductDetail() {
  const { product } = Route.useLoaderData();
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const saved = useAppSelector(selectIsWishlisted(product.id));
  const { addToCart, toggleWishlist } = useProductActions();

  const related = products.filter((p) => p.category === product.category && p.id !== product.id);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <Button variant="ghost" size="sm" asChild className="mb-6 -ml-2 text-muted-foreground">
        <Link to="/">
          <ChevronLeft /> Back to shop
        </Link>
      </Button>

      <div className="grid gap-12 lg:grid-cols-2">
        {/* Gallery */}
        <div className="space-y-4">
          <motion.div
            key={activeImage}
            initial={{ opacity: 0.4, scale: 0.99 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.35 }}
            className="overflow-hidden rounded-4xl border border-border bg-surface shadow-soft"
          >
            <img
              src={product.gallery[activeImage] ?? product.image}
              alt={`${product.name} view ${activeImage + 1}`}
              className="aspect-square w-full object-cover"
            />
          </motion.div>
          <div className="flex gap-3">
            {product.gallery.map((src: string, i: number) => (
              <button
                key={src + i}
                type="button"
                onClick={() => setActiveImage(i)}
                aria-label={`Show image ${i + 1}`}
                aria-pressed={activeImage === i}
                className={cn(
                  "size-20 overflow-hidden rounded-2xl border-2 transition-colors",
                  activeImage === i ? "border-accent" : "border-border hover:border-foreground/30",
                )}
              >
                <img src={src} alt="" className="size-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
            {product.brand}
          </span>
          <h1 className="mt-2 text-3xl font-semibold sm:text-4xl">{product.name}</h1>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <Rating value={product.rating} reviews={product.reviews} size="md" />
            <span
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium",
                product.stock > 10
                  ? "bg-success/15 text-success"
                  : "bg-destructive/10 text-destructive",
              )}
            >
              {product.stock > 10 ? "In stock" : `Only ${product.stock} left`}
            </span>
          </div>

          <PriceTag price={product.price} compareAt={product.compareAt} size="lg" className="mt-6" />

          <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{product.description}</p>

          <ul className="mt-6 grid gap-2 sm:grid-cols-2">
            {product.highlights.map((h: string) => (
              <li key={h} className="flex items-center gap-2 text-sm">
                <Check size={15} className="text-success" aria-hidden="true" />
                {h}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 rounded-2xl border border-border p-1">
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Decrease quantity"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              >
                <Minus />
              </Button>
              <span className="w-10 text-center font-semibold tabular-nums">{quantity}</span>
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Increase quantity"
                onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
              >
                <Plus />
              </Button>
            </div>

            <Button variant="hero" size="lg" onClick={() => addToCart(product, quantity)}>
              <ShoppingBag /> Add to cart
            </Button>

            <Button
              variant="outline"
              size="lg"
              aria-pressed={saved}
              onClick={() => toggleWishlist(product)}
            >
              <Heart className={cn(saved && "fill-destructive text-destructive")} />
              {saved ? "Saved" : "Wishlist"}
            </Button>
          </div>

          <div className="mt-8 grid gap-3 rounded-3xl border border-border bg-surface p-5 sm:grid-cols-2">
            <div className="flex items-center gap-2 text-sm">
              <Truck size={16} className="text-muted-foreground" /> Free shipping over $250
            </div>
            <div className="flex items-center gap-2 text-sm">
              <ShieldCheck size={16} className="text-muted-foreground" /> 2-year warranty
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24">
          <h2 className="mb-8 text-2xl font-semibold">You may also like</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
