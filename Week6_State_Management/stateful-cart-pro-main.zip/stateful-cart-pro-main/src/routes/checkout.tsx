import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { motion } from "framer-motion";
import { CheckCircle2, CreditCard, Lock, PackageCheck } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { OrderSummary } from "@/components/OrderSummary";
import { EmptyState } from "@/components/EmptyState";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { selectCartItems, selectOrderSummary } from "@/app/selectors";
import { clearCart } from "@/features/cart/cartSlice";
import { useCurrency } from "@/hooks/useCurrency";
import { cn } from "@/lib/utils";

interface CheckoutForm {
  fullName: string;
  email: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
}

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — SmartCart Pro" },
      {
        name: "description",
        content: "Confirm your shipping details and place your order in a few seconds.",
      },
      { property: "og:title", content: "Checkout — SmartCart Pro" },
      { property: "og:description", content: "Fast, validated checkout for the SmartCart Pro demo store." },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const items = useAppSelector(selectCartItems);
  const summary = useAppSelector(selectOrderSummary);
  const user = useAppSelector((s) => s.user);
  const { format } = useCurrency();
  const [placed, setPlaced] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CheckoutForm>({
    defaultValues: {
      fullName: user.username,
      email: user.email,
      address: "",
      city: "",
      postalCode: "",
      country: "",
    },
  });

  const onSubmit = async () => {
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 900));
    const id = `SC-${Math.floor(100000 + Math.random() * 900000)}`;
    setPlaced(id);
    dispatch(clearCart());
    setSubmitting(false);
    toast.success("Order confirmed", { description: `Reference ${id}` });
  };

  if (placed) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-4xl border border-border bg-card p-12 text-center shadow-lift"
        >
          <div className="mx-auto mb-6 flex size-16 items-center justify-center rounded-2xl bg-success/15 text-success">
            <CheckCircle2 size={28} />
          </div>
          <h1 className="text-3xl font-semibold">Order confirmed</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Thanks for shopping with SmartCart Pro. Your reference is{" "}
            <strong className="text-foreground">{placed}</strong> — a confirmation is on its way.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button variant="hero" size="lg" asChild>
              <Link to="/">Continue shopping</Link>
            </Button>
            <Button variant="outline" size="lg" onClick={() => navigate({ to: "/wishlist" })}>
              View wishlist
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <EmptyState
          icon={<PackageCheck />}
          title="Nothing to check out"
          description="Add a few products to your cart and come back here to complete the order."
          action={
            <Button variant="hero" size="lg" asChild>
              <Link to="/">Browse the catalogue</Link>
            </Button>
          }
        />
      </div>
    );
  }

  const field = (
    name: keyof CheckoutForm,
    label: string,
    placeholder: string,
    type = "text",
    pattern?: RegExp,
  ) => (
    <div className="space-y-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input
        id={name}
        type={type}
        placeholder={placeholder}
        aria-invalid={!!errors[name]}
        className={cn("h-11 rounded-xl", errors[name] && "border-destructive")}
        {...register(name, {
          required: `${label} is required`,
          ...(pattern ? { pattern: { value: pattern, message: `Enter a valid ${label.toLowerCase()}` } } : {}),
        })}
      />
      {errors[name] && (
        <p role="alert" className="text-xs text-destructive">
          {errors[name]?.message}
        </p>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-semibold sm:text-4xl">Checkout</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Totals are derived from memoised Redux selectors — nothing is duplicated in local state.
      </p>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_380px]">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
          <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="mb-5 text-lg font-semibold">Customer information</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {field("fullName", "Full name", "Ada Lovelace")}
              {field("email", "Email", "ada@example.com", "email", /^[^\s@]+@[^\s@]+\.[^\s@]+$/)}
            </div>
          </section>

          <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="mb-5 text-lg font-semibold">Shipping address</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">{field("address", "Street address", "12 Orchard Lane")}</div>
              {field("city", "City", "Lisbon")}
              {field("postalCode", "Postal code", "1250-096")}
              <div className="sm:col-span-2">{field("country", "Country", "Portugal")}</div>
            </div>
          </section>

          <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold">
              <CreditCard size={18} /> Payment summary
            </h2>
            <p className="text-sm text-muted-foreground">
              This is a demo store — no card is charged. Placing the order clears the cart slice and
              its persisted copy.
            </p>
            <div className="mt-4 flex items-center justify-between rounded-2xl bg-secondary/60 px-4 py-3">
              <span className="text-sm font-medium">Amount due today</span>
              <span className="font-display text-xl font-semibold">{format(summary.total)}</span>
            </div>
          </section>

          <Button type="submit" variant="hero" size="lg" className="w-full" disabled={submitting}>
            <Lock /> {submitting ? "Placing order…" : `Place order · ${format(summary.total)}`}
          </Button>
        </form>

        <div className="space-y-4">
          <OrderSummary compact />
        </div>
      </div>
    </div>
  );
}
