import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AnimatePresence } from "framer-motion";
import { ShoppingCart, Tag, Trash2, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CartItemRow } from "@/components/CartItemRow";
import { OrderSummary } from "@/components/OrderSummary";
import { EmptyState } from "@/components/EmptyState";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { selectCartItems, selectCoupon } from "@/app/selectors";
import { applyCoupon, clearCart, removeCoupon, COUPONS } from "@/features/cart/cartSlice";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — SmartCart Pro" },
      {
        name: "description",
        content:
          "Review your cart, adjust quantities and apply coupons. Cart contents persist across browser refreshes.",
      },
      { property: "og:title", content: "Your Cart — SmartCart Pro" },
      { property: "og:description", content: "Persistent shopping cart powered by Redux Toolkit." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const dispatch = useAppDispatch();
  const items = useAppSelector(selectCartItems);
  const coupon = useAppSelector(selectCoupon);
  const [code, setCode] = useState("");

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = code.trim().toUpperCase();
    if (!COUPONS[normalized]) {
      toast.error("That coupon isn't valid", { description: "Try SMART10, WEEK6 or REDUX20." });
      return;
    }
    dispatch(applyCoupon(normalized));
    toast.success(`${normalized} applied — ${COUPONS[normalized]}% off`);
    setCode("");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold sm:text-4xl">Shopping cart</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Stored in the cart slice and mirrored to Local Storage on every change.
          </p>
        </div>
        {items.length > 0 && (
          <Button
            variant="ghost"
            className="text-muted-foreground hover:text-destructive"
            onClick={() => {
              dispatch(clearCart());
              toast("Cart cleared");
            }}
          >
            <Trash2 /> Clear cart
          </Button>
        )}
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={<ShoppingCart />}
          title="Your cart is empty"
          description="Nothing here yet. Add something you love and it'll still be here after a refresh."
          action={
            <Button variant="hero" size="lg" asChild>
              <Link to="/">Start shopping</Link>
            </Button>
          }
        />
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
          <ul className="space-y-4">
            <AnimatePresence initial={false}>
              {items.map((item) => (
                <CartItemRow key={item.id} item={item} />
              ))}
            </AnimatePresence>
          </ul>

          <div className="space-y-4">
            <div className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold">
                <Tag size={15} /> Coupon code
              </h2>
              {coupon ? (
                <div className="flex items-center justify-between rounded-2xl bg-success/10 px-4 py-3">
                  <span className="text-sm font-semibold text-success">
                    {coupon} · {COUPONS[coupon]}% off
                  </span>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label="Remove coupon"
                    onClick={() => dispatch(removeCoupon())}
                  >
                    <X />
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleApply} className="flex gap-2">
                  <label htmlFor="coupon" className="sr-only">
                    Coupon code
                  </label>
                  <Input
                    id="coupon"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="SMART10"
                    className="h-10 rounded-xl uppercase"
                  />
                  <Button type="submit">Apply</Button>
                </form>
              )}
              <p className="mt-3 text-xs text-muted-foreground">
                Demo codes: SMART10, WEEK6, REDUX20
              </p>
            </div>

            <OrderSummary />

            <Button variant="hero" size="lg" className="w-full" asChild>
              <Link to="/checkout">Proceed to checkout</Link>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
