import { useMemo, useState, useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, PackageSearch, ShieldCheck, Truck, Undo2 } from "lucide-react";

import { ProductCard } from "@/components/ProductCard";
import { ProductCardSkeleton } from "@/components/Skeletons";
import { CategoryCard } from "@/components/CategoryCard";
import { SearchBar } from "@/components/SearchBar";
import { FilterPanel, defaultFilters, type Filters } from "@/components/FilterPanel";
import { EmptyState } from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { categories, products } from "@/services/products";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search["q"] === "string" && search["q"] ? (search["q"] as string) : undefined,
    category:
      typeof search["category"] === "string" && search["category"]
        ? (search["category"] as string)
        : undefined,
  }),
  head: () => ({
    meta: [
      { title: "SmartCart Pro — Premium Tech, Global State Done Right" },
      {
        name: "description",
        content:
          "Browse premium audio, wearables and workspace gear. A Redux Toolkit demo store with persistent cart, wishlist, theme and preferences.",
      },
      { property: "og:title", content: "SmartCart Pro — Premium Tech Store" },
      {
        property: "og:description",
        content:
          "A modern, responsive storefront showcasing Redux Toolkit global state with Local Storage persistence.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const search = Route.useSearch();
  const [query, setQuery] = useState(search.q ?? "");
  const [filters, setFilters] = useState<Filters>({
    ...defaultFilters,
    category: search.category ?? "all",
  });
  const [loading, setLoading] = useState(true);

  // Simulated catalogue fetch so skeleton loaders are visible on first paint.
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 550);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    setQuery(search.q ?? "");
    setFilters((f) => ({ ...f, category: search.category ?? "all" }));
  }, [search.q, search.category]);

  const featured = useMemo(() => products.filter((p) => p.featured).slice(0, 4), []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = products.filter((p) => {
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q);
      const matchesCategory = filters.category === "all" || p.category === filters.category;
      return (
        matchesQuery &&
        matchesCategory &&
        p.price <= filters.maxPrice &&
        p.rating >= filters.minRating
      );
    });

    switch (filters.sort) {
      case "price-asc":
        return [...list].sort((a, b) => a.price - b.price);
      case "price-desc":
        return [...list].sort((a, b) => b.price - a.price);
      case "rating":
        return [...list].sort((a, b) => b.rating - a.rating);
      default:
        return [...list].sort((a, b) => Number(!!b.featured) - Number(!!a.featured));
    }
  }, [query, filters]);

  return (
    <>
      {/* ------------------------------- Hero ------------------------------- */}
      <section className="relative overflow-hidden gradient-hero">
        <div className="grid-noise absolute inset-0 opacity-30" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-primary-foreground"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-4 py-1.5 text-xs font-medium backdrop-blur">
              Redux Toolkit · persistent global state
            </span>
            <h1 className="mt-6 font-display text-4xl leading-[1.05] font-semibold sm:text-6xl">
              Premium gear that <span className="text-gradient">remembers you</span>
            </h1>
            <p className="mt-5 max-w-lg text-base text-primary-foreground/75">
              Your cart, wishlist, theme and preferences live in a single global store — persisted
              to Local Storage and rehydrated instantly on every visit. Refresh and see.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button variant="hero" size="lg" asChild>
                <a href="#catalog">
                  Shop the catalogue <ArrowRight />
                </a>
              </Button>
              <Button variant="glass" size="lg" asChild>
                <Link to="/architecture">See the state flow</Link>
              </Button>
            </div>
            <dl className="mt-12 grid max-w-md grid-cols-3 gap-6">
              {[
                ["5", "Redux slices"],
                ["100%", "Persisted state"],
                ["0ms", "Rehydration lag"],
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="font-display text-2xl font-semibold">{value}</dt>
                  <dd className="text-xs text-primary-foreground/60">{label}</dd>
                </div>
              ))}
            </dl>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <div className="animate-float overflow-hidden rounded-4xl border border-primary-foreground/15 shadow-lift">
              <img
                src="/images/hero-showcase.jpg"
                alt="Premium headphones, smartwatch and camera arranged on a warm studio backdrop"
                className="aspect-4/3 w-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ------------------------------ Trust bar ---------------------------- */}
      <section className="border-b border-border bg-surface">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:grid-cols-3 sm:px-6 lg:px-8">
          {[
            { icon: Truck, title: "Free shipping over $250", copy: "Tracked, two-day delivery" },
            { icon: Undo2, title: "30-day returns", copy: "No questions, no restocking fee" },
            { icon: ShieldCheck, title: "2-year warranty", copy: "Covered on every product" },
          ].map(({ icon: Icon, title, copy }) => (
            <div key={title} className="flex items-center gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-card text-foreground shadow-soft">
                <Icon size={18} />
              </span>
              <div>
                <p className="text-sm font-semibold">{title}</p>
                <p className="text-xs text-muted-foreground">{copy}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ------------------------------ Featured ----------------------------- */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-semibold">Featured this week</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Hand-picked pieces our team actually uses.
            </p>
          </div>
          <Button variant="ghost" asChild>
            <a href="#catalog">
              View all <ArrowRight />
            </a>
          </Button>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)
            : featured.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      </section>

      {/* ----------------------------- Categories ---------------------------- */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <h2 className="mb-8 text-3xl font-semibold">Shop by category</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          {categories.map((c, i) => (
            <CategoryCard key={c.id} category={c} index={i} />
          ))}
        </div>
      </section>

      {/* ------------------------------ Promo -------------------------------- */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-4xl gradient-hero p-10 text-primary-foreground sm:p-14">
          <div className="grid-noise absolute inset-0 opacity-25" aria-hidden="true" />
          <div className="relative max-w-xl">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground/70">
              Limited offer
            </p>
            <h2 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
              Save 20% with code <span className="text-gradient">REDUX20</span>
            </h2>
            <p className="mt-3 text-sm text-primary-foreground/75">
              Apply it in the cart — the coupon lives in the cart slice and survives a refresh.
            </p>
            <Button variant="hero" size="lg" asChild className="mt-7">
              <Link to="/cart">Go to cart</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ----------------------------- Catalogue ----------------------------- */}
      <section id="catalog" className="mx-auto max-w-7xl scroll-mt-24 px-4 pb-24 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-semibold">All products</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {visible.length} product{visible.length === 1 ? "" : "s"} available
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
          <FilterPanel filters={filters} onChange={setFilters} />

          <div>
            <SearchBar value={query} onChange={setQuery} className="mb-6" id="catalog-search" />
            {loading ? (
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <ProductCardSkeleton key={i} />
                ))}
              </div>
            ) : visible.length === 0 ? (
              <EmptyState
                icon={<PackageSearch />}
                title="No products match"
                description="Try widening the price range or clearing your filters."
                action={
                  <Button
                    onClick={() => {
                      setFilters(defaultFilters);
                      setQuery("");
                    }}
                  >
                    Reset everything
                  </Button>
                }
              />
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {visible.map((p, i) => (
                  <ProductCard key={p.id} product={p} index={i} />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
