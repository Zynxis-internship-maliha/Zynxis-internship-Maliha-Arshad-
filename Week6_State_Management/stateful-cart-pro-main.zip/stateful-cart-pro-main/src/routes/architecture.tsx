import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, Database, HardDrive, Layers, MousePointerClick, RefreshCw } from "lucide-react";

export const Route = createFileRoute("/architecture")({
  head: () => ({
    meta: [
      { title: "State Architecture — SmartCart Pro" },
      {
        name: "description",
        content:
          "The Redux Toolkit state flow behind SmartCart Pro: slices, memoised selectors and Local Storage rehydration.",
      },
      { property: "og:title", content: "State Architecture — SmartCart Pro" },
      {
        property: "og:description",
        content: "How global state flows from component to store to Local Storage and back.",
      },
    ],
  }),
  component: ArchitecturePage,
});

const slices = [
  { name: "cartSlice", state: "items, discount, coupon, shippingCost", actions: "addProduct, removeProduct, increaseQuantity, decreaseQuantity, applyCoupon, clearCart" },
  { name: "wishlistSlice", state: "items", actions: "addToWishlist, removeFromWishlist, clearWishlist" },
  { name: "themeSlice", state: "mode", actions: "toggleTheme, setTheme" },
  { name: "userSlice", state: "username, email, avatar, isLoggedIn", actions: "login, logout, updateProfile" },
  { name: "preferencesSlice", state: "language, currency, notifications", actions: "updateSettings, toggleNotification, resetSettings" },
];

const flow = [
  { icon: MousePointerClick, label: "User interaction", detail: "Click, form submit, toggle" },
  { icon: Layers, label: "React component", detail: "Dispatches a typed action" },
  { icon: Database, label: "Slice reducer", detail: "Immer-powered immutable update" },
  { icon: RefreshCw, label: "Store updated", detail: "Memoised selectors recompute" },
  { icon: HardDrive, label: "Local Storage", detail: "store.subscribe mirrors state" },
];

function ArchitecturePage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-semibold sm:text-4xl">State architecture</h1>
      <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
        Every piece of shared state lives in one Redux Toolkit store, split into feature slices.
        Components never own shared data — they dispatch actions and read from memoised selectors.
      </p>

      <section className="mt-12">
        <h2 className="text-xl font-semibold">State flow</h2>
        <ol className="mt-6 space-y-3">
          {flow.map(({ icon: Icon, label, detail }, i) => (
            <li key={label}>
              <div className="flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-soft">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-secondary">
                  <Icon size={18} />
                </span>
                <div>
                  <p className="font-semibold">{label}</p>
                  <p className="text-xs text-muted-foreground">{detail}</p>
                </div>
              </div>
              {i < flow.length - 1 && (
                <div className="flex justify-center py-2 text-muted-foreground" aria-hidden="true">
                  <ArrowDown size={16} />
                </div>
              )}
            </li>
          ))}
        </ol>
        <p className="mt-4 text-sm text-muted-foreground">
          On the next page load the persisted snapshot is read back and dispatched through
          <code className="mx-1 rounded bg-secondary px-1.5 py-0.5 text-xs">hydrate*</code>
          actions, so the store is rehydrated before the first paint after mount.
        </p>
      </section>

      <section className="mt-16">
        <h2 className="text-xl font-semibold">Slices</h2>
        <div className="mt-6 overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th scope="col" className="px-5 py-3">Slice</th>
                <th scope="col" className="px-5 py-3">State</th>
                <th scope="col" className="px-5 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {slices.map((s) => (
                <tr key={s.name} className="border-t border-border align-top">
                  <td className="px-5 py-4 font-semibold">{s.name}</td>
                  <td className="px-5 py-4 text-muted-foreground">{s.state}</td>
                  <td className="px-5 py-4 text-muted-foreground">{s.actions}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-xl font-semibold">Store diagram</h2>
        <pre className="mt-6 overflow-x-auto rounded-3xl border border-border bg-card p-6 text-xs leading-relaxed shadow-soft">
{`                 User
                   |
                   v
          React Components
                   |
                   v
          Redux Toolkit Store
                   |
   +---------------+---------------+
   v               v               v
Cart Slice    Wishlist Slice    User Slice
   |               |               |
   v               v               v
Theme Slice   Preferences      Product Data
   |
   v
Local Storage
   |
   v
Browser Refresh
   |
   v
Store Rehydrated`}
        </pre>
      </section>
    </div>
  );
}
