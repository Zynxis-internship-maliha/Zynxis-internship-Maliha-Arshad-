import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { motion } from "framer-motion";
import { LogOut, Mail, Lock, Sparkles } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { login, logout } from "@/features/user/userSlice";
import { cn } from "@/lib/utils";

interface LoginForm {
  email: string;
  password: string;
}

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — SmartCart Pro" },
      {
        name: "description",
        content: "Sign in to SmartCart Pro. Your session is stored in the user slice and persisted.",
      },
      { property: "og:title", content: "Sign in — SmartCart Pro" },
      { property: "og:description", content: "A polished, validated authentication screen." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const user = useAppSelector((s) => s.user);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginForm>({ defaultValues: { email: "", password: "" } });

  const onSubmit = async (data: LoginForm) => {
    await new Promise((r) => setTimeout(r, 700));
    dispatch(login({ email: data.email }));
    toast.success("Welcome back!");
    navigate({ to: "/" });
  };

  return (
    <div className="relative flex min-h-[85vh] items-center justify-center overflow-hidden px-4 py-16">
      {/* Animated backdrop */}
      <div className="absolute inset-0 gradient-hero" aria-hidden="true" />
      <div className="grid-noise absolute inset-0 opacity-25" aria-hidden="true" />
      <motion.div
        aria-hidden="true"
        className="absolute -left-24 top-10 size-80 rounded-full bg-accent/30 blur-3xl"
        animate={{ x: [0, 60, 0], y: [0, 40, 0] }}
        transition={{ duration: 16, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden="true"
        className="absolute -right-20 bottom-0 size-96 rounded-full bg-primary-foreground/10 blur-3xl"
        animate={{ x: [0, -50, 0], y: [0, -30, 0] }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md rounded-4xl border border-border bg-card p-8 shadow-lift sm:p-10"
      >
        <span className="flex size-11 items-center justify-center rounded-2xl gradient-accent text-accent-foreground shadow-glow">
          <Sparkles size={20} />
        </span>

        {user.isLoggedIn ? (
          <>
            <h1 className="mt-6 text-2xl font-semibold">You're signed in</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Signed in as <strong className="text-foreground">{user.email}</strong>. This session
              survives a browser refresh.
            </p>
            <div className="mt-8 flex flex-col gap-3">
              <Button variant="hero" size="lg" asChild>
                <Link to="/">Continue shopping</Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  dispatch(logout());
                  toast("Signed out");
                }}
              >
                <LogOut /> Sign out
              </Button>
            </div>
          </>
        ) : (
          <>
            <h1 className="mt-6 text-2xl font-semibold">Welcome back</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Sign in to sync your cart, wishlist and preferences.
            </p>

            <form onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-5" noValidate>
              <div className="space-y-1.5">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail
                    size={15}
                    className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
                    aria-hidden="true"
                  />
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    aria-invalid={!!errors.email}
                    className={cn("h-11 rounded-xl pl-10", errors.email && "border-destructive")}
                    {...register("email", {
                      required: "Email is required",
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: "Enter a valid email address",
                      },
                    })}
                  />
                </div>
                {errors.email && (
                  <p role="alert" className="text-xs text-destructive">
                    {errors.email.message}
                  </p>
                )}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock
                    size={15}
                    className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
                    aria-hidden="true"
                  />
                  <Input
                    id="password"
                    type="password"
                    autoComplete="current-password"
                    placeholder="••••••••"
                    aria-invalid={!!errors.password}
                    className={cn("h-11 rounded-xl pl-10", errors.password && "border-destructive")}
                    {...register("password", {
                      required: "Password is required",
                      minLength: { value: 6, message: "At least 6 characters" },
                    })}
                  />
                </div>
                {errors.password && (
                  <p role="alert" className="text-xs text-destructive">
                    {errors.password.message}
                  </p>
                )}
              </div>

              <Button
                type="submit"
                variant="hero"
                size="lg"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Signing in…" : "Sign in"}
              </Button>
            </form>

            <p className="mt-6 text-center text-xs text-muted-foreground">
              Demo only — any valid email and a 6+ character password works.
            </p>
          </>
        )}
      </motion.div>
    </div>
  );
}
