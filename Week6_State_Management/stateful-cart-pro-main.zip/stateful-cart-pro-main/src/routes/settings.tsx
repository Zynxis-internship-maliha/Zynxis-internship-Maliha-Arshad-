import { createFileRoute, Link } from "@tanstack/react-router";
import { Bell, Globe, Moon, RotateCcw, Wallet } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { selectPreferences, selectTheme, selectUser } from "@/app/selectors";
import { toggleTheme } from "@/features/theme/themeSlice";
import {
  resetSettings,
  toggleNotification,
  updateSettings,
  type Language,
} from "@/features/preferences/preferencesSlice";
import { CURRENCY_LABELS } from "@/utils/currency";
import type { Currency } from "@/services/products";

const LANGUAGES: Record<Language, string> = {
  en: "English",
  es: "Español",
  fr: "Français",
  de: "Deutsch",
  hi: "हिन्दी",
};

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Preferences — SmartCart Pro" },
      {
        name: "description",
        content: "Control theme, currency, language and notifications. Every choice is persisted.",
      },
      { property: "og:title", content: "Preferences — SmartCart Pro" },
      { property: "og:description", content: "User preferences backed by a dedicated Redux slice." },
    ],
  }),
  component: SettingsPage,
});

function Row({
  icon,
  title,
  description,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border py-5 last:border-0">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-xl bg-secondary">
          {icon}
        </span>
        <div>
          <p className="text-sm font-semibold">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function SettingsPage() {
  const dispatch = useAppDispatch();
  const prefs = useAppSelector(selectPreferences);
  const theme = useAppSelector(selectTheme);
  const user = useAppSelector(selectUser);

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="text-3xl font-semibold sm:text-4xl">Preferences</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Managed by the theme and preferences slices, rehydrated from Local Storage on every load.
      </p>

      {user.isLoggedIn ? (
        <div className="mt-8 flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-soft">
          <img src={user.avatar} alt="" className="size-12 rounded-2xl bg-secondary" />
          <div>
            <p className="font-semibold">{user.username}</p>
            <p className="text-xs text-muted-foreground">{user.email}</p>
          </div>
        </div>
      ) : (
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-dashed border-border p-5">
          <p className="text-sm text-muted-foreground">Sign in to sync these preferences.</p>
          <Button asChild>
            <Link to="/login">Sign in</Link>
          </Button>
        </div>
      )}

      <section className="mt-6 rounded-3xl border border-border bg-card px-6 shadow-soft">
        <Row icon={<Moon size={16} />} title="Dark mode" description="Switch the entire interface theme">
          <Switch
            checked={theme === "dark"}
            onCheckedChange={() => dispatch(toggleTheme())}
            aria-label="Toggle dark mode"
          />
        </Row>

        <Row icon={<Wallet size={16} />} title="Currency" description="Applied to every price on the site">
          <Select
            value={prefs.currency}
            onValueChange={(v) => dispatch(updateSettings({ currency: v as Currency }))}
          >
            <SelectTrigger className="w-52 rounded-xl" aria-label="Select currency">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(CURRENCY_LABELS).map(([code, label]) => (
                <SelectItem key={code} value={code}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>

        <Row icon={<Globe size={16} />} title="Language" description="Interface language preference">
          <Select
            value={prefs.language}
            onValueChange={(v) => dispatch(updateSettings({ language: v as Language }))}
          >
            <SelectTrigger className="w-52 rounded-xl" aria-label="Select language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(LANGUAGES).map(([code, label]) => (
                <SelectItem key={code} value={code}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>

        <Row icon={<Bell size={16} />} title="Order updates" description="Shipping and delivery alerts">
          <Switch
            checked={prefs.notifications.orderUpdates}
            onCheckedChange={() => dispatch(toggleNotification("orderUpdates"))}
            aria-label="Toggle order updates"
          />
        </Row>

        <Row icon={<Bell size={16} />} title="Promotions" description="Occasional offers and launches">
          <Switch
            checked={prefs.notifications.promotions}
            onCheckedChange={() => dispatch(toggleNotification("promotions"))}
            aria-label="Toggle promotions"
          />
        </Row>

        <Row icon={<Bell size={16} />} title="Price drops" description="Alerts for saved wishlist items">
          <Switch
            checked={prefs.notifications.priceDrops}
            onCheckedChange={() => dispatch(toggleNotification("priceDrops"))}
            aria-label="Toggle price drop alerts"
          />
        </Row>
      </section>

      <Button
        variant="outline"
        className="mt-6"
        onClick={() => {
          dispatch(resetSettings());
          toast("Preferences reset to defaults");
        }}
      >
        <RotateCcw /> Reset preferences
      </Button>
    </div>
  );
}
