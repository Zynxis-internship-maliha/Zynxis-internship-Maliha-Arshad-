import { createFileRoute, Link } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Heart, ShoppingBag, Trash2, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Rating } from "@/components/Rating";
import { PriceTag } from "@/components/PriceTag";
import { EmptyState } from "@/components/EmptyState";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { selectWishlistItems } from "@/app/selectors";
import { clearWishlist, removeFromWishlist } from "@/features/wishlist/wishlistSlice";
import { addProduct } from "@/features/cart/cartSlice";
import { getProduct } from "@/services/products";

export const Route = createFileRoute("/wishlist")({
  head: () => ({
    meta: [
      { title: "Wishlist — SmartCart Pro" },
      {
        name: "description",
        content: "Everything you've saved for later, kept in sync across sessions.",
      },
      { property: "og:title", content: "Wishlist — SmartCart Pro" },
      { property: "og:description", content: "Saved products persisted with Redux Toolkit." },
    ],
  }),
  component: WishlistPage,
});

function WishlistPage() {
  const dispatch = useAppDispatch();
  const items = useAppSelector(selectWishlistItems);

  const moveToCart = (id: string) => {
    const product = getProduct(id);
    if (!product) return;
    dispatch(addProduct(product, 1));
    dispatch(removeFromWishlist(id));
    toast.success(`${product.name} moved to cart`);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold sm:text-4xl">Wishlist</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {items.length} saved item{items.length === 1 ? "" : "s"} — stored in the wishlist slice.
          </p>
        </div>
        {items.length > 0 && (
          <Button
            variant="ghost"
            className="text-muted-foreground hover:text-destructive"
            onClick={() => {
              dispatch(clearWishlist());
              toast("Wishlist cleared");
            }}
          >
            <Trash2 /> Clear wishlist
          </Button>
        )}
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={<Heart />}
          title="Nothing saved yet"
          description="Tap the heart on any product to keep it here for later."
          action={
            <Button variant="hero" size="lg" asChild>
              <Link to="/">Browse products</Link>
            </Button>
          }
        />
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence initial={false}>
            {items.map((item) => (
              <motion.article
                key={item.id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-soft"
              >
                <Link
                  to="/products/$productId"
                  params={{ productId: item.id }}
                  className="aspect-4/3 overflow-hidden bg-surface"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    loading="lazy"
                    className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </Link>
                <Button
                  variant="glass"
                  size="icon-sm"
                  className="absolute right-3 top-3 rounded-full"
                  aria-label={`Remove ${item.name} from wishlist`}
                  onClick={() => dispatch(removeFromWishlist(item.id))}
                >
                  <X />
                </Button>
                <div className="flex flex-1 flex-col gap-2 p-5">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    {item.brand}
                  </span>
                  <h2 className="text-base leading-snug font-semibold">{item.name}</h2>
                  <Rating value={item.rating} />
                  <PriceTag price={item.price} className="mt-1" />
                  <Button variant="hero" className="mt-auto w-full" onClick={() => moveToCart(item.id)}>
                    <ShoppingBag /> Move to cart
                  </Button>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
