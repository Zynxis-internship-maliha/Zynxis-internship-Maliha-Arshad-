export type Currency = "USD" | "EUR" | "GBP" | "INR";

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  image: string;
  gallery: string[];
  description: string;
  highlights: string[];
  stock: number;
  featured?: boolean;
  badge?: string;
}

export const categories = [
  { id: "audio", name: "Audio", blurb: "Studio-grade sound", icon: "Headphones" },
  { id: "wearables", name: "Wearables", blurb: "Always-on companions", icon: "Watch" },
  { id: "workspace", name: "Workspace", blurb: "Desk essentials", icon: "Keyboard" },
  { id: "imaging", name: "Imaging", blurb: "Capture everything", icon: "Camera" },
  { id: "power", name: "Power", blurb: "Charge anywhere", icon: "BatteryCharging" },
  { id: "living", name: "Living", blurb: "Smart at home", icon: "Lamp" },
] as const;

const img = (n: string) => `/images/${n}.jpg`;

export const products: Product[] = [
  {
    id: "aurora-over-ear",
    name: "Aurora Over-Ear Headphones",
    brand: "Northwave",
    category: "audio",
    price: 349,
    compareAt: 429,
    rating: 4.8,
    reviews: 1284,
    image: img("product-headphones"),
    gallery: [img("product-headphones"), img("product-earbuds"), img("product-speaker")],
    description:
      "Reference-tuned 40mm drivers, adaptive hybrid noise cancellation and 48 hours of playback in a machined aluminium frame. Built for long listening sessions that never fatigue.",
    highlights: ["Adaptive ANC", "48h battery", "Multipoint Bluetooth 5.4", "Memory-foam ear cushions"],
    stock: 24,
    featured: true,
    badge: "Editor's pick",
  },
  {
    id: "pulse-earbuds",
    name: "Pulse Pro Wireless Earbuds",
    brand: "Northwave",
    category: "audio",
    price: 189,
    compareAt: 219,
    rating: 4.6,
    reviews: 942,
    image: img("product-earbuds"),
    gallery: [img("product-earbuds"), img("product-headphones")],
    description:
      "Featherweight buds with spatial audio, transparency mode and a pocketable charging case that tops up in twelve minutes.",
    highlights: ["Spatial audio", "IPX5 sweat resistant", "12 min quick charge", "Wireless charging case"],
    stock: 51,
    featured: true,
  },
  {
    id: "helio-speaker",
    name: "Helio Portable Speaker",
    brand: "Northwave",
    category: "audio",
    price: 229,
    rating: 4.5,
    reviews: 418,
    image: img("product-speaker"),
    gallery: [img("product-speaker"), img("product-lamp")],
    description:
      "A room-filling 360° driver array wrapped in recycled textile. Pairs two units for true stereo in a single tap.",
    highlights: ["360° sound", "20h battery", "IP67 rated", "Stereo pairing"],
    stock: 12,
  },
  {
    id: "orbit-watch",
    name: "Orbit Titanium Smartwatch",
    brand: "Meridian",
    category: "wearables",
    price: 499,
    compareAt: 559,
    rating: 4.9,
    reviews: 2310,
    image: img("product-watch"),
    gallery: [img("product-watch"), img("product-earbuds")],
    description:
      "Grade-5 titanium case, sapphire crystal and a dual-frequency GPS that stays locked in dense cities. Seven-day battery under real use.",
    highlights: ["Sapphire crystal", "Dual-band GPS", "7-day battery", "ECG + SpO₂"],
    stock: 8,
    featured: true,
    badge: "Low stock",
  },
  {
    id: "atlas-keyboard",
    name: "Atlas Mechanical Keyboard",
    brand: "Formwork",
    category: "workspace",
    price: 179,
    rating: 4.7,
    reviews: 763,
    image: img("product-keyboard"),
    gallery: [img("product-keyboard"), img("product-lamp")],
    description:
      "Gasket-mounted 75% layout with hot-swappable switches, per-key lighting and a CNC aluminium body that refuses to flex.",
    highlights: ["Hot-swap switches", "Gasket mount", "QMK/VIA", "USB-C + 2.4GHz"],
    stock: 33,
    featured: true,
  },
  {
    id: "vantage-camera",
    name: "Vantage Compact Camera",
    brand: "Lumen",
    category: "imaging",
    price: 899,
    compareAt: 999,
    rating: 4.8,
    reviews: 356,
    image: img("product-camera"),
    gallery: [img("product-camera"), img("product-speaker")],
    description:
      "A 33MP full-frame sensor in a body that disappears into a jacket pocket. Film simulations baked in, RAW when you need it.",
    highlights: ["33MP full-frame", "In-body stabilisation", "4K/60 ProRes", "Tilting OLED"],
    stock: 5,
    featured: true,
  },
  {
    id: "flux-powerbank",
    name: "Flux 140W Power Bank",
    brand: "Formwork",
    category: "power",
    price: 129,
    rating: 4.4,
    reviews: 611,
    image: img("product-powerbank"),
    gallery: [img("product-powerbank"), img("product-keyboard")],
    description:
      "27,000mAh of graphene-cooled capacity with a live power display. Charges a laptop and two phones simultaneously.",
    highlights: ["140W USB-C PD", "27,000mAh", "Live OLED display", "Airline safe"],
    stock: 64,
  },
  {
    id: "lumen-lamp",
    name: "Lumen Desk Light",
    brand: "Lumen",
    category: "living",
    price: 159,
    compareAt: 189,
    rating: 4.6,
    reviews: 289,
    image: img("product-lamp"),
    gallery: [img("product-lamp"), img("product-keyboard")],
    description:
      "Flicker-free asymmetric lighting that covers the whole desk without glare, with automatic circadian colour shifts.",
    highlights: ["Ra98 colour accuracy", "Circadian presets", "Ambient sensor", "Aluminium arm"],
    stock: 19,
  },
];

export const getProduct = (id: string) => products.find((p) => p.id === id);
