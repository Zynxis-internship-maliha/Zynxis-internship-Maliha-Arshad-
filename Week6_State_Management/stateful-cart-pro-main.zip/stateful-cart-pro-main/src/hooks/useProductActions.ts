import { useCallback } from "react";
import { toast } from "sonner";

import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { addProduct } from "@/features/cart/cartSlice";
import { addToWishlist, removeFromWishlist } from "@/features/wishlist/wishlistSlice";
import type { Product } from "@/services/products";

/** Shared product interactions so cards, detail pages and lists behave alike. */
export function useProductActions() {
  const dispatch = useAppDispatch();
  const wishlistIds = useAppSelector((s) => s.wishlist.items.map((i) => i.id).join(","));

  const addToCart = useCallback(
    (product: Product, quantity = 1) => {
      dispatch(addProduct(product, quantity));
      toast.success(`${product.name} added to cart`, {
        description: quantity > 1 ? `Quantity: ${quantity}` : undefined,
      });
    },
    [dispatch],
  );

  const toggleWishlist = useCallback(
    (product: Product) => {
      const isSaved = wishlistIds.split(",").includes(product.id);
      if (isSaved) {
        dispatch(removeFromWishlist(product.id));
        toast(`${product.name} removed from wishlist`);
      } else {
        dispatch(addToWishlist(product));
        toast.success(`${product.name} saved to wishlist`);
      }
    },
    [dispatch, wishlistIds],
  );

  return { addToCart, toggleWishlist };
}
