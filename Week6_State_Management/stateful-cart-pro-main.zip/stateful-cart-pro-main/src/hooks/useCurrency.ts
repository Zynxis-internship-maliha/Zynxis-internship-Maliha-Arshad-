import { useCallback } from "react";
import { useAppSelector } from "@/app/hooks";
import { selectCurrency } from "@/app/selectors";
import { formatPrice } from "@/utils/currency";

/** Formats USD base prices into the user's preferred currency. */
export function useCurrency() {
  const currency = useAppSelector(selectCurrency);
  const format = useCallback((usd: number) => formatPrice(usd, currency), [currency]);
  return { currency, format };
}
