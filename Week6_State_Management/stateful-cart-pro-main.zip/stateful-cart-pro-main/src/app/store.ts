import { configureStore } from "@reduxjs/toolkit";

import cartReducer from "@/features/cart/cartSlice";
import wishlistReducer from "@/features/wishlist/wishlistSlice";
import themeReducer from "@/features/theme/themeSlice";
import userReducer from "@/features/user/userSlice";
import preferencesReducer from "@/features/preferences/preferencesSlice";

/**
 * Single global store. Slices are feature-scoped so each domain owns its
 * own state shape, reducers and actions.
 *
 * The store starts from default state on both server and client so SSR and
 * hydration match; persisted values are re-applied on mount by
 * <StatePersistence /> (see src/app/StatePersistence.tsx).
 */
export const store = configureStore({
  reducer: {
    cart: cartReducer,
    wishlist: wishlistReducer,
    theme: themeReducer,
    user: userReducer,
    preferences: preferencesReducer,
  },
  devTools: import.meta.env.DEV,
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
