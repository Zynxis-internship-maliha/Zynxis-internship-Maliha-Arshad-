import { createSelector } from "@reduxjs/toolkit";
import type { RootState } from "@/app/store";

/* ---------------------------------- cart --------------------------------- */
export const selectCartItems = (s: RootState) => s.cart.items;
export const selectDiscountRate = (s: RootState) => s.cart.discount;
export const selectShippingCost = (s: RootState) => s.cart.shippingCost;
export const selectCoupon = (s: RootState) => s.cart.coupon;

export const selectTotalItems = createSelector([selectCartItems], (items) =>
  items.reduce((n, i) => n + i.quantity, 0),
);

export const selectSubtotal = createSelector([selectCartItems], (items) =>
  items.reduce((sum, i) => sum + i.price * i.quantity, 0),
);

export const TAX_RATE = 0.08;
export const FREE_SHIPPING_THRESHOLD = 250;

/** Memoised order summary — recomputes only when its inputs change. */
export const selectOrderSummary = createSelector(
  [selectSubtotal, selectDiscountRate, selectShippingCost, selectCartItems],
  (subtotal, discountRate, shippingCost, items) => {
    const discount = (subtotal * discountRate) / 100;
    const taxable = subtotal - discount;
    const tax = taxable * TAX_RATE;
    const shipping = items.length === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : shippingCost;
    return {
      subtotal,
      discount,
      tax,
      shipping,
      total: Math.max(0, taxable + tax + shipping),
      freeShippingRemaining: Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal),
    };
  },
);

export const selectIsInCart = (id: string) => (s: RootState) =>
  s.cart.items.some((i) => i.id === id);

/* -------------------------------- wishlist ------------------------------- */
export const selectWishlistItems = (s: RootState) => s.wishlist.items;
export const selectWishlistCount = (s: RootState) => s.wishlist.items.length;
export const selectIsWishlisted = (id: string) => (s: RootState) =>
  s.wishlist.items.some((i) => i.id === id);

/* ---------------------------------- misc --------------------------------- */
export const selectTheme = (s: RootState) => s.theme.mode;
export const selectUser = (s: RootState) => s.user;
export const selectPreferences = (s: RootState) => s.preferences;
export const selectCurrency = (s: RootState) => s.preferences.currency;
