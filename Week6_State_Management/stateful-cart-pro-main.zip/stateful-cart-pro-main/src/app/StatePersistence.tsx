import { useEffect } from "react";
import { useStore } from "react-redux";

import type { RootState } from "@/app/store";
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import { loadState, saveState } from "@/utils/storage";
import { hydrateCart, initialCartState, type CartState } from "@/features/cart/cartSlice";
import {
  hydrateWishlist,
  initialWishlistState,
  type WishlistState,
} from "@/features/wishlist/wishlistSlice";
import { hydrateTheme, initialThemeState, type ThemeState } from "@/features/theme/themeSlice";
import { hydrateUser, initialUserState, type UserState } from "@/features/user/userSlice";
import {
  hydratePreferences,
  initialPreferencesState,
  type PreferencesState,
} from "@/features/preferences/preferencesSlice";

/**
 * Rehydrates persisted slices after mount, then mirrors every future store
 * update back into Local Storage.
 *
 *   store update -> subscribe callback -> localStorage
 *   page load    -> loadState -> hydrate* action -> store
 */
export function StatePersistence() {
  const dispatch = useAppDispatch();
  const store = useStore<RootState>();
  const theme = useAppSelector((s) => s.theme.mode);

  useEffect(() => {
    dispatch(hydrateCart(loadState<CartState>("cart", initialCartState)));
    dispatch(hydrateWishlist(loadState<WishlistState>("wishlist", initialWishlistState)));
    dispatch(hydrateUser(loadState<UserState>("user", initialUserState)));
    dispatch(hydratePreferences(loadState<PreferencesState>("preferences", initialPreferencesState)));

    const stored = loadState<ThemeState>("theme", {
      mode:
        typeof window !== "undefined" &&
        window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : initialThemeState.mode,
    });
    dispatch(hydrateTheme(stored));

    const unsubscribe = store.subscribe(() => {
      const state = store.getState();
      saveState("cart", state.cart);
      saveState("wishlist", state.wishlist);
      saveState("theme", state.theme);
      saveState("user", state.user);
      saveState("preferences", state.preferences);
    });
    return unsubscribe;
  }, [dispatch, store]);

  // Keep the document class in sync with the theme slice.
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
  }, [theme]);

  return null;
}
