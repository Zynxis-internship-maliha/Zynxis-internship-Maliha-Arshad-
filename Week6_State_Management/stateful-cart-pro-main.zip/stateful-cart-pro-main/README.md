# Stateful Cart Pro

Below is a senior-level prompt optimized for Lovable AI. It is designed as if written by a professional prompt engineer and fulfills your Week 6 Internship Task completely.

Professional Lovable Prompt — Week 6 Internship (Global State Management)

ROLE

You are a Senior React Engineer, Senior UI/UX Designer, Product Designer, and Frontend Architect with 15+ years of experience building production-ready SaaS applications.

Your mission is to design and develop a modern, scalable, responsive React application that demonstrates Global State Management using Redux Toolkit (preferred) or Zustand (acceptable alternative). The application must showcase real-world architecture, clean code, reusable components, persistent state, and modern UI/UX.

This project should look like something built by a professional frontend developer working at a top software company.

Project Title

SmartCart Pro — Modern E-Commerce State Management Demo

Objective

Develop a fully responsive e-commerce application that demonstrates professional implementation of Global State Management.

The application must show how application-wide state is managed efficiently across multiple pages while maintaining excellent performance and scalability.

All important states must persist after browser refresh using Local Storage.

Technology Stack

Use:

React 19

Vite

Redux Toolkit (Mandatory)

React Redux

React Router DOM

Tailwind CSS

Local Storage Persistence

React Icons

Framer Motion

React Hook Form

React Hot Toast

Lucide React

ESLint

Clean Component Architecture

Do NOT use Bootstrap.

UI Design Requirements

Create an ultra-modern interface inspired by:

Stripe

Vercel

Linear

Shopify

Apple

Notion

Design language should include:

Glassmorphism

Soft Shadows

Smooth Animations

Rounded Cards

Large White Space

Modern Typography

Professional Color Palette

Gradient Highlights

Elegant Hover Effects

Beautiful Loading States

Skeleton Loaders

Responsive Layout

Mobile First Design

The application must look premium and production-ready.

Application Pages

Home

Display

Hero Section

Featured Products

Categories

Search

Product Grid

Filter Sidebar

Promotional Banner

Product Details

Display

Product Image Gallery

Product Information

Rating

Price

Description

Quantity Selector

Add to Cart

Add to Wishlist

Shopping Cart

Display

Cart Items

Quantity Controls

Remove Item

Empty Cart

Coupon Section

Order Summary

Calculate

Subtotal

Tax

Discount

Shipping

Grand Total

Wishlist

Display

Saved Products

Move to Cart

Remove Product

Checkout

Display

Customer Information

Shipping Address

Payment Summary

Order Confirmation

User Preferences

Allow users to manage

Theme

Language

Currency

Notification Preference

Settings

Display

Dark Mode Toggle

Currency Selector

Language Selector

Notification Toggle

Login Screen

Beautiful authentication page

Modern card layout

Animated background

Validation

Responsive

404 Page

Professional error page

Animated illustration

Return Home button

Global State Management

Implement Redux Toolkit using feature-based architecture.

Create separate slices for:

Cart Slice

Store

Cart Items

Product Quantity

Total Price

Total Items

Discount

Shipping Cost

Actions

Add Product

Remove Product

Increase Quantity

Decrease Quantity

Clear Cart

Wishlist Slice

Store

Wishlist Items

Actions

Add

Remove

Clear Wishlist

Theme Slice

Store

Light Theme

Dark Theme

Actions

Toggle Theme

User Slice

Store

Username

Email

Login Status

User Avatar

Actions

Login

Logout

Update Profile

Preferences Slice

Store

Language

Currency

Notification Settings

Actions

Update Settings

Reset Settings

Persistence

Persist the following using Local Storage:

Shopping Cart

Wishlist

Theme

User Preferences

Logged-in User

After refreshing the browser, restore all persisted data automatically.

Navigation

Create a sticky responsive navigation bar.

Include

Logo

Search Bar

Categories

Wishlist Icon

Cart Icon with Badge

User Menu

Theme Toggle

Mobile navigation should use an animated drawer.

Components

Develop reusable components:

Product Card

Category Card

Search Bar

Filter Panel

Navbar

Footer

Cart Item

Wishlist Card

Loading Skeleton

Empty State

Toast Notification

Modal

Button

Input

Badge

Price Tag

Rating Component

Folder Structure

Use a scalable architecture:

src/
│
├── app/
│   └── store.js
│
├── features/
│   ├── cart/
│   ├── wishlist/
│   ├── user/
│   ├── preferences/
│   └── theme/
│
├── pages/
│   ├── Home/
│   ├── Product/
│   ├── Cart/
│   ├── Wishlist/
│   ├── Checkout/
│   ├── Settings/
│   ├── Login/
│   └── NotFound/
│
├── components/
│
├── hooks/
│
├── layouts/
│
├── services/
│
├── utils/
│
├── assets/
│
└── styles/


State Flow

Design a clear state flow:

User Interaction
        │
        ▼
React Components
        │
        ▼
Dispatch Redux Action
        │
        ▼
Redux Slice Reducer
        │
        ▼
Redux Store Updated
        │
        ▼
Persist State to Local Storage
        │
        ▼
UI Automatically Re-renders


Logic Diagram

Create a professional architecture diagram showing:

                User
                  │
                  ▼
        React Components
                  │
                  ▼
          Redux Toolkit Store
                  │
      ┌───────────┼───────────┐
      ▼           ▼           ▼
 Cart Slice   Wishlist    User Slice
      │           │           │
      ▼           ▼           ▼
 Theme Slice  Preferences  Products
      │
      ▼
 Local Storage
      │
      ▼
 Browser Refresh
      │
      ▼
 Redux Store Rehydrated


Performance Requirements

Optimize using:

Lazy Loading

Code Splitting

Memoization (React.memo, useMemo, useCallback)

Optimized Redux Selectors

Fast Rendering

Minimal Re-renders

Clean State Updates

Accessibility

Ensure:

Keyboard Navigation

Proper Semantic HTML

ARIA Labels

Focus States

Color Contrast

Responsive Typography

Deliverables

Generate:

Complete React Project

Fully Functional Redux Toolkit Store

Modern Responsive UI

Clean Folder Structure

Reusable Components

Persistent Global State

Logic Diagram

Source Code

README with setup instructions

Well-commented code

Production-ready architecture

Final Quality Requirements

The final application should:

Demonstrate Global State Management clearly using Redux Toolkit.

Persist state across browser sessions with Local Storage.

Include a professional Logic Diagram and clean, maintainable source code.

Follow modern React best practices, scalable architecture, and responsive UI principles.

Feel polished enough to serve as an internship portfolio project or junior frontend developer showcase.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/a0b21658-2d7d-47dd-9584-7625a994a858).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
