import { CircleCheck, CircleDashed, Clock, TriangleAlert, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ClientStatus, ProjectStatus } from "@/data/types";

type Status = ProjectStatus | ClientStatus;

const config: Record<Status, { className: string; icon: LucideIcon }> = {
  Completed: { className: "border-success/35 bg-success/10 text-success", icon: CircleCheck },
  "In Progress": { className: "border-info/35 bg-info/10 text-info", icon: CircleDashed },
  Pending: { className: "border-warning/35 bg-warning/10 text-warning", icon: Clock },
  Delayed: { className: "border-destructive/35 bg-destructive/10 text-destructive", icon: TriangleAlert },
  Active: { className: "border-success/35 bg-success/10 text-success", icon: CircleCheck },
  Onboarding: { className: "border-info/35 bg-info/10 text-info", icon: CircleDashed },
  Churned: { className: "border-border bg-secondary text-muted-foreground", icon: TriangleAlert },
};

export function StatusBadge({ status, className }: { status: Status; className?: string }) {
  const { className: tone, icon: Icon } = config[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        tone,
        className,
      )}
    >
      <Icon className="size-3.5 shrink-0" aria-hidden="true" />
      {status}
    </span>
  );
}
