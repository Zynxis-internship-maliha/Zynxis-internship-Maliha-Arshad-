import { ArrowDownRight, ArrowUpRight, icons as lucideIcons } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatPercent } from "@/lib/format";
import type { DashboardMetric } from "@/data/types";

export function StatCard({ metric, index = 0 }: { metric: DashboardMetric; index?: number }) {
  const Icon = lucideIcons[metric.icon as keyof typeof lucideIcons] ?? lucideIcons.Activity;
  const positive = metric.change >= 0;
  const TrendIcon = positive ? ArrowUpRight : ArrowDownRight;

  return (
    <article
      className="surface-card animate-rise p-5 hover:-translate-y-0.5 hover:border-ring/40 hover:shadow-[var(--shadow-elevated)]"
      style={{ animationDelay: `${Math.min(index, 6) * 45}ms` }}
    >
      <div className="flex items-start justify-between gap-3">
        <h3 className="min-w-0 truncate text-sm font-medium text-muted-foreground">{metric.label}</h3>
        <span
          aria-hidden="true"
          className="grid size-9 shrink-0 place-items-center rounded-lg border bg-secondary text-secondary-foreground"
        >
          <Icon className="size-4" />
        </span>
      </div>
      <p className="mt-3 text-[26px] font-semibold leading-tight tracking-tight">{metric.value}</p>
      <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1">
        <span
          className={cn(
            "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium",
            positive
              ? "border-success/35 bg-success/10 text-success"
              : "border-destructive/35 bg-destructive/10 text-destructive",
          )}
        >
          <TrendIcon className="size-3.5" aria-hidden="true" />
          <span>{formatPercent(metric.change)}</span>
          <span className="sr-only">{positive ? "increase" : "decrease"}</span>
        </span>
        <span className="truncate text-xs text-muted-foreground">{metric.hint}</span>
      </div>
    </article>
  );
}
