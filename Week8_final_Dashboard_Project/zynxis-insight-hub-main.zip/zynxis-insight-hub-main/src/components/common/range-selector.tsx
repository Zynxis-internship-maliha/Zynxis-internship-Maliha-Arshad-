import { dateRanges, type DateRange } from "@/data/analytics";
import { cn } from "@/lib/utils";

export function RangeSelector({
  value,
  onChange,
  label = "Select date range",
}: {
  value: DateRange;
  onChange: (next: DateRange) => void;
  label?: string;
}) {
  return (
    <div
      role="radiogroup"
      aria-label={label}
      className="inline-flex w-full max-w-full overflow-x-auto rounded-lg border bg-secondary p-1 sm:w-auto"
    >
      {dateRanges.map((range) => (
        <button
          key={range}
          type="button"
          role="radio"
          aria-checked={value === range}
          onClick={() => onChange(range)}
          className={cn(
            "flex-1 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors sm:flex-none",
            value === range
              ? "bg-card text-foreground shadow-[var(--shadow-card)]"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {range}
        </button>
      ))}
    </div>
  );
}
