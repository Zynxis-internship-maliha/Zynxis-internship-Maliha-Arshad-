import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { activitySeries, clientDistribution, projectPerformance, revenueSeries } from "@/data/analytics";
import { compactCurrency, currency } from "@/lib/format";

const axisStyle = { fill: "var(--color-muted-foreground)", fontSize: 12 };
const gridStroke = "var(--color-border)";

const tooltipStyle = {
  backgroundColor: "var(--color-popover)",
  border: "1px solid var(--color-border)",
  borderRadius: "0.625rem",
  color: "var(--color-popover-foreground)",
  fontSize: "12px",
  boxShadow: "var(--shadow-elevated)",
};

function ChartFrame({ height, label, children }: { height: number; label: string; children: React.ReactElement }) {
  return (
    <div role="img" aria-label={label} className="w-full min-w-0" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  );
}

export function RevenueChart({ factor = 1, height = 320 }: { factor?: number; height?: number }) {
  const data = revenueSeries.map((point) => ({
    month: point.month,
    Revenue: Math.round(point.revenue * factor),
    Expenses: Math.round(point.expenses * factor),
    Profit: Math.round(point.profit * factor),
  }));

  return (
    <ChartFrame
      height={height}
      label="Area chart of monthly revenue, expenses and profit from January to August"
    >
      <AreaChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="zx-revenue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-chart-1)" stopOpacity={0.35} />
            <stop offset="100%" stopColor="var(--color-chart-1)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="zx-profit" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-chart-2)" stopOpacity={0.28} />
            <stop offset="100%" stopColor="var(--color-chart-2)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
        <XAxis dataKey="month" tick={axisStyle} tickLine={false} axisLine={false} />
        <YAxis
          tick={axisStyle}
          tickLine={false}
          axisLine={false}
          width={64}
          tickFormatter={(value: number) => compactCurrency.format(value)}
        />
        <Tooltip
          contentStyle={tooltipStyle}
          formatter={(value: number, name: string) => [currency.format(value), name]}
        />
        <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
        <Area
          type="monotone"
          dataKey="Revenue"
          stroke="var(--color-chart-1)"
          strokeWidth={2}
          fill="url(#zx-revenue)"
        />
        <Area
          type="monotone"
          dataKey="Profit"
          stroke="var(--color-chart-2)"
          strokeWidth={2}
          fill="url(#zx-profit)"
        />
        <Line type="monotone" dataKey="Expenses" stroke="var(--color-chart-3)" strokeWidth={2} dot={false} />
      </AreaChart>
    </ChartFrame>
  );
}

export function ProjectChart({ height = 300 }: { height?: number }) {
  return (
    <ChartFrame
      height={height}
      label="Bar chart of projects by status: completed, in progress, pending and delayed"
    >
      <BarChart data={projectPerformance} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
        <XAxis dataKey="status" tick={axisStyle} tickLine={false} axisLine={false} interval={0} />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} width={44} />
        <Tooltip
          cursor={{ fill: "var(--color-accent)", opacity: 0.4 }}
          contentStyle={tooltipStyle}
          formatter={(value: number) => [`${value} projects`, "Projects"]}
        />
        <Bar dataKey="projects" radius={[6, 6, 0, 0]} maxBarSize={64}>
          {projectPerformance.map((entry, index) => (
            <Cell key={entry.status} fill={`var(--color-chart-${index + 1})`} />
          ))}
        </Bar>
      </BarChart>
    </ChartFrame>
  );
}

export function ClientDistributionChart({ height = 300 }: { height?: number }) {
  const total = clientDistribution.reduce((sum, entry) => sum + entry.value, 0);

  return (
    <div className="flex min-w-0 flex-col gap-4 sm:flex-row sm:items-center">
      <ChartFrame height={height} label="Donut chart of client distribution by segment">
        <PieChart>
          <Tooltip
            contentStyle={tooltipStyle}
            formatter={(value: number, name: string) => [
              `${value} clients (${Math.round((value / total) * 100)}%)`,
              name,
            ]}
          />
          <Pie
            data={clientDistribution}
            dataKey="value"
            nameKey="segment"
            innerRadius="58%"
            outerRadius="82%"
            paddingAngle={2}
            stroke="var(--color-card)"
            strokeWidth={2}
          >
            {clientDistribution.map((entry, index) => (
              <Cell key={entry.segment} fill={`var(--color-chart-${index + 1})`} />
            ))}
          </Pie>
        </PieChart>
      </ChartFrame>

      <ul className="min-w-0 space-y-2 sm:w-44">
        {clientDistribution.map((entry, index) => (
          <li key={entry.segment} className="flex items-center gap-2 text-sm">
            <span
              aria-hidden="true"
              className="size-2.5 shrink-0 rounded-full"
              style={{ backgroundColor: `var(--color-chart-${index + 1})` }}
            />
            <span className="min-w-0 flex-1 truncate text-muted-foreground">{entry.segment}</span>
            <span className="shrink-0 font-medium tabular-nums">
              {Math.round((entry.value / total) * 100)}%
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ActivityChart({ height = 300 }: { height?: number }) {
  return (
    <ChartFrame
      height={height}
      label="Line chart of tasks completed, tasks pending and new clients over the last six weeks"
    >
      <LineChart data={activitySeries} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
        <XAxis dataKey="week" tick={axisStyle} tickLine={false} axisLine={false} />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} width={44} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
        <Line
          type="monotone"
          name="Tasks completed"
          dataKey="tasksCompleted"
          stroke="var(--color-chart-2)"
          strokeWidth={2}
          dot={{ r: 3 }}
        />
        <Line
          type="monotone"
          name="Tasks pending"
          dataKey="tasksPending"
          stroke="var(--color-chart-3)"
          strokeWidth={2}
          dot={{ r: 3 }}
        />
        <Line
          type="monotone"
          name="New clients"
          dataKey="newClients"
          stroke="var(--color-chart-4)"
          strokeWidth={2}
          dot={{ r: 3 }}
        />
      </LineChart>
    </ChartFrame>
  );
}
