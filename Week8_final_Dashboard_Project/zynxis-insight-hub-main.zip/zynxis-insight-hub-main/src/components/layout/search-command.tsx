import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Button } from "@/components/ui/button";
import { projects } from "@/data/projects";
import { clients } from "@/data/clients";
import { navItems } from "@/components/layout/sidebar-content";

export function SearchCommand() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        setOpen((prev) => !prev);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  const projectResults = useMemo(() => projects.slice(0, 6), []);
  const clientResults = useMemo(() => clients.slice(0, 6), []);

  const go = (to: string) => {
    setOpen(false);
    setQuery("");
    void navigate({ to });
  };

  return (
    <>
      <Button
        variant="outline"
        onClick={() => setOpen(true)}
        className="hidden h-9 w-56 justify-start gap-2 px-3 text-sm font-normal text-muted-foreground lg:flex xl:w-72"
      >
        <Search className="size-4 shrink-0" aria-hidden="true" />
        <span className="truncate">Search projects, clients…</span>
        <kbd className="ml-auto hidden shrink-0 rounded border bg-secondary px-1.5 font-mono text-[10px] text-muted-foreground xl:inline">
          ⌘K
        </kbd>
      </Button>

      <Button
        variant="ghost"
        size="icon"
        aria-label="Open search"
        className="min-h-9 min-w-9 lg:hidden"
        onClick={() => setOpen(true)}
      >
        <Search className="size-4" aria-hidden="true" />
      </Button>

      <CommandDialog
        open={open}
        onOpenChange={setOpen}
        title="Global search"
        description="Search projects, clients and pages"
      >
        <CommandInput
          placeholder="Search projects, clients or pages…"
          value={query}
          onValueChange={setQuery}
        />
        <CommandList>
          <CommandEmpty>
            <div className="px-4 py-6 text-center">
              <p className="text-sm font-medium">No results found</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Try a different term, such as a client company or project name.
              </p>
            </div>
          </CommandEmpty>

          <CommandGroup heading="Pages">
            {navItems.map((item) => (
              <CommandItem key={item.to} value={`page ${item.label}`} onSelect={() => go(item.to)}>
                <item.icon className="size-4" aria-hidden="true" />
                {item.label}
              </CommandItem>
            ))}
          </CommandGroup>

          <CommandGroup heading="Projects">
            {projectResults.map((project) => (
              <CommandItem
                key={project.id}
                value={`project ${project.name} ${project.client}`}
                onSelect={() => go("/projects")}
              >
                <span className="truncate">{project.name}</span>
                <span className="ml-auto truncate text-xs text-muted-foreground">{project.client}</span>
              </CommandItem>
            ))}
          </CommandGroup>

          <CommandGroup heading="Clients">
            {clientResults.map((client) => (
              <CommandItem
                key={client.id}
                value={`client ${client.name} ${client.company}`}
                onSelect={() => go("/clients")}
              >
                <span className="truncate">{client.name}</span>
                <span className="ml-auto truncate text-xs text-muted-foreground">{client.company}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}
