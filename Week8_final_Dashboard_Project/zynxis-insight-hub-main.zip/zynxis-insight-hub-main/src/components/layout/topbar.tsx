import { Link, useRouterState } from "@tanstack/react-router";
import { LogOut, Menu, Settings, UserRound } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SearchCommand } from "@/components/layout/search-command";
import { NotificationDropdown } from "@/components/layout/notification-dropdown";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { initials, useProfile } from "@/lib/profile-context";
import { navItems } from "@/components/layout/sidebar-content";

export function Topbar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const { profile } = useProfile();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const current = navItems.find((item) => (item.to === "/" ? pathname === "/" : pathname.startsWith(item.to)));

  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center gap-2 border-b bg-background/85 px-4 backdrop-blur-md sm:px-6">
      <Button
        variant="ghost"
        size="icon"
        className="min-h-9 min-w-9 md:hidden"
        aria-label="Open navigation menu"
        onClick={onOpenMenu}
      >
        <Menu className="size-4" aria-hidden="true" />
      </Button>

      <nav aria-label="Breadcrumb" className="min-w-0 flex-1">
        <ol className="flex min-w-0 items-center gap-1.5 text-sm">
          <li className="hidden text-muted-foreground sm:block">Zynxis</li>
          <li aria-hidden="true" className="hidden text-muted-foreground sm:block">
            /
          </li>
          <li className="min-w-0 truncate font-medium">{current?.label ?? "Dashboard"}</li>
        </ol>
      </nav>

      <div className="flex shrink-0 items-center gap-1 sm:gap-1.5">
        <SearchCommand />
        <NotificationDropdown />
        <ThemeToggle />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className="ml-1 flex min-h-9 items-center gap-2 rounded-full border py-1 pl-1 pr-1 transition-colors hover:bg-accent sm:pr-3"
              aria-label="Open profile menu"
            >
              <span
                aria-hidden="true"
                className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-[11px] font-semibold text-primary-foreground"
              >
                {initials(profile.fullName)}
              </span>
              <span className="hidden max-w-32 truncate text-sm font-medium sm:block">
                {profile.fullName}
              </span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <span className="block truncate text-sm font-medium">{profile.fullName}</span>
              <span className="block truncate text-xs font-normal text-muted-foreground">
                {profile.email}
              </span>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/profile">
                <UserRound className="size-4" aria-hidden="true" />
                Profile
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/settings">
                <Settings className="size-4" aria-hidden="true" />
                Settings
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onSelect={() => toast.success("Signed out", { description: "This demo keeps you signed in." })}
            >
              <LogOut className="size-4" aria-hidden="true" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
