import { Bell, CheckCheck, CreditCard, FolderCheck, MessageSquare, TimerReset, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotifications } from "@/lib/notifications-context";
import { cn } from "@/lib/utils";
import type { Notification } from "@/data/types";
import { EmptyState } from "@/components/common/empty-state";

const iconFor: Record<Notification["type"], typeof Bell> = {
  client: UserPlus,
  project: FolderCheck,
  payment: CreditCard,
  message: MessageSquare,
  deadline: TimerReset,
};

export function NotificationDropdown() {
  const { notifications, unreadCount, markAllRead, markRead } = useNotifications();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative min-h-9 min-w-9"
          aria-label={`Notifications, ${unreadCount} unread`}
        >
          <Bell className="size-4" aria-hidden="true" />
          {unreadCount > 0 ? (
            <span className="absolute -right-0.5 -top-0.5 grid min-h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">
              {unreadCount}
            </span>
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[min(22rem,calc(100vw-2rem))] p-0">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <p className="text-sm font-semibold">Notifications</p>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 px-2 text-xs"
            disabled={unreadCount === 0}
            onClick={() => {
              markAllRead();
              toast.success("All notifications marked as read");
            }}
          >
            <CheckCheck className="size-3.5" aria-hidden="true" />
            Mark all as read
          </Button>
        </div>

        {notifications.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon={Bell}
              title="You're all caught up"
              description="New client, project and payment updates will appear here."
            />
          </div>
        ) : (
          <ScrollArea className="max-h-80">
            <ul className="divide-y">
              {notifications.map((n) => {
                const Icon = iconFor[n.type];
                return (
                  <li key={n.id}>
                    <button
                      type="button"
                      onClick={() => markRead(n.id)}
                      className="flex w-full gap-3 px-4 py-3 text-left transition-colors hover:bg-accent focus-visible:bg-accent"
                    >
                      <span
                        aria-hidden="true"
                        className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-secondary text-secondary-foreground"
                      >
                        <Icon className="size-4" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className={cn("truncate text-sm", !n.read && "font-semibold")}>{n.title}</span>
                          {!n.read ? (
                            <span className="shrink-0 rounded-full border border-primary/40 px-1.5 py-px text-[10px] font-medium text-primary">
                              New
                            </span>
                          ) : null}
                        </span>
                        <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                          {n.description}
                        </span>
                        <span className="mt-1 block text-[11px] text-muted-foreground">{n.time}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </ScrollArea>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
