import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { defaultProfile } from "@/data/profile";
import type { UserProfile } from "@/data/types";

const STORAGE_KEY = "zynxis-profile";

type ProfileContextValue = {
  profile: UserProfile;
  updateProfile: (next: UserProfile) => void;
  resetProfile: () => void;
  hydrated: boolean;
};

const ProfileContext = createContext<ProfileContextValue | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setProfile({ ...defaultProfile, ...(JSON.parse(raw) as Partial<UserProfile>) });
    } catch {
      /* ignore malformed storage */
    }
    setHydrated(true);
  }, []);

  const updateProfile = useCallback((next: UserProfile) => {
    setProfile(next);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const resetProfile = useCallback(() => {
    setProfile(defaultProfile);
    window.localStorage.removeItem(STORAGE_KEY);
  }, []);

  return (
    <ProfileContext.Provider value={{ profile, updateProfile, resetProfile, hydrated }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error("useProfile must be used within ProfileProvider");
  return ctx;
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}
