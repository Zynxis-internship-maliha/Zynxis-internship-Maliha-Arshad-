import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { FolderKanban, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { ProgressBar } from "@/components/common/progress-bar";
import { EmptyState } from "@/components/common/empty-state";
import { TableSkeleton } from "@/components/common/loading-skeleton";
import { projects } from "@/data/projects";
import type { Project, ProjectStatus } from "@/data/types";
import { currency, formatDate } from "@/lib/format";
import { useSimulatedLoad } from "@/hooks/use-simulated-load";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Zynxis Client Dashboard" },
      {
        name: "description",
        content: "Track active client work, progress, budgets and deadlines across every engagement.",
      },
      { property: "og:title", content: "Projects — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Search, filter and sort your client projects with live progress tracking.",
      },
    ],
  }),
  component: ProjectsPage,
});

const statuses: (ProjectStatus | "All")[] = ["All", "Completed", "In Progress", "Pending", "Delayed"];
const sorts = ["Deadline", "Name", "Progress", "Budget"] as const;

function ProjectsPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<(typeof statuses)[number]>("All");
  const [sort, setSort] = useState<(typeof sorts)[number]>("Deadline");
  const [selected, setSelected] = useState<Project | null>(null);
  const { status: loadStatus } = useSimulatedLoad(500);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    const list = projects.filter((project) => {
      const matchesTerm =
        !term ||
        project.name.toLowerCase().includes(term) ||
        project.client.toLowerCase().includes(term);
      const matchesStatus = status === "All" || project.status === status;
      return matchesTerm && matchesStatus;
    });

    return [...list].sort((a, b) => {
      if (sort === "Name") return a.name.localeCompare(b.name);
      if (sort === "Progress") return b.progress - a.progress;
      if (sort === "Budget") return b.budget - a.budget;
      return a.deadline.localeCompare(b.deadline);
    });
  }, [query, status, sort]);

  const resetFilters = () => {
    setQuery("");
    setStatus("All");
  };

  return (
    <>
      <PageHeader
        title="Projects"
        description="Track your active client work and project progress."
        actions={
          <Button onClick={() => toast.success("Project created", { description: "Draft project added." })}>
            <Plus className="size-4" aria-hidden="true" />
            Add Project
          </Button>
        }
      />

      <div className="surface-card grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-[minmax(0,1fr)_10rem_10rem]">
        <div className="relative min-w-0">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <label htmlFor="project-search" className="sr-only">
            Search projects
          </label>
          <Input
            id="project-search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search project or client…"
            className="pl-9"
          />
        </div>

        <div className="min-w-0">
          <label htmlFor="project-status" className="sr-only">
            Filter by status
          </label>
          <Select value={status} onValueChange={(value) => setStatus(value as typeof status)}>
            <SelectTrigger id="project-status" className="w-full">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {statuses.map((option) => (
                <SelectItem key={option} value={option}>
                  {option === "All" ? "All statuses" : option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="min-w-0">
          <label htmlFor="project-sort" className="sr-only">
            Sort projects
          </label>
          <Select value={sort} onValueChange={(value) => setSort(value as typeof sort)}>
            <SelectTrigger id="project-sort" className="w-full">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              {sorts.map((option) => (
                <SelectItem key={option} value={option}>
                  Sort by {option.toLowerCase()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {loadStatus === "loading" ? (
        <TableSkeleton rows={5} />
      ) : filtered.length === 0 ? (
        <div className="surface-card">
          <EmptyState
            icon={FolderKanban}
            title="No projects found"
            description="Try changing your filters or create a new project."
            actionLabel="Clear filters"
            onAction={resetFilters}
          />
        </div>
      ) : (
        <ul className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((project, index) => (
            <li key={project.id}>
              <button
                type="button"
                onClick={() => setSelected(project)}
                style={{ animationDelay: `${Math.min(index, 6) * 40}ms` }}
                className="surface-card animate-rise w-full p-5 text-left hover:-translate-y-0.5 hover:border-ring/40 hover:shadow-[var(--shadow-elevated)]"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h2 className="truncate text-sm font-semibold">{project.name}</h2>
                    <p className="truncate text-xs text-muted-foreground">{project.client}</p>
                  </div>
                  <StatusBadge status={project.status} />
                </div>

                <ProgressBar className="mt-4" value={project.progress} label={`${project.name} progress`} />

                <dl className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-3">
                  <div className="min-w-0">
                    <dt className="text-muted-foreground">Deadline</dt>
                    <dd className="truncate font-medium">{formatDate(project.deadline)}</dd>
                  </div>
                  <div className="min-w-0">
                    <dt className="text-muted-foreground">Budget</dt>
                    <dd className="truncate font-medium">{currency.format(project.budget)}</dd>
                  </div>
                  <div className="min-w-0">
                    <dt className="text-muted-foreground">Team</dt>
                    <dd className="truncate font-medium">{project.team.length} members</dd>
                  </div>
                </dl>
              </button>
            </li>
          ))}
        </ul>
      )}

      <Dialog open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-lg">
          {selected ? (
            <>
              <DialogHeader>
                <DialogTitle className="pr-6 text-left">{selected.name}</DialogTitle>
                <DialogDescription className="text-left">{selected.summary}</DialogDescription>
              </DialogHeader>

              <div className="space-y-5">
                <div className="flex flex-wrap items-center gap-3">
                  <StatusBadge status={selected.status} />
                  <span className="text-sm text-muted-foreground">{selected.client}</span>
                </div>

                <ProgressBar value={selected.progress} label={`${selected.name} progress`} />

                <dl className="grid grid-cols-2 gap-4 text-sm">
                  <div className="min-w-0">
                    <dt className="text-xs text-muted-foreground">Deadline</dt>
                    <dd className="font-medium">{formatDate(selected.deadline)}</dd>
                  </div>
                  <div className="min-w-0">
                    <dt className="text-xs text-muted-foreground">Budget</dt>
                    <dd className="font-medium">{currency.format(selected.budget)}</dd>
                  </div>
                </dl>

                <div>
                  <h3 className="text-xs text-muted-foreground">Team</h3>
                  <ul className="mt-2 flex flex-wrap gap-2">
                    {selected.team.map((member) => (
                      <li
                        key={member}
                        className="rounded-full border bg-secondary px-2.5 py-1 text-xs text-secondary-foreground"
                      >
                        {member}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}
