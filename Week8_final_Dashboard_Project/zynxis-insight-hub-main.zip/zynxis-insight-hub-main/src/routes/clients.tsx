import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpDown, Mail, Phone, Search, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { EmptyState } from "@/components/common/empty-state";
import { TableSkeleton } from "@/components/common/loading-skeleton";
import { clients } from "@/data/clients";
import type { Client, ClientSegment } from "@/data/types";
import { currency } from "@/lib/format";
import { initials } from "@/lib/profile-context";
import { useSimulatedLoad } from "@/hooks/use-simulated-load";

export const Route = createFileRoute("/clients")({
  head: () => ({
    meta: [
      { title: "Clients — Zynxis Client Dashboard" },
      {
        name: "description",
        content: "Manage client accounts, revenue, project ownership and recent activity in one place.",
      },
      { property: "og:title", content: "Clients — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Search, filter and review every client account across your portfolio.",
      },
    ],
  }),
  component: ClientsPage,
});

const segments: (ClientSegment | "All")[] = ["All", "Enterprise", "Startup", "Small Business", "Individual"];
const PAGE_SIZE = 6;

function ClientsPage() {
  const [query, setQuery] = useState("");
  const [segment, setSegment] = useState<(typeof segments)[number]>("All");
  const [sortDesc, setSortDesc] = useState(true);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Client | null>(null);
  const { status } = useSimulatedLoad(500);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    const list = clients.filter((client) => {
      const matchesTerm =
        !term ||
        client.name.toLowerCase().includes(term) ||
        client.company.toLowerCase().includes(term) ||
        client.project.toLowerCase().includes(term);
      return matchesTerm && (segment === "All" || client.segment === segment);
    });
    return [...list].sort((a, b) => (sortDesc ? b.revenue - a.revenue : a.revenue - b.revenue));
  }, [query, segment, sortDesc]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const visible = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <PageHeader
        title="Clients"
        description="Review account health, revenue and recent activity across your client portfolio."
      />

      <div className="surface-card grid grid-cols-1 gap-3 p-4 sm:grid-cols-[minmax(0,1fr)_11rem_auto]">
        <div className="relative min-w-0">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <label htmlFor="client-search" className="sr-only">
            Search clients
          </label>
          <Input
            id="client-search"
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setPage(1);
            }}
            placeholder="Search client, company or project…"
            className="pl-9"
          />
        </div>

        <div className="min-w-0">
          <label htmlFor="client-segment" className="sr-only">
            Filter by segment
          </label>
          <Select
            value={segment}
            onValueChange={(value) => {
              setSegment(value as typeof segment);
              setPage(1);
            }}
          >
            <SelectTrigger id="client-segment" className="w-full">
              <SelectValue placeholder="Segment" />
            </SelectTrigger>
            <SelectContent>
              {segments.map((option) => (
                <SelectItem key={option} value={option}>
                  {option === "All" ? "All segments" : option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button variant="outline" onClick={() => setSortDesc((prev) => !prev)}>
          <ArrowUpDown className="size-4" aria-hidden="true" />
          Revenue {sortDesc ? "high to low" : "low to high"}
        </Button>
      </div>

      {status === "loading" ? (
        <TableSkeleton rows={6} />
      ) : filtered.length === 0 ? (
        <div className="surface-card">
          <EmptyState
            icon={Users}
            title="No clients found"
            description="Try a different search term or clear the segment filter."
            actionLabel="Clear filters"
            onAction={() => {
              setQuery("");
              setSegment("All");
            }}
          />
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <div className="surface-card hidden overflow-hidden lg:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Revenue</TableHead>
                  <TableHead>Last Activity</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell className="font-medium">
                      <span className="flex min-w-0 items-center gap-2.5">
                        <span
                          aria-hidden="true"
                          className="grid size-8 shrink-0 place-items-center rounded-full bg-secondary text-[11px] font-semibold text-secondary-foreground"
                        >
                          {initials(client.name)}
                        </span>
                        <span className="truncate">{client.name}</span>
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{client.company}</TableCell>
                    <TableCell className="text-muted-foreground">{client.project}</TableCell>
                    <TableCell>
                      <StatusBadge status={client.status} />
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {currency.format(client.revenue)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{client.lastActivity}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => setSelected(client)}>
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile / tablet cards */}
          <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:hidden">
            {visible.map((client) => (
              <li key={client.id}>
                <button
                  type="button"
                  onClick={() => setSelected(client)}
                  className="surface-card w-full p-4 text-left hover:border-ring/40"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-2.5">
                      <span
                        aria-hidden="true"
                        className="grid size-9 shrink-0 place-items-center rounded-full bg-secondary text-xs font-semibold text-secondary-foreground"
                      >
                        {initials(client.name)}
                      </span>
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{client.name}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {client.company}
                        </span>
                      </span>
                    </span>
                    <StatusBadge status={client.status} />
                  </div>
                  <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div className="min-w-0">
                      <dt className="text-muted-foreground">Revenue</dt>
                      <dd className="truncate font-medium tabular-nums">
                        {currency.format(client.revenue)}
                      </dd>
                    </div>
                    <div className="min-w-0">
                      <dt className="text-muted-foreground">Last activity</dt>
                      <dd className="truncate font-medium">{client.lastActivity}</dd>
                    </div>
                  </dl>
                </button>
              </li>
            ))}
          </ul>

          <nav
            aria-label="Client list pagination"
            className="flex flex-wrap items-center justify-between gap-3"
          >
            <p className="text-xs text-muted-foreground">
              Showing {visible.length} of {filtered.length} clients
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <span className="text-xs tabular-nums text-muted-foreground">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </Button>
            </div>
          </nav>
        </>
      )}

      <Sheet open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
          {selected ? (
            <>
              <SheetHeader>
                <SheetTitle>{selected.name}</SheetTitle>
                <SheetDescription>
                  {selected.segment} account · {selected.company}
                </SheetDescription>
              </SheetHeader>

              <div className="space-y-6 px-4 pb-6">
                <StatusBadge status={selected.status} />

                <section>
                  <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Contact
                  </h3>
                  <ul className="mt-2 space-y-2 text-sm">
                    <li className="flex min-w-0 items-center gap-2">
                      <Mail className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                      <span className="truncate">{selected.email}</span>
                    </li>
                    <li className="flex min-w-0 items-center gap-2">
                      <Phone className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                      <span className="truncate">{selected.phone}</span>
                    </li>
                  </ul>
                </section>

                <section className="grid grid-cols-2 gap-4">
                  <div className="min-w-0">
                    <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Revenue
                    </h3>
                    <p className="mt-1 text-lg font-semibold tabular-nums">
                      {currency.format(selected.revenue)}
                    </p>
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Active project
                    </h3>
                    <p className="mt-1 truncate text-sm font-medium">{selected.project}</p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Recent activity
                  </h3>
                  <ol className="mt-2 space-y-3">
                    {selected.activity.map((item) => (
                      <li key={item.id} className="flex gap-3">
                        <span
                          aria-hidden="true"
                          className="mt-1.5 size-2 shrink-0 rounded-full bg-primary"
                        />
                        <div className="min-w-0">
                          <p className="text-sm leading-snug">{item.label}</p>
                          <p className="text-xs text-muted-foreground">{item.time}</p>
                        </div>
                      </li>
                    ))}
                  </ol>
                </section>
              </div>
            </>
          ) : null}
        </SheetContent>
      </Sheet>
    </>
  );
}
