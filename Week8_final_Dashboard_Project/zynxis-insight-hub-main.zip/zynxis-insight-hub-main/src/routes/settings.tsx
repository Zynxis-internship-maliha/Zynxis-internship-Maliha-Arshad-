import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Monitor, Moon, Sun } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { PageHeader } from "@/components/common/page-header";
import { useTheme, type Theme } from "@/lib/theme";
import { useProfile } from "@/lib/profile-context";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Zynxis Client Dashboard" },
      {
        name: "description",
        content: "Configure appearance, notifications, account details and privacy preferences.",
      },
      { property: "og:title", content: "Settings — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Theme, notification, account and security preferences for your workspace.",
      },
    ],
  }),
  component: SettingsPage,
});

const themeOptions: { value: Theme; label: string; icon: typeof Sun }[] = [
  { value: "dark", label: "Dark", icon: Moon },
  { value: "light", label: "Light", icon: Sun },
  { value: "system", label: "System", icon: Monitor },
];

const notificationOptions = [
  { id: "email", label: "Email notifications", description: "Daily digest of portfolio changes." },
  { id: "projects", label: "Project updates", description: "Milestones, status changes and blockers." },
  { id: "messages", label: "Client messages", description: "Direct messages from client contacts." },
  { id: "reports", label: "Weekly reports", description: "Monday summary of revenue and delivery." },
];

function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const { profile } = useProfile();
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    email: true,
    projects: true,
    messages: false,
    reports: true,
  });

  return (
    <>
      <PageHeader title="Settings" description="Configure appearance, notifications, account and privacy." />

      <section className="surface-card p-5 sm:p-6">
        <h2 className="text-base font-semibold tracking-tight">Appearance</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Choose how Zynxis looks. Your preference is saved in this browser.
        </p>
        <fieldset className="mt-5">
          <legend className="sr-only">Theme</legend>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {themeOptions.map((option) => {
              const active = theme === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => {
                    setTheme(option.value);
                    toast.success("Settings saved", { description: `Theme set to ${option.label}.` });
                  }}
                  className={cn(
                    "flex items-center gap-3 rounded-xl border p-4 text-left transition-colors",
                    active ? "border-primary bg-accent" : "hover:border-ring/40 hover:bg-accent/50",
                  )}
                >
                  <option.icon className="size-4 shrink-0" aria-hidden="true" />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium">{option.label}</span>
                    <span className="block truncate text-xs text-muted-foreground">
                      {active ? "Currently active" : "Select"}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </fieldset>
      </section>

      <section className="surface-card p-5 sm:p-6">
        <h2 className="text-base font-semibold tracking-tight">Notifications</h2>
        <ul className="mt-4 divide-y">
          {notificationOptions.map((option) => (
            <li key={option.id} className="flex items-center justify-between gap-4 py-3.5">
              <div className="min-w-0">
                <Label htmlFor={`notify-${option.id}`} className="text-sm font-medium">
                  {option.label}
                </Label>
                <p className="text-xs text-muted-foreground">{option.description}</p>
              </div>
              <Switch
                id={`notify-${option.id}`}
                checked={toggles[option.id] ?? false}
                onCheckedChange={(checked) => {
                  setToggles((prev) => ({ ...prev, [option.id]: checked }));
                  toast.success("Settings saved");
                }}
              />
            </li>
          ))}
        </ul>
      </section>

      <section className="surface-card p-5 sm:p-6">
        <h2 className="text-base font-semibold tracking-tight">Account</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="account-name">Name</Label>
            <Input id="account-name" defaultValue={profile.fullName} readOnly />
          </div>
          <div className="space-y-2">
            <Label htmlFor="account-email">Email</Label>
            <Input id="account-email" type="email" defaultValue={profile.email} readOnly />
          </div>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Update these fields from the Profile page.
        </p>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => toast("Password reset link sent", { description: "Check your inbox to continue." })}
        >
          Change password
        </Button>
      </section>

      <section className="surface-card p-5 sm:p-6">
        <h2 className="text-base font-semibold tracking-tight">Privacy &amp; Security</h2>
        <ul className="mt-4 divide-y">
          <li className="flex items-center justify-between gap-4 py-3.5">
            <div className="min-w-0">
              <Label htmlFor="privacy-2fa" className="text-sm font-medium">
                Two-factor authentication
              </Label>
              <p className="text-xs text-muted-foreground">Require a second factor on new devices.</p>
            </div>
            <Switch id="privacy-2fa" defaultChecked onCheckedChange={() => toast.success("Settings saved")} />
          </li>
          <li className="flex items-center justify-between gap-4 py-3.5">
            <div className="min-w-0">
              <Label htmlFor="privacy-session" className="text-sm font-medium">
                Auto sign-out after 30 minutes
              </Label>
              <p className="text-xs text-muted-foreground">Ends idle sessions on shared machines.</p>
            </div>
            <Switch id="privacy-session" onCheckedChange={() => toast.success("Settings saved")} />
          </li>
        </ul>
      </section>
    </>
  );
}
