import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { ChartCard } from "@/components/common/chart-card";
import { RangeSelector } from "@/components/common/range-selector";
import { ChartSkeleton, StatCardSkeleton } from "@/components/common/loading-skeleton";
import { ErrorState } from "@/components/common/error-state";
import {
  ActivityChart,
  ClientDistributionChart,
  ProjectChart,
  RevenueChart,
} from "@/components/charts";
import { dashboardMetrics } from "@/data/dashboard";
import { rangeFactor, type DateRange } from "@/data/analytics";
import { useSimulatedLoad } from "@/hooks/use-simulated-load";

export const Route = createFileRoute("/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — Zynxis Client Dashboard" },
      {
        name: "description",
        content: "Monitor revenue, clients, projects and delivery performance with interactive charts.",
      },
      { property: "og:title", content: "Analytics — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Interactive revenue, project, client and activity analytics for your portfolio.",
      },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30 Days");
  const { status, retry, simulateFailure } = useSimulatedLoad(700);

  return (
    <>
      <PageHeader
        title="Analytics"
        description="Monitor revenue, clients, projects and performance."
        actions={
          <>
            <RangeSelector value={range} onChange={setRange} />
            <Button
              variant="outline"
              onClick={() => toast.success("Export queued", { description: "Your CSV will be emailed shortly." })}
            >
              <Download className="size-4" aria-hidden="true" />
              Export
            </Button>
          </>
        }
      />

      <section aria-labelledby="analytics-kpis" className="space-y-4">
        <h2 id="analytics-kpis" className="sr-only">
          Summary metrics
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {status === "loading"
            ? Array.from({ length: 4 }).map((_, i) => <StatCardSkeleton key={i} />)
            : dashboardMetrics
                .slice(0, 4)
                .map((metric, index) => <StatCard key={metric.id} metric={metric} index={index} />)}
        </div>
      </section>

      {status === "error" ? (
        <div className="surface-card">
          <ErrorState onRetry={retry} />
        </div>
      ) : status === "loading" ? (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <ChartSkeleton height={340} />
          <ChartSkeleton height={340} />
          <ChartSkeleton height={300} />
          <ChartSkeleton height={300} />
        </div>
      ) : (
        <>
          <ChartCard title="Revenue Performance" description={`Revenue, expenses and profit · ${range}`}>
            <RevenueChart factor={rangeFactor[range]} height={340} />
          </ChartCard>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <ChartCard title="Project Performance" description="Projects grouped by delivery status">
              <ProjectChart />
            </ChartCard>
            <ChartCard title="Client Distribution" description="Accounts by segment">
              <ClientDistributionChart />
            </ChartCard>
          </div>

          <ChartCard
            title="Activity & Throughput"
            description="Tasks completed, tasks pending and new clients per week"
          >
            <ActivityChart height={320} />
          </ChartCard>
        </>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <p className="text-xs text-muted-foreground">
          Data is mocked locally for this capstone build.
        </p>
        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={simulateFailure}>
          Simulate failed request
        </Button>
      </div>
    </>
  );
}
