import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { ChartCard } from "@/components/common/chart-card";
import { RangeSelector } from "@/components/common/range-selector";
import { ProgressBar } from "@/components/common/progress-bar";
import { StatusBadge } from "@/components/common/status-badge";
import { ChartSkeleton, StatCardSkeleton } from "@/components/common/loading-skeleton";
import { ErrorState } from "@/components/common/error-state";
import {
  ActivityChart,
  ClientDistributionChart,
  ProjectChart,
  RevenueChart,
} from "@/components/charts";
import { dashboardMetrics, recentActivity } from "@/data/dashboard";
import { projects } from "@/data/projects";
import { rangeFactor, type DateRange } from "@/data/analytics";
import { currency, formatDate, greeting } from "@/lib/format";
import { useProfile } from "@/lib/profile-context";
import { useSimulatedLoad } from "@/hooks/use-simulated-load";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Zynxis Client Dashboard" },
      {
        name: "description",
        content:
          "Overview of revenue, active projects, clients and satisfaction across your Zynxis client portfolio.",
      },
      { property: "og:title", content: "Dashboard — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Track revenue, projects, clients and team activity in one premium workspace.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { profile } = useProfile();
  const [range, setRange] = useState<DateRange>("30 Days");
  const { status, retry } = useSimulatedLoad(600);
  const firstName = profile.fullName.split(" ")[0];

  const activeProjects = useMemo(
    () => projects.filter((p) => p.status !== "Completed").slice(0, 5),
    [],
  );

  return (
    <>
      <PageHeader
        title={`${greeting()}, ${firstName}`}
        description="Here's what's happening across your client portfolio today."
        actions={
          <>
            <RangeSelector value={range} onChange={setRange} />
            <Button onClick={() => toast.success("Project created", { description: "Draft project added to your workspace." })}>
              <Plus className="size-4" aria-hidden="true" />
              Create Project
            </Button>
          </>
        }
      />

      <section aria-labelledby="kpi-heading" className="space-y-4">
        <h2 id="kpi-heading" className="sr-only">
          Key performance indicators
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {status === "loading"
            ? Array.from({ length: 6 }).map((_, i) => <StatCardSkeleton key={i} />)
            : dashboardMetrics.map((metric, index) => (
                <StatCard key={metric.id} metric={metric} index={index} />
              ))}
        </div>
      </section>

      {status === "error" ? (
        <div className="surface-card">
          <ErrorState onRetry={retry} />
        </div>
      ) : status === "loading" ? (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <ChartSkeleton height={320} />
          <ChartSkeleton height={320} />
          <ChartSkeleton height={320} />
        </div>
      ) : (
        <>
          <ChartCard
            title="Revenue Performance"
            description={`Revenue, expenses and profit · ${range}`}
          >
            <RevenueChart factor={rangeFactor[range]} />
          </ChartCard>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <ChartCard title="Project Performance" description="Delivery status across the portfolio">
              <ProjectChart />
            </ChartCard>
            <ChartCard title="Client Distribution" description="Accounts by segment">
              <ClientDistributionChart />
            </ChartCard>
          </div>
        </>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        <section className="surface-card animate-rise min-w-0 p-5 xl:col-span-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold tracking-tight">Project progress</h2>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/projects">
                View all
                <ArrowRight className="size-4" aria-hidden="true" />
              </Link>
            </Button>
          </div>
          <ul className="mt-4 divide-y">
            {activeProjects.map((project) => (
              <li key={project.id} className="py-3.5 first:pt-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{project.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {project.client} · due {formatDate(project.deadline)}
                    </p>
                  </div>
                  <StatusBadge status={project.status} />
                </div>
                <ProgressBar
                  className="mt-3"
                  value={project.progress}
                  label={`${project.name} progress`}
                />
              </li>
            ))}
          </ul>
        </section>

        <section className="surface-card animate-rise min-w-0 p-5 xl:col-span-2">
          <h2 className="text-base font-semibold tracking-tight">Recent activity</h2>
          <ol className="mt-4 space-y-4">
            {recentActivity.map((item) => (
              <li key={item.id} className="flex gap-3">
                <span aria-hidden="true" className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" />
                <div className="min-w-0">
                  <p className="text-sm leading-snug">{item.title}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{item.meta}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      </div>

      <ChartCard title="Team activity" description="Tasks and new clients over the last six weeks">
        <ActivityChart />
      </ChartCard>

      <p className="text-xs text-muted-foreground">
        Portfolio value under management: {currency.format(571400)} across {projects.length} tracked
        engagements.
      </p>
    </>
  );
}
