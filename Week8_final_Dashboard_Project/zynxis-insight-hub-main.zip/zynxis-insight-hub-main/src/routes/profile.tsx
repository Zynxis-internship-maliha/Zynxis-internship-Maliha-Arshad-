import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Briefcase, MapPin, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/common/page-header";
import { initials, useProfile } from "@/lib/profile-context";
import type { UserProfile } from "@/data/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Zynxis Client Dashboard" },
      {
        name: "description",
        content: "View and edit your Zynxis account profile, contact details and professional information.",
      },
      { property: "og:title", content: "Profile — Zynxis Client Dashboard" },
      {
        property: "og:description",
        content: "Manage your personal, contact and professional information.",
      },
    ],
  }),
  component: ProfilePage,
});

type Errors = Partial<Record<keyof UserProfile, string>>;

function validate(values: UserProfile): Errors {
  const errors: Errors = {};
  if (!values.fullName.trim()) errors.fullName = "Full name is required.";
  else if (values.fullName.trim().length < 2) errors.fullName = "Use at least 2 characters.";
  else if (values.fullName.length > 60) errors.fullName = "Keep this under 60 characters.";

  if (!values.email.trim()) errors.email = "Email is required.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email)) errors.email = "Enter a valid email address.";

  if (values.phone && !/^[+\d][\d\s()\-.]{6,20}$/.test(values.phone))
    errors.phone = "Enter a valid phone number.";

  if (!values.jobTitle.trim()) errors.jobTitle = "Job title is required.";
  if (!values.company.trim()) errors.company = "Company is required.";
  if (values.bio.length > 400) errors.bio = "Bio must be 400 characters or fewer.";

  return errors;
}

function ProfilePage() {
  const { profile, updateProfile } = useProfile();
  const [editing, setEditing] = useState(false);
  const [values, setValues] = useState<UserProfile>(profile);
  const [errors, setErrors] = useState<Errors>({});

  useEffect(() => {
    if (!editing) setValues(profile);
  }, [profile, editing]);

  const setField = (key: keyof UserProfile, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const nextErrors = validate(values);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      toast.error("Please fix the highlighted fields");
      return;
    }
    updateProfile(values);
    setEditing(false);
    toast.success("Profile updated successfully", { description: "Your changes are saved on this device." });
  };

  return (
    <>
      <PageHeader
        title="Profile"
        description="Manage your personal, contact and professional information."
        actions={
          !editing ? (
            <Button onClick={() => setEditing(true)}>
              <Pencil className="size-4" aria-hidden="true" />
              Edit Profile
            </Button>
          ) : null
        }
      />

      <section className="surface-card animate-rise p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <span
            aria-hidden="true"
            className="grid size-16 shrink-0 place-items-center rounded-2xl bg-primary text-xl font-semibold text-primary-foreground"
          >
            {initials(profile.fullName)}
          </span>
          <div className="min-w-0 space-y-1">
            <h2 className="truncate text-lg font-semibold">{profile.fullName}</h2>
            <p className="truncate text-sm text-muted-foreground">
              {profile.jobTitle} · {profile.company}
            </p>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <MapPin className="size-3.5" aria-hidden="true" />
                {profile.location}
              </span>
              <span className="flex items-center gap-1.5">
                <Briefcase className="size-3.5" aria-hidden="true" />
                {profile.company}
              </span>
            </div>
          </div>
        </div>
      </section>

      <form onSubmit={onSubmit} noValidate className="space-y-6">
        <FieldSection title="Personal Information" description="How your name appears across Zynxis.">
          <Field
            id="fullName"
            label="Full Name"
            value={values.fullName}
            error={errors.fullName}
            disabled={!editing}
            required
            onChange={(v) => setField("fullName", v)}
          />
          <Field
            id="location"
            label="Location"
            value={values.location}
            error={errors.location}
            disabled={!editing}
            onChange={(v) => setField("location", v)}
          />
        </FieldSection>

        <FieldSection title="Contact Information" description="Used for client notifications and reports.">
          <Field
            id="email"
            label="Email"
            type="email"
            value={values.email}
            error={errors.email}
            disabled={!editing}
            required
            onChange={(v) => setField("email", v)}
          />
          <Field
            id="phone"
            label="Phone"
            type="tel"
            value={values.phone}
            error={errors.phone}
            disabled={!editing}
            onChange={(v) => setField("phone", v)}
          />
        </FieldSection>

        <FieldSection title="Professional Information" description="Your role within the organisation.">
          <Field
            id="company"
            label="Company"
            value={values.company}
            error={errors.company}
            disabled={!editing}
            required
            onChange={(v) => setField("company", v)}
          />
          <Field
            id="jobTitle"
            label="Job Title"
            value={values.jobTitle}
            error={errors.jobTitle}
            disabled={!editing}
            required
            onChange={(v) => setField("jobTitle", v)}
          />
        </FieldSection>

        <FieldSection title="About" description="A short summary shared with internal teams." single>
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              rows={5}
              value={values.bio}
              disabled={!editing}
              aria-invalid={Boolean(errors.bio)}
              aria-describedby={errors.bio ? "bio-error" : "bio-hint"}
              onChange={(event) => setField("bio", event.target.value)}
              className={cn(errors.bio && "border-destructive")}
            />
            {errors.bio ? (
              <p id="bio-error" className="text-xs text-destructive">
                {errors.bio}
              </p>
            ) : (
              <p id="bio-hint" className="text-xs text-muted-foreground">
                {values.bio.length}/400 characters
              </p>
            )}
          </div>
        </FieldSection>

        {editing ? (
          <div className="flex flex-wrap gap-2">
            <Button type="submit">Save Changes</Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setValues(profile);
                setErrors({});
                setEditing(false);
              }}
            >
              Cancel
            </Button>
          </div>
        ) : null}
      </form>
    </>
  );
}

function FieldSection({
  title,
  description,
  children,
  single,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
  single?: boolean;
}) {
  return (
    <section className="surface-card p-5 sm:p-6">
      <h2 className="text-base font-semibold tracking-tight">{title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      <div className={cn("mt-5 grid gap-4", !single && "sm:grid-cols-2")}>{children}</div>
    </section>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  error,
  disabled,
  type = "text",
  required,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string | undefined;
  disabled?: boolean;
  type?: string;
  required?: boolean;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>
        {label}
        {required ? (
          <span aria-hidden="true" className="ml-0.5 text-destructive">
            *
          </span>
        ) : null}
      </Label>
      <Input
        id={id}
        type={type}
        value={value}
        disabled={disabled}
        required={required}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-error` : undefined}
        onChange={(event) => onChange(event.target.value)}
        className={cn(error && "border-destructive focus-visible:ring-destructive")}
      />
      {error ? (
        <p id={`${id}-error`} className="text-xs text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
