import { useEffect, useState } from "react";

/**
 * Simulates an async data fetch so the UI can demonstrate loading, success and
 * error states without inventing backend complexity.
 */
export function useSimulatedLoad(delay = 650) {
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [attempt, setAttempt] = useState(0);
  const [shouldFail, setShouldFail] = useState(false);

  useEffect(() => {
    setStatus("loading");
    const timer = window.setTimeout(() => setStatus(shouldFail ? "error" : "ready"), delay);
    return () => window.clearTimeout(timer);
  }, [delay, attempt, shouldFail]);

  return {
    status,
    retry: () => {
      setShouldFail(false);
      setAttempt((n) => n + 1);
    },
    simulateFailure: () => {
      setShouldFail(true);
      setAttempt((n) => n + 1);
    },
  };
}
