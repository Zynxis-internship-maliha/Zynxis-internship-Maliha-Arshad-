export type ProjectStatus = "Completed" | "In Progress" | "Pending" | "Delayed";
export type ClientStatus = "Active" | "Onboarding" | "Churned";
export type ClientSegment = "Enterprise" | "Startup" | "Small Business" | "Individual";

export interface DashboardMetric {
  id: string;
  label: string;
  value: string;
  change: number;
  icon: string;
  hint: string;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  status: ProjectStatus;
  progress: number;
  deadline: string;
  budget: number;
  team: string[];
  summary: string;
}

export interface Client {
  id: string;
  name: string;
  company: string;
  segment: ClientSegment;
  email: string;
  phone: string;
  project: string;
  status: ClientStatus;
  revenue: number;
  lastActivity: string;
  activity: { id: string; label: string; time: string }[];
}

export interface Notification {
  id: string;
  title: string;
  description: string;
  time: string;
  type: "client" | "project" | "payment" | "message" | "deadline";
  read: boolean;
}

export interface UserProfile {
  fullName: string;
  email: string;
  phone: string;
  company: string;
  jobTitle: string;
  location: string;
  bio: string;
}

export interface RevenuePoint {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
}

export interface ActivityPoint {
  week: string;
  tasksCompleted: number;
  tasksPending: number;
  newClients: number;
}
