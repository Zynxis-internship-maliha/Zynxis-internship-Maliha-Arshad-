import type { Notification, UserProfile } from "./types";

export const initialNotifications: Notification[] = [
  {
    id: "n1",
    title: "New client added",
    description: "Vantage Logistics completed onboarding and was assigned to your portfolio.",
    time: "12m ago",
    type: "client",
    read: false,
  },
  {
    id: "n2",
    title: "Project milestone completed",
    description: "CRM Development reached the go-live milestone ahead of schedule.",
    time: "1h ago",
    type: "project",
    read: false,
  },
  {
    id: "n3",
    title: "Payment received",
    description: "Helio Fintech paid invoice #ZX-2291 for $18,400.",
    time: "2h ago",
    type: "payment",
    read: false,
  },
  {
    id: "n4",
    title: "Client sent a message",
    description: "Elena Marsh asked about the analytics tagging plan for launch week.",
    time: "Yesterday",
    type: "message",
    read: true,
  },
  {
    id: "n5",
    title: "Project deadline approaching",
    description: "Analytics Platform is due in 6 days and is currently marked as delayed.",
    time: "Yesterday",
    type: "deadline",
    read: true,
  },
];

export const defaultProfile: UserProfile = {
  fullName: "Alex Morgan",
  email: "alex.morgan@zynxis.example",
  phone: "+1 (415) 555-0110",
  company: "Zynxis",
  jobTitle: "Senior Client Manager",
  location: "San Francisco, CA",
  bio: "Client manager focused on enterprise delivery. I lead cross-functional teams across design, engineering and analytics, and I care about shipping work that measurably moves a client's business.",
};
