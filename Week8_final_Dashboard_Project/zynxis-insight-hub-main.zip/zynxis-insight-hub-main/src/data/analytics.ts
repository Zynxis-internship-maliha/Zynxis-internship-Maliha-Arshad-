import type { ActivityPoint, RevenuePoint } from "./types";

export const revenueSeries: RevenuePoint[] = [
  { month: "Jan", revenue: 42500, expenses: 24800, profit: 17700 },
  { month: "Feb", revenue: 48900, expenses: 26400, profit: 22500 },
  { month: "Mar", revenue: 51200, expenses: 29100, profit: 22100 },
  { month: "Apr", revenue: 58750, expenses: 31200, profit: 27550 },
  { month: "May", revenue: 63400, expenses: 33800, profit: 29600 },
  { month: "Jun", revenue: 71800, expenses: 36500, profit: 35300 },
  { month: "Jul", revenue: 78300, expenses: 39100, profit: 39200 },
  { month: "Aug", revenue: 84250, expenses: 41600, profit: 42650 },
];

export const projectPerformance = [
  { status: "Completed", projects: 89 },
  { status: "In Progress", projects: 24 },
  { status: "Pending", projects: 17 },
  { status: "Delayed", projects: 6 },
];

export const clientDistribution = [
  { segment: "Enterprise", value: 42 },
  { segment: "Startup", value: 58 },
  { segment: "Small Business", value: 39 },
  { segment: "Individual", value: 17 },
];

export const activitySeries: ActivityPoint[] = [
  { week: "W1", tasksCompleted: 48, tasksPending: 19, newClients: 4 },
  { week: "W2", tasksCompleted: 55, tasksPending: 22, newClients: 6 },
  { week: "W3", tasksCompleted: 61, tasksPending: 16, newClients: 3 },
  { week: "W4", tasksCompleted: 72, tasksPending: 14, newClients: 8 },
  { week: "W5", tasksCompleted: 68, tasksPending: 21, newClients: 5 },
  { week: "W6", tasksCompleted: 81, tasksPending: 17, newClients: 9 },
];

export const dateRanges = ["Today", "7 Days", "30 Days", "90 Days"] as const;
export type DateRange = (typeof dateRanges)[number];

/** Multipliers used to make the range selector meaningfully change the data. */
export const rangeFactor: Record<DateRange, number> = {
  Today: 0.06,
  "7 Days": 0.28,
  "30 Days": 1,
  "90 Days": 2.85,
};
