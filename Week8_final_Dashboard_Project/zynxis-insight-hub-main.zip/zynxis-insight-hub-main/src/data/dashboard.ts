import type { DashboardMetric } from "./types";

export const dashboardMetrics: DashboardMetric[] = [
  {
    id: "revenue",
    label: "Total Revenue",
    value: "$84,250",
    change: 18.6,
    icon: "DollarSign",
    hint: "vs. previous period",
  },
  {
    id: "active-projects",
    label: "Active Projects",
    value: "24",
    change: 8.2,
    icon: "FolderKanban",
    hint: "6 launching this month",
  },
  {
    id: "clients",
    label: "Total Clients",
    value: "156",
    change: 12.4,
    icon: "Users",
    hint: "9 added this period",
  },
  {
    id: "completed",
    label: "Completed Projects",
    value: "89",
    change: 15.8,
    icon: "CircleCheck",
    hint: "on-time rate 92%",
  },
  {
    id: "pending",
    label: "Pending Tasks",
    value: "17",
    change: -4.2,
    icon: "ListTodo",
    hint: "3 overdue",
  },
  {
    id: "satisfaction",
    label: "Client Satisfaction",
    value: "94.8%",
    change: 3.1,
    icon: "Star",
    hint: "based on 132 reviews",
  },
];

export const recentActivity = [
  {
    id: "a1",
    title: "Northwind Retail approved the design system handoff",
    meta: "Website Redesign · 24 minutes ago",
  },
  { id: "a2", title: "Invoice #ZX-2291 paid in full ($18,400)", meta: "Helio Fintech · 2 hours ago" },
  { id: "a3", title: "Sprint 14 closed with 27 of 29 tasks completed", meta: "CRM Development · 5 hours ago" },
  { id: "a4", title: "New client onboarded: Vantage Logistics", meta: "Enterprise · Yesterday" },
  { id: "a5", title: "Deadline moved forward for Analytics Platform", meta: "Orbit Labs · Yesterday" },
];
