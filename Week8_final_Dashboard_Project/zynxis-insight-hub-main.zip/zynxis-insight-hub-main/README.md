# Zynxis Client Dashboard — Week 8 Capstone

## 1. Project Overview

A production-quality frontend SaaS client-management dashboard for the fictional brand **Zynxis**. It covers portfolio analytics, project delivery tracking, client management, user profile management and a persistent dark/light theme system.

## 2. Objectives

Fulfil the Week 8 capstone requirements — **data visualization**, **user profile management**, and **dark/light mode** — inside a cohesive, accessible, enterprise-grade interface.

## 3. Features

- Dashboard overview: greeting, date-range selector, 6 KPI cards, revenue/project/client charts, project progress, recent activity
- Analytics page with range selector, export action, 4 charts and a simulated failure/retry path
- Projects: search, status filter, sort, animated progress, project detail modal
- Clients: desktop table + mobile cards, search, segment filter, revenue sort, pagination, client detail drawer
- Profile: real editing with validation, toast feedback and `localStorage` persistence
- Settings: appearance (Dark / Light / System), notifications, account, privacy
- Global ⌘K search across pages, projects and clients; notification dropdown with unread badge and "mark all as read"
- Loading skeletons, empty states, error states, toasts

## 4. Tech Stack

React 19 · TypeScript · TanStack Start/Router · Tailwind CSS v4 · shadcn/ui (Radix) · Recharts · Lucide · Sonner.

## 5. Design System

All colors, radii and shadows are `oklch` tokens in `src/styles.css` (`:root` + `.dark`), mapped to Tailwind utilities through `@theme inline`. Components never hardcode colors. Typography is Inter loaded via `<link>` in the root route.

## 6. Application Architecture

```
src/
  routes/        __root.tsx (shell + providers), index, analytics, projects, clients, profile, settings
  components/
    layout/      app-shell, sidebar-content, topbar, search-command, notification-dropdown, theme-toggle
    common/      page-header, stat-card, chart-card, status-badge, progress-bar, range-selector,
                 empty-state, error-state, loading-skeleton
    charts/      RevenueChart, ProjectChart, ClientDistributionChart, ActivityChart
  data/          types, dashboard, projects, clients, profile, analytics (mock data only)
  lib/           theme, profile-context, notifications-context, format
  hooks/         use-simulated-load
```

## 7. Component Architecture

The persistent `AppShell` renders the sidebar (sheet drawer under `md`), topbar and `<Outlet />`. Pages compose small presentational primitives; no page owns raw layout chrome.

## 8. State Management

React context for cross-cutting state (`ThemeProvider`, `ProfileProvider`, `NotificationsProvider`); local `useState` for filters, dialogs and dropdowns. No Redux — the app does not need it.

## 9. Data Handling

All data is typed mock data in `src/data/`, keyed off interfaces in `types.ts` (`DashboardMetric`, `Project`, `Client`, `Notification`, `UserProfile`, `RevenuePoint`, `ActivityPoint`). No data is hardcoded inside components.

## 10. Theme Implementation

`ThemeProvider` resolves `dark | light | system`, toggles the `.dark` class and `color-scheme` on `<html>`, and persists to `localStorage` under `zynxis-theme`. A small inline script in the document head applies the stored theme before paint to prevent flashing. Charts read theme tokens via CSS variables, so they re-color automatically.

## 11. Responsive Design

Mobile-first layout: sidebar becomes an animated drawer under `md`, KPI grids step 1 → 2 → 3 columns, charts stack, the clients table swaps to cards under `lg`, and `min-w-0` / `truncate` guards prevent horizontal overflow.

## 12. Accessibility

Semantic landmarks (`main`, `nav`, `header`), skip link, single H1 per page, labelled form fields with `aria-invalid` + error IDs, `aria-label` on all icon-only buttons, `role="img"` descriptions on charts, status conveyed with icon + text (not color alone), visible focus rings, Radix-backed dialogs/drawers/menus for focus management, and a global `prefers-reduced-motion` override.

## 13. Performance

Route-level code splitting from the router, memoized filtering/sorting, token-driven CSS instead of runtime style objects, no heavy animation library, and lightweight skeletons instead of blocking spinners.

## 14. Testing Checklist

Routes render · sidebar + drawer · ⌘K search · filters/sort/pagination · charts render and resize · project modal · client drawer · profile validation, save and refresh persistence · theme toggle + persistence · notifications · toasts · no horizontal overflow at 320px · keyboard-only navigation.

## 15. Deployment

Publish from Lovable (Publish button) or build locally with `bun run build` and deploy the output.

## 16. Hosted URL

`https://<your-project>.lovable.app` — replace after publishing.
