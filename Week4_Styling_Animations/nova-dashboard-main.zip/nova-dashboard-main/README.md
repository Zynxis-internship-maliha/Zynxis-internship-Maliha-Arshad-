# Nova Dashboard

You are a Senior Frontend Engineer, Senior UI/UX Designer, Motion Designer, and Accessibility Expert.

Your mission is to build a premium, production-quality SaaS dashboard that demonstrates advanced styling, animation, and modern frontend architecture.

This is NOT a simple dashboard.

The final result should look like a real startup product built by an experienced frontend team.

==================================================

OBJECTIVE

==================================================

Create a fully responsive, visually stunning dashboard using:

• React (Latest)

• Tailwind CSS

• Framer Motion

• Lucide React Icons

• Clean reusable component architecture

The project must demonstrate advanced UI styling and meaningful animations that improve the user experience rather than distracting from it.

Every animation should feel smooth, premium, and intentional.

==================================================

DESIGN STYLE

==================================================

Create a futuristic premium SaaS interface.

Design inspiration:

• Linear

• Vercel

• Stripe

• Framer

• Raycast

• Notion

• Supabase

Visual Style

• Dark Theme

• Minimal

• Elegant

• Spacious

• Premium

• Professional

• Glassmorphism where appropriate

• Soft gradients

• Modern typography

• High contrast

• Excellent readability

Color Palette

Background

#020617

Surface

#0F172A

Card

#1E293B

Border

rgba(255,255,255,0.08)

Primary

#3B82F6

Secondary

#06B6D4

Success

#22C55E

Warning

#F59E0B

Danger

#EF4444

Text

#F8FAFC

Secondary Text

#94A3B8

==================================================

LAYOUT

==================================================

Create a professional dashboard including:

Animated Sidebar

Animated Top Navigation

Search Bar

Notification Bell

Profile Menu

Welcome Hero Section

Statistics Cards

Revenue Card

Sales Analytics

Traffic Overview

Performance Metrics

Activity Timeline

Recent Orders Table

Tasks Panel

Project Progress

Quick Actions

Settings Card

Footer

Everything must be responsive.

Desktop

Tablet

Mobile

==================================================

COMPONENT STRUCTURE

==================================================

Organize code professionally.

src/

components/

Navbar

Sidebar

StatCard

ChartCard

ActivityCard

Button

SearchBar

Table

Modal

Dropdown

Tooltip

Footer

pages/

Dashboard

hooks/

utils/

animations/

styles/

==================================================

TAILWIND REQUIREMENTS

==================================================

Use utility-first Tailwind CSS.

Avoid unnecessary custom CSS.

Use:

Flex

Grid

Spacing System

Rounded Corners

Shadow Utilities

Transition Utilities

Gradient Utilities

Backdrop Blur

Hover Utilities

Focus Utilities

Dark Theme Utilities

==================================================

FRAMER MOTION REQUIREMENTS

==================================================

Use Framer Motion throughout the project.

Animations must be smooth.

Never overuse motion.

Motion should improve usability.

==================================================

PAGE LOAD

==================================================

Entire dashboard

opacity

0 → 1

y

30px → 0

duration

0.8

ease

easeOut

==================================================

SIDEBAR

==================================================

Slide from left

Fade in

Icons animate individually

Active menu item glows

Hover expands background

==================================================

NAVBAR

==================================================

Slide down

Fade in

Search bar expands on focus

Notification bell shakes slightly on click

Avatar scales slightly on hover

==================================================

STAT CARDS

==================================================

Each card enters with stagger animation.

Hover effect

scale 1 → 1.04

translateY -6px

Soft blue shadow

Animated number counting

Progress bars animate width

==================================================

BUTTONS

==================================================

Hover

Scale

Glow

Tap

Shrink

Focus

Accessible outline

==================================================

TABLE

==================================================

Rows fade upward

Hover highlights row

Status badges animate

Sorting icon rotates

==================================================

MODALS

==================================================

Background blur

Scale animation

Fade animation

Smooth exit animation

==================================================

DROPDOWNS

==================================================

Fade

Scale

Click outside closes

Keyboard accessible

==================================================

SCROLL ANIMATIONS

==================================================

Every major section animates once when entering viewport.

Fade

Slide

Scale

Do not repeat continuously.

==================================================

MICRO INTERACTIONS

==================================================

Hover cards

Hover buttons

Hover icons

Hover sidebar items

Hover profile avatar

Animated tooltip

Animated badges

Animated progress rings

Animated skeleton loaders

Floating Action Button

Toast notification animation

==================================================

CUSTOM UI EFFECTS

==================================================

Soft glow

Glass cards

Gradient borders

Gradient buttons

Gradient headings

Custom scrollbar

Smooth scrolling

Backdrop blur

Hover shadows

==================================================

ACCESSIBILITY

==================================================

Keyboard navigation

Visible focus states

ARIA labels

Semantic HTML

High color contrast

Screen-reader friendly

Reduced motion support

==================================================

PERFORMANCE

==================================================

Lazy load heavy components

Optimize images

Reusable components

Clean folder structure

No duplicated code

No inline styles unless necessary

==================================================

CODE QUALITY

==================================================

Professional naming

Reusable components

Readable architecture

Maintainable code

Scalable folder structure

Comment only where useful

==================================================

RESPONSIVENESS

==================================================

Perfect responsiveness for:

320px

375px

768px

1024px

1440px

Large desktop

Nothing should overflow.

==================================================

FINAL RESULT

==================================================

The finished project should feel like a premium commercial SaaS dashboard.

Every interaction should feel polished.

Animations should enhance usability.

The design should impress recruiters and internship mentors.

The code should be production-ready, clean, modular, responsive, and easy to extend.

Generate the complete application with all components, routing, animations, responsive layouts, and modern UI styling. Ensure the project includes everything required to demonstrate advanced Tailwind CSS styling and Framer Motion animations, matching the internship Week 4 deliverable.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/32389565-f3e5-4c63-86cd-20983ad16d28).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
