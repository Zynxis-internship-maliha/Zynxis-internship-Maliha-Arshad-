import { useEffect, useState } from "react";
import { useInView, useReducedMotion } from "motion/react";
import type { RefObject } from "react";

/**
 * Counts from 0 to `target` once the referenced element enters the viewport.
 * Respects prefers-reduced-motion by jumping straight to the final value.
 */
export function useCountUp(
  target: number,
  ref: RefObject<Element | null>,
  { duration = 1400, decimals = 0 }: { duration?: number; decimals?: number } = {},
) {
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const reduceMotion = useReducedMotion();
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!inView) return;
    if (reduceMotion) {
      setValue(target);
      return;
    }

    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Number((target * eased).toFixed(decimals)));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [inView, target, duration, decimals, reduceMotion]);

  return value;
}