import { motion, useReducedMotion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";
import { pageEnter, staggerGrid } from "@/animations/variants";
import { stats } from "@/utils/dashboard-data";
import { Navbar } from "@/components/dashboard/Navbar";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { HeroSection } from "@/components/dashboard/HeroSection";
import { StatCard } from "@/components/dashboard/StatCard";
import { ChartCard } from "@/components/dashboard/ChartCard";
import { ActivityCard } from "@/components/dashboard/ActivityCard";
import { OrdersTable } from "@/components/dashboard/OrdersTable";
import { TasksPanel } from "@/components/dashboard/TasksPanel";
import { PerformanceCard } from "@/components/dashboard/PerformanceCard";
import { ProjectProgress } from "@/components/dashboard/ProjectProgress";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { SettingsCard } from "@/components/dashboard/SettingsCard";
import { Footer } from "@/components/dashboard/Footer";
import { FloatingActionButton } from "@/components/dashboard/FloatingActionButton";
import { Badge } from "@/components/ui-kit/Badge";
import { Button } from "@/components/ui-kit/Button";
import { Modal } from "@/components/ui-kit/Modal";
import { trafficSources } from "@/utils/dashboard-data";

export function Dashboard() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const reduceMotion = useReducedMotion();

  return (
    <div className="mesh-bg flex min-h-dvh bg-background">
      <Sidebar mobileOpen={mobileNavOpen} onMobileClose={() => setMobileNavOpen(false)} />

      <div className="flex min-w-0 flex-1 flex-col">
        <Navbar onMenuClick={() => setMobileNavOpen(true)} onNewReport={() => setReportOpen(true)} />

        <motion.main
          variants={pageEnter}
          initial={reduceMotion ? "visible" : "hidden"}
          animate="visible"
          className="mx-auto w-full max-w-[1500px] flex-1 space-y-5 px-4 py-6 sm:px-6 sm:py-8"
        >
          <HeroSection onPrimaryAction={() => setReportOpen(true)} />

          <motion.div
            variants={staggerGrid}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4"
          >
            {stats.map((stat) => (
              <StatCard key={stat.label} stat={stat} />
            ))}
          </motion.div>

          <div className="grid gap-5 xl:grid-cols-3">
            <ChartCard
              chart="revenue"
              title="Revenue"
              description="Actuals against forecast, last 8 months"
              action={<Badge tone="primary">+18.4%</Badge>}
              className="xl:col-span-2"
            />
            <ChartCard
              chart="traffic"
              title="Traffic overview"
              description="Share of sessions by source"
              height={220}
              footer={
                <ul className="grid grid-cols-2 gap-2">
                  {trafficSources.map((source) => (
                    <li key={source.name} className="flex items-center gap-2 text-xs">
                      <span
                        className="h-2.5 w-2.5 shrink-0 rounded-full"
                        style={{ background: source.color }}
                        aria-hidden="true"
                      />
                      <span className="truncate text-muted-foreground">{source.name}</span>
                      <span className="ml-auto font-semibold text-foreground tabular-nums">
                        {source.value}%
                      </span>
                    </li>
                  ))}
                </ul>
              }
            />
          </div>

          <div className="grid gap-5 xl:grid-cols-3">
            <ChartCard
              chart="sales"
              title="Sales analytics"
              description="Online versus retail, this week"
              className="xl:col-span-2"
            />
            <PerformanceCard />
          </div>

          <div className="grid gap-5 xl:grid-cols-3">
            <OrdersTable
              onExport={() => toast.success("Export queued — we'll email the CSV shortly")}
              className="xl:col-span-2"
            />
            <ActivityCard />
          </div>

          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            <TasksPanel />
            <ProjectProgress />
            <QuickActions />
            <SettingsCard />
          </div>

          <Footer />
        </motion.main>
      </div>

      <FloatingActionButton onClick={() => toast("Nebula AI is thinking…", { description: "Ask anything about your metrics." })} />

      <Modal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        title="Generate a report"
        description="Pick a range and we'll assemble the numbers for you."
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setReportOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="gradient"
              size="sm"
              onClick={() => {
                setReportOpen(false);
                toast.success("Report generated", { description: "Q3 revenue summary is ready." });
              }}
            >
              Generate
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          {["Last 7 days", "Last 30 days", "This quarter"].map((range, index) => (
            <label
              key={range}
              className="flex min-h-11 cursor-pointer items-center gap-3 rounded-2xl border border-border/70 px-3.5 py-3 transition-colors hover:border-primary/45 hover:bg-primary/6"
            >
              <input
                type="radio"
                name="report-range"
                defaultChecked={index === 1}
                className="h-4 w-4 accent-[var(--color-primary)]"
              />
              <span className="text-sm text-foreground">{range}</span>
            </label>
          ))}
        </div>
      </Modal>
    </div>
  );
}