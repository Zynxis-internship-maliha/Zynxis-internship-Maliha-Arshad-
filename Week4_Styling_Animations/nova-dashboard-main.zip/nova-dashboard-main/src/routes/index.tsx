import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/pages/Dashboard";

const title = "Nebula Analytics — Revenue & growth dashboard";
const description =
  "A premium analytics dashboard for revenue, sales, traffic and service health, with live activity, orders and project progress.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Dashboard,
});
