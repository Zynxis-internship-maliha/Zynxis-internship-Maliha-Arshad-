import {
  Activity,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  CreditCard,
  DollarSign,
  FileText,
  Gauge,
  LayoutDashboard,
  LifeBuoy,
  Rocket,
  Settings,
  ShoppingCart,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";

export const navItems = [
  { label: "Overview", icon: LayoutDashboard, badge: null },
  { label: "Analytics", icon: Activity, badge: null },
  { label: "Customers", icon: Users, badge: "24" },
  { label: "Orders", icon: ShoppingCart, badge: "6" },
  { label: "Billing", icon: CreditCard, badge: null },
  { label: "Reports", icon: FileText, badge: null },
  { label: "Performance", icon: Gauge, badge: null },
] as const;

export const navFooterItems = [
  { label: "Settings", icon: Settings },
  { label: "Support", icon: LifeBuoy },
] as const;

export type Stat = {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  delta: number;
  progress: number;
  icon: typeof DollarSign;
  tone: "primary" | "secondary" | "success" | "warning";
  hint: string;
};

export const stats: Stat[] = [
  {
    label: "Total revenue",
    value: 284920,
    prefix: "$",
    delta: 18.4,
    progress: 78,
    icon: DollarSign,
    tone: "primary",
    hint: "Gross volume across all workspaces this quarter.",
  },
  {
    label: "Active users",
    value: 42871,
    delta: 9.2,
    progress: 64,
    icon: Users,
    tone: "secondary",
    hint: "Unique accounts with a session in the last 30 days.",
  },
  {
    label: "Conversion rate",
    value: 6.4,
    suffix: "%",
    decimals: 1,
    delta: 2.1,
    progress: 52,
    icon: ArrowUpRight,
    tone: "success",
    hint: "Visitors who completed checkout this week.",
  },
  {
    label: "Churn risk",
    value: 1.8,
    suffix: "%",
    decimals: 1,
    delta: -0.6,
    progress: 21,
    icon: Wallet,
    tone: "warning",
    hint: "Accounts predicted to cancel within 60 days.",
  },
];

export const revenueSeries = [
  { month: "Jan", revenue: 18200, forecast: 16400 },
  { month: "Feb", revenue: 21400, forecast: 19800 },
  { month: "Mar", revenue: 19800, forecast: 21200 },
  { month: "Apr", revenue: 26400, forecast: 24100 },
  { month: "May", revenue: 31200, forecast: 28600 },
  { month: "Jun", revenue: 29800, forecast: 31000 },
  { month: "Jul", revenue: 38600, forecast: 34200 },
  { month: "Aug", revenue: 44100, forecast: 39800 },
];

export const salesSeries = [
  { day: "Mon", online: 3200, retail: 1800 },
  { day: "Tue", online: 4100, retail: 2100 },
  { day: "Wed", online: 3800, retail: 2600 },
  { day: "Thu", online: 5200, retail: 2400 },
  { day: "Fri", online: 6100, retail: 3100 },
  { day: "Sat", online: 5400, retail: 3600 },
  { day: "Sun", online: 4700, retail: 2900 },
];

export const trafficSources = [
  { name: "Organic", value: 42, color: "var(--color-primary)" },
  { name: "Referral", value: 24, color: "var(--color-secondary)" },
  { name: "Campaigns", value: 20, color: "var(--color-success)" },
  { name: "Direct", value: 14, color: "var(--color-warning)" },
];

export const performanceMetrics = [
  { label: "Uptime", value: 99.98, suffix: "%", tone: "success" as const },
  { label: "API latency", value: 128, suffix: "ms", tone: "primary" as const },
  { label: "Error rate", value: 0.14, suffix: "%", tone: "warning" as const },
  { label: "Apdex", value: 0.96, suffix: "", tone: "secondary" as const },
];

export const activity = [
  {
    title: "Payment captured",
    detail: "Northwind Labs · $12,400 annual plan",
    time: "2m ago",
    tone: "success" as const,
    icon: BadgeCheck,
  },
  {
    title: "Deployment shipped",
    detail: "api-gateway v4.18.2 rolled out to production",
    time: "26m ago",
    tone: "primary" as const,
    icon: Rocket,
  },
  {
    title: "Usage spike detected",
    detail: "Workspace Atlas exceeded 80% of quota",
    time: "1h ago",
    tone: "warning" as const,
    icon: Activity,
  },
  {
    title: "New enterprise trial",
    detail: "Helios Group started a 14-day pilot",
    time: "3h ago",
    tone: "secondary" as const,
    icon: Sparkles,
  },
  {
    title: "Alert resolved",
    detail: "Latency in eu-central-1 back to baseline",
    time: "5h ago",
    tone: "success" as const,
    icon: Bell,
  },
];

export type OrderStatus = "Paid" | "Pending" | "Refunded" | "Failed";

export type Order = {
  id: string;
  customer: string;
  email: string;
  plan: string;
  amount: number;
  status: OrderStatus;
  date: string;
};

export const orders: Order[] = [
  {
    id: "INV-2481",
    customer: "Amelia Fischer",
    email: "amelia@northwind.io",
    plan: "Scale",
    amount: 1240,
    status: "Paid",
    date: "Aug 03",
  },
  {
    id: "INV-2480",
    customer: "Daniel Osei",
    email: "daniel@helios.co",
    plan: "Growth",
    amount: 480,
    status: "Pending",
    date: "Aug 03",
  },
  {
    id: "INV-2479",
    customer: "Sofia Marino",
    email: "sofia@atlas.dev",
    plan: "Enterprise",
    amount: 5600,
    status: "Paid",
    date: "Aug 02",
  },
  {
    id: "INV-2478",
    customer: "Ken Tanaka",
    email: "ken@brightline.jp",
    plan: "Scale",
    amount: 1240,
    status: "Refunded",
    date: "Aug 02",
  },
  {
    id: "INV-2477",
    customer: "Priya Raman",
    email: "priya@lumen.in",
    plan: "Starter",
    amount: 180,
    status: "Failed",
    date: "Aug 01",
  },
  {
    id: "INV-2476",
    customer: "Marcus Bell",
    email: "marcus@quanta.io",
    plan: "Growth",
    amount: 480,
    status: "Paid",
    date: "Aug 01",
  },
];

export const initialTasks = [
  { id: "t1", title: "Review Q3 pricing experiment", due: "Today", done: false },
  { id: "t2", title: "Approve SOC 2 evidence upload", due: "Today", done: true },
  { id: "t3", title: "Ship usage-based billing beta", due: "Tomorrow", done: false },
  { id: "t4", title: "Sync with Helios onboarding", due: "Friday", done: false },
];

export const projects = [
  { name: "Billing v2 migration", progress: 82, owner: "Platform", tone: "primary" as const },
  { name: "Mobile analytics SDK", progress: 64, owner: "Growth", tone: "secondary" as const },
  { name: "SOC 2 Type II", progress: 45, owner: "Security", tone: "warning" as const },
  { name: "Realtime alerting", progress: 91, owner: "Infra", tone: "success" as const },
];