export type Tone = "primary" | "secondary" | "success" | "warning" | "danger";

/** Single source of truth for tonal styling so no component hardcodes colors. */
export const toneStyles: Record<Tone, { text: string; bg: string; ring: string; stroke: string }> = {
  primary: {
    text: "text-primary",
    bg: "bg-primary/12",
    ring: "ring-primary/30",
    stroke: "var(--color-primary)",
  },
  secondary: {
    text: "text-secondary",
    bg: "bg-secondary/12",
    ring: "ring-secondary/30",
    stroke: "var(--color-secondary)",
  },
  success: {
    text: "text-success",
    bg: "bg-success/12",
    ring: "ring-success/30",
    stroke: "var(--color-success)",
  },
  warning: {
    text: "text-warning",
    bg: "bg-warning/12",
    ring: "ring-warning/30",
    stroke: "var(--color-warning)",
  },
  danger: {
    text: "text-destructive",
    bg: "bg-destructive/12",
    ring: "ring-destructive/30",
    stroke: "var(--color-destructive)",
  },
};