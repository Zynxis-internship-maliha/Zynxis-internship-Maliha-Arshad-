import type { Variants } from "motion/react";

/** Shared easing + timing so every surface animates with one voice. */
export const EASE_OUT = [0.22, 1, 0.36, 1] as const;

export const pageEnter: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: "easeOut", staggerChildren: 0.08 },
  },
};

export const sectionReveal: Variants = {
  hidden: { opacity: 0, y: 26 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: EASE_OUT } },
};

export const staggerGrid: Variants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
};

export const cardEnter: Variants = {
  hidden: { opacity: 0, y: 24, scale: 0.97 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.5, ease: EASE_OUT } },
};

export const rowEnter: Variants = {
  hidden: { opacity: 0, y: 14 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: EASE_OUT } },
};

export const sidebarEnter: Variants = {
  hidden: { x: -32, opacity: 0 },
  visible: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.55, ease: EASE_OUT, staggerChildren: 0.05, delayChildren: 0.15 },
  },
};

export const navbarEnter: Variants = {
  hidden: { y: -28, opacity: 0 },
  visible: { y: 0, opacity: 1, transition: { duration: 0.5, ease: EASE_OUT } },
};

export const popEnter: Variants = {
  hidden: { opacity: 0, scale: 0.94, y: -6 },
  visible: { opacity: 1, scale: 1, y: 0, transition: { duration: 0.18, ease: EASE_OUT } },
  exit: { opacity: 0, scale: 0.96, y: -4, transition: { duration: 0.14 } },
};

/** Viewport config for "animate once when scrolled into view". */
export const revealOnce = { once: true, amount: 0.25 } as const;