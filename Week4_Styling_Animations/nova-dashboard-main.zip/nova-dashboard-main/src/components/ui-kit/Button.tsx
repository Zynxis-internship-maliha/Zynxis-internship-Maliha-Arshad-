import { motion } from "motion/react";
import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex shrink-0 items-center justify-center gap-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        gradient:
          "bg-linear-to-r from-primary to-secondary text-primary-foreground shadow-[0_10px_30px_-12px_var(--color-primary)] hover:shadow-[0_16px_40px_-12px_var(--color-primary)]",
        solid: "bg-primary text-primary-foreground hover:bg-primary/90",
        glass: "glass text-foreground hover:bg-card/80",
        outline: "border border-border bg-transparent text-foreground hover:bg-card/60",
        ghost: "bg-transparent text-muted-foreground hover:bg-card/60 hover:text-foreground",
      },
      size: {
        sm: "h-9 px-3",
        md: "h-11 px-4",
        lg: "h-12 px-6 text-base",
        icon: "h-11 w-11 min-h-11 min-w-11 rounded-xl",
      },
    },
    defaultVariants: { variant: "solid", size: "md" },
  },
);

type ButtonProps = ComponentPropsWithoutRef<typeof motion.button> &
  VariantProps<typeof buttonVariants> & { children?: ReactNode };

export function Button({ className, variant, size, ...props }: ButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 24 }}
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}

export { buttonVariants };