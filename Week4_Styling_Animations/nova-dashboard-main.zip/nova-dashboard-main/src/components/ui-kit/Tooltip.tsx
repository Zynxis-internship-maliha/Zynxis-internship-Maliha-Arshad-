import { AnimatePresence, motion } from "motion/react";
import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type TooltipProps = {
  label: string;
  children: ReactNode;
  side?: "top" | "right";
  className?: string;
};

/** Lightweight animated tooltip that also opens on keyboard focus. */
export function Tooltip({ label, children, side = "top", className }: TooltipProps) {
  const [open, setOpen] = useState(false);

  return (
    <span
      className={cn("relative inline-flex", className)}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      <AnimatePresence>
        {open && (
          <motion.span
            role="tooltip"
            initial={{ opacity: 0, scale: 0.92, y: side === "top" ? 4 : 0, x: side === "right" ? -4 : 0 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.16, ease: [0.22, 1, 0.36, 1] }}
            className={cn(
              "glass pointer-events-none absolute z-50 w-max max-w-[15rem] rounded-lg px-2.5 py-1.5 text-xs font-medium text-foreground",
              side === "top"
                ? "bottom-[calc(100%+8px)] left-1/2 -translate-x-1/2"
                : "left-[calc(100%+10px)] top-1/2 -translate-y-1/2",
            )}
          >
            {label}
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
}