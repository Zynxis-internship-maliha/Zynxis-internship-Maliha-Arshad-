import { cn } from "@/lib/utils";

/** Shimmering placeholder used while lazy sections hydrate. */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "relative overflow-hidden rounded-xl bg-muted/60",
        "after:absolute after:inset-0 after:animate-[shimmer_1.6s_infinite] after:bg-linear-to-r after:from-transparent after:via-foreground/10 after:to-transparent",
        className,
      )}
    />
  );
}

export function ChartSkeleton({ height = 260 }: { height?: number }) {
  return (
    <div className="space-y-3" style={{ minHeight: height }}>
      <Skeleton className="h-4 w-32" />
      <div className="flex items-end gap-2" style={{ height: height - 40 }}>
        {["h-[45%]", "h-[70%]", "h-[55%]", "h-[85%]", "h-[62%]", "h-[92%]", "h-[74%]"].map((h) => (
          <Skeleton key={h} className={`flex-1 ${h}`} />
        ))}
      </div>
    </div>
  );
}