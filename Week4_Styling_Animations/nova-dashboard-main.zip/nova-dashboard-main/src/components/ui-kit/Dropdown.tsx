import { AnimatePresence, motion } from "motion/react";
import { useRef, useState, type ReactNode } from "react";
import { popEnter } from "@/animations/variants";
import { useClickOutside } from "@/hooks/useClickOutside";
import { cn } from "@/lib/utils";

type DropdownProps = {
  trigger: (state: { open: boolean; toggle: () => void }) => ReactNode;
  children: (close: () => void) => ReactNode;
  align?: "left" | "right";
  label: string;
  panelClassName?: string;
};

export function Dropdown({ trigger, children, align = "right", label, panelClassName }: DropdownProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  useClickOutside(containerRef, () => setOpen(false), open);

  return (
    <div ref={containerRef} className="relative">
      {trigger({ open, toggle: () => setOpen((v) => !v) })}
      <AnimatePresence>
        {open && (
          <motion.div
            role="menu"
            aria-label={label}
            variants={popEnter}
            initial="hidden"
            animate="visible"
            exit="exit"
            className={cn(
              "glass absolute top-[calc(100%+10px)] z-50 w-64 overflow-hidden rounded-2xl p-2",
              align === "right" ? "right-0" : "left-0",
              panelClassName,
            )}
          >
            {children(() => setOpen(false))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function DropdownItem({
  children,
  onSelect,
  icon: Icon,
}: {
  children: ReactNode;
  onSelect?: () => void;
  icon?: React.ComponentType<{ className?: string }>;
}) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onSelect}
      className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-sm text-muted-foreground transition-colors outline-none hover:bg-primary/10 hover:text-foreground focus-visible:bg-primary/10 focus-visible:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
    >
      {Icon ? <Icon className="h-4 w-4 shrink-0" /> : null}
      <span className="truncate">{children}</span>
    </button>
  );
}