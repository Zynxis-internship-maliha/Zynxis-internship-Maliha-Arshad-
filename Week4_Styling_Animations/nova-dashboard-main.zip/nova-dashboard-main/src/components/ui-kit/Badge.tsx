import { motion } from "motion/react";
import { cn } from "@/lib/utils";
import { toneStyles, type Tone } from "@/utils/tones";

export function Badge({
  children,
  tone = "primary",
  pulse = false,
  className,
}: {
  children: React.ReactNode;
  tone?: Tone;
  pulse?: boolean;
  className?: string;
}) {
  const t = toneStyles[tone];
  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 380, damping: 22 }}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset",
        t.bg,
        t.text,
        t.ring,
        className,
      )}
    >
      {pulse ? (
        <motion.span
          className="h-1.5 w-1.5 rounded-full bg-current"
          animate={{ opacity: [1, 0.35, 1], scale: [1, 0.8, 1] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        />
      ) : null}
      {children}
    </motion.span>
  );
}