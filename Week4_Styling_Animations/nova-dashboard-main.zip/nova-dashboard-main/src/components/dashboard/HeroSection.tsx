import { motion } from "motion/react";
import { ArrowUpRight, Sparkles, Zap } from "lucide-react";
import { EASE_OUT } from "@/animations/variants";
import { Badge } from "@/components/ui-kit/Badge";
import { Button } from "@/components/ui-kit/Button";

export function HeroSection({ onPrimaryAction }: { onPrimaryAction: () => void }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: EASE_OUT }}
      className="glass gradient-border mesh-bg relative overflow-hidden rounded-3xl p-6 sm:p-8"
      aria-labelledby="welcome-heading"
    >
      <motion.span
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 -right-16 h-64 w-64 rounded-full bg-primary/20 blur-3xl"
        animate={{ opacity: [0.45, 0.75, 0.45], scale: [1, 1.08, 1] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <div className="relative grid gap-6 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
        <div className="min-w-0">
          <Badge tone="secondary" pulse>
            All systems operational
          </Badge>
          <h1
            id="welcome-heading"
            className="text-gradient mt-4 text-2xl leading-tight font-bold sm:text-3xl lg:text-4xl"
          >
            Good morning, Aisha
          </h1>
          <p className="mt-3 max-w-xl text-sm text-muted-foreground sm:text-base">
            Revenue is up 18.4% against last quarter and churn risk is at a twelve-month low. Here is
            what needs your attention today.
          </p>
          <dl className="mt-6 flex flex-wrap gap-x-8 gap-y-3">
            {[
              { label: "Open pipeline", value: "$1.24M" },
              { label: "Deals closing", value: "18 this week" },
              { label: "NPS", value: "62" },
            ].map((item) => (
              <div key={item.label} className="min-w-0">
                <dt className="text-xs tracking-wide text-muted-foreground uppercase">{item.label}</dt>
                <dd className="mt-1 text-sm font-semibold text-foreground">{item.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button variant="gradient" size="lg" onClick={onPrimaryAction}>
            <Zap className="h-4 w-4" />
            Generate report
          </Button>
          <Button variant="glass" size="lg">
            <Sparkles className="h-4 w-4" />
            Ask AI
            <ArrowUpRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.section>
  );
}