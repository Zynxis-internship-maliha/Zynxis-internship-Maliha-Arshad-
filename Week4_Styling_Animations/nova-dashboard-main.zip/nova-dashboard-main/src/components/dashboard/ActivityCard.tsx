import { motion } from "motion/react";
import { staggerGrid, rowEnter } from "@/animations/variants";
import { activity } from "@/utils/dashboard-data";
import { toneStyles } from "@/utils/tones";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { Button } from "@/components/ui-kit/Button";

export function ActivityCard() {
  return (
    <SectionCard
      title="Activity timeline"
      description="Everything happening across your workspace"
      action={
        <Button variant="ghost" size="sm">
          View all
        </Button>
      }
    >
      <motion.ol
        variants={staggerGrid}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        className="relative space-y-1 before:absolute before:top-2 before:bottom-2 before:left-[21px] before:w-px before:bg-border"
      >
        {activity.map((item) => {
          const tone = toneStyles[item.tone];
          return (
            <motion.li
              key={item.title}
              variants={rowEnter}
              className="group relative flex gap-4 rounded-2xl p-2.5 transition-colors hover:bg-foreground/4"
            >
              <span
                className={`relative z-10 grid h-11 w-11 shrink-0 place-items-center rounded-xl ring-1 ring-inset transition-transform duration-200 group-hover:scale-110 ${tone.bg} ${tone.text} ${tone.ring}`}
              >
                <item.icon className="h-[18px] w-[18px]" aria-hidden="true" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline justify-between gap-3">
                  <span className="truncate text-sm font-semibold text-foreground">{item.title}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{item.time}</span>
                </span>
                <span className="mt-0.5 block truncate text-xs text-muted-foreground sm:text-sm">
                  {item.detail}
                </span>
              </span>
            </motion.li>
          );
        })}
      </motion.ol>
    </SectionCard>
  );
}