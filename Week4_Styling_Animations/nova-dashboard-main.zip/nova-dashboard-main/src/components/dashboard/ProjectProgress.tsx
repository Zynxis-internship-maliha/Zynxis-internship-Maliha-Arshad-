import { motion } from "motion/react";
import { projects } from "@/utils/dashboard-data";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { toneStyles } from "@/utils/tones";

export function ProjectProgress() {
  return (
    <SectionCard title="Project progress" description="Active initiatives this quarter">
      <ul className="space-y-5">
        {projects.map((project, index) => (
          <li key={project.name}>
            <div className="flex items-baseline justify-between gap-3">
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium text-foreground">
                  {project.name}
                </span>
                <span className="block truncate text-xs text-muted-foreground">{project.owner}</span>
              </span>
              <span className={`shrink-0 text-sm font-semibold tabular-nums ${toneStyles[project.tone].text}`}>
                {project.progress}%
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-foreground/8">
              <motion.div
                className="h-full rounded-full"
                style={{ background: toneStyles[project.tone].stroke }}
                initial={{ width: 0 }}
                whileInView={{ width: `${project.progress}%` }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: index * 0.1 }}
              />
            </div>
          </li>
        ))}
      </ul>
    </SectionCard>
  );
}