import { ClientOnly } from "@tanstack/react-router";
import { Suspense, lazy } from "react";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { ChartSkeleton } from "@/components/ui-kit/Skeleton";

const charts = {
  revenue: lazy(() => import("@/components/dashboard/charts/RevenueChart")),
  sales: lazy(() => import("@/components/dashboard/charts/SalesChart")),
  traffic: lazy(() => import("@/components/dashboard/charts/TrafficChart")),
};

type ChartCardProps = {
  chart: keyof typeof charts;
  title: string;
  description?: string;
  action?: React.ReactNode;
  footer?: React.ReactNode;
  height?: number;
  className?: string;
};

/** Charts are heavy: they are code-split and only mounted on the client. */
export function ChartCard({
  chart,
  title,
  description,
  action,
  footer,
  height = 280,
  className,
}: ChartCardProps) {
  const Chart = charts[chart];

  return (
    <SectionCard title={title} description={description} action={action} className={className}>
      <div className="min-w-0">
        <ClientOnly fallback={<ChartSkeleton height={height} />}>
          <Suspense fallback={<ChartSkeleton height={height} />}>
            <Chart />
          </Suspense>
        </ClientOnly>
      </div>
      {footer ? <div className="mt-4">{footer}</div> : null}
    </SectionCard>
  );
}