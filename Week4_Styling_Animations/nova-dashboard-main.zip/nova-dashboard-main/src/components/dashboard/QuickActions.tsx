import { motion } from "motion/react";
import { FileText, Mail, ShieldCheck, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { cardEnter, staggerGrid } from "@/animations/variants";
import { SectionCard } from "@/components/dashboard/SectionCard";

const actions = [
  { label: "Invite teammate", icon: UserPlus, message: "Invite link copied to clipboard" },
  { label: "Send invoice", icon: Mail, message: "Invoice queued for delivery" },
  { label: "New report", icon: FileText, message: "Report draft created" },
  { label: "Run audit", icon: ShieldCheck, message: "Security audit started" },
];

export function QuickActions() {
  return (
    <SectionCard title="Quick actions" description="One tap away from the common flows">
      <motion.div
        variants={staggerGrid}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="grid grid-cols-2 gap-3"
      >
        {actions.map((action) => (
          <motion.button
            key={action.label}
            type="button"
            variants={cardEnter}
            whileHover={{ y: -4, scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => toast.success(action.message)}
            className="flex min-h-11 flex-col items-start gap-2.5 rounded-2xl border border-border/70 bg-surface/50 p-4 text-left transition-colors outline-none hover:border-primary/45 hover:bg-primary/8 focus-visible:ring-2 focus-visible:ring-ring"
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-primary/25 to-secondary/20 text-primary">
              <action.icon className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="text-sm font-medium text-foreground">{action.label}</span>
          </motion.button>
        ))}
      </motion.div>
    </SectionCard>
  );
}