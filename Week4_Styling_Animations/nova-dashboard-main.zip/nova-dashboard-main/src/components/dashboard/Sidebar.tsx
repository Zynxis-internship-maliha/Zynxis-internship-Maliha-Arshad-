import { AnimatePresence, motion } from "motion/react";
import { ChevronLeft, Command, X } from "lucide-react";
import { useState } from "react";
import { EASE_OUT, sidebarEnter } from "@/animations/variants";
import { navFooterItems, navItems } from "@/utils/dashboard-data";
import { Tooltip } from "@/components/ui-kit/Tooltip";
import { cn } from "@/lib/utils";

type SidebarProps = {
  mobileOpen: boolean;
  onMobileClose: () => void;
};

export function Sidebar({ mobileOpen, onMobileClose }: SidebarProps) {
  const [active, setActive] = useState<string>(navItems[0].label);
  const [collapsed, setCollapsed] = useState(false);

  const nav = (
    <motion.nav
      variants={sidebarEnter}
      initial="hidden"
      animate="visible"
      aria-label="Main navigation"
      className={cn(
        "flex h-full flex-col gap-6 border-r border-border bg-sidebar/80 p-4 backdrop-blur-xl transition-[width] duration-300",
        collapsed ? "w-[84px]" : "w-[268px]",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <a
          href="/"
          className="flex min-w-0 items-center gap-3 rounded-xl outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-linear-to-br from-primary to-secondary text-primary-foreground shadow-[0_8px_24px_-8px_var(--color-primary)]">
            <Command className="h-5 w-5" aria-hidden="true" />
          </span>
          {!collapsed && (
            <span className="min-w-0">
              <span className="block truncate text-sm font-semibold text-foreground">Nebula</span>
              <span className="block truncate text-xs text-muted-foreground">Growth workspace</span>
            </span>
          )}
        </a>
        <button
          type="button"
          onClick={() => setCollapsed((v) => !v)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-pressed={collapsed}
          className="hidden h-9 w-9 shrink-0 place-items-center rounded-xl border border-border text-muted-foreground transition-colors outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring lg:grid"
        >
          <motion.span animate={{ rotate: collapsed ? 180 : 0 }} transition={{ duration: 0.3 }}>
            <ChevronLeft className="h-4 w-4" />
          </motion.span>
        </button>
        <button
          type="button"
          onClick={onMobileClose}
          aria-label="Close navigation"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-border text-muted-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring lg:hidden"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <ul className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = item.label === active;
          const button = (
            <button
              type="button"
              onClick={() => setActive(item.label)}
              aria-current={isActive ? "page" : undefined}
              className={cn(
                "group relative flex w-full min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring",
                isActive ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                collapsed && "justify-center px-0",
              )}
            >
              {isActive && (
                <motion.span
                  layoutId="sidebar-active"
                  transition={{ duration: 0.35, ease: EASE_OUT }}
                  className="absolute inset-0 rounded-xl bg-primary/15 ring-1 ring-inset ring-primary/30 shadow-[inset_0_0_24px_-8px_var(--color-primary)]"
                  aria-hidden="true"
                />
              )}
              <span
                className={cn(
                  "absolute inset-0 rounded-xl bg-foreground/0 transition-colors duration-200",
                  !isActive && "group-hover:bg-foreground/5",
                )}
                aria-hidden="true"
              />
              <motion.span
                whileHover={{ scale: 1.18, rotate: -6 }}
                transition={{ type: "spring", stiffness: 400, damping: 18 }}
                className={cn("relative z-10 shrink-0", isActive && "text-primary")}
              >
                <item.icon className="h-[18px] w-[18px]" aria-hidden="true" />
              </motion.span>
              {!collapsed && <span className="relative z-10 truncate">{item.label}</span>}
              {!collapsed && item.badge ? (
                <span className="relative z-10 ml-auto rounded-full bg-secondary/15 px-2 py-0.5 text-[11px] font-semibold text-secondary">
                  {item.badge}
                </span>
              ) : null}
            </button>
          );

          return (
            <motion.li key={item.label} variants={sidebarEnter}>
              {collapsed ? (
                <Tooltip label={item.label} side="right" className="w-full">
                  {button}
                </Tooltip>
              ) : (
                button
              )}
            </motion.li>
          );
        })}
      </ul>

      <div className="space-y-1 border-t border-border pt-3">
        {navFooterItems.map((item) => (
          <button
            key={item.label}
            type="button"
            className={cn(
              "flex w-full min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium text-muted-foreground transition-colors outline-none hover:bg-foreground/5 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",
              collapsed && "justify-center px-0",
            )}
          >
            <item.icon className="h-[18px] w-[18px] shrink-0" aria-hidden="true" />
            {!collapsed && <span className="truncate">{item.label}</span>}
          </button>
        ))}
      </div>
    </motion.nav>
  );

  return (
    <>
      <aside className="sticky top-0 hidden h-dvh shrink-0 lg:block">{nav}</aside>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-90 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <button
              type="button"
              aria-label="Close navigation overlay"
              onClick={onMobileClose}
              className="absolute inset-0 bg-background/70 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ duration: 0.32, ease: EASE_OUT }}
              className="relative h-dvh w-[280px]"
            >
              {nav}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}