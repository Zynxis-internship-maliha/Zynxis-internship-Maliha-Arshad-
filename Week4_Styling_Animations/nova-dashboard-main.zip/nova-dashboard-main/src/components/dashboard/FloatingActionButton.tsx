import { motion } from "motion/react";
import { Sparkles } from "lucide-react";
import { Tooltip } from "@/components/ui-kit/Tooltip";

export function FloatingActionButton({ onClick }: { onClick: () => void }) {
  return (
    <div className="fixed right-5 bottom-5 z-70 sm:right-8 sm:bottom-8">
      <Tooltip label="Ask Nebula AI">
        <motion.button
          type="button"
          onClick={onClick}
          aria-label="Ask Nebula AI"
          initial={{ opacity: 0, scale: 0.6, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ delay: 0.8, type: "spring", stiffness: 300, damping: 20 }}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.93 }}
          className="grid h-14 w-14 place-items-center rounded-2xl bg-linear-to-br from-primary to-secondary text-primary-foreground shadow-[0_18px_40px_-14px_var(--color-primary)] outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Sparkles className="h-6 w-6" aria-hidden="true" />
        </motion.button>
      </Tooltip>
    </div>
  );
}