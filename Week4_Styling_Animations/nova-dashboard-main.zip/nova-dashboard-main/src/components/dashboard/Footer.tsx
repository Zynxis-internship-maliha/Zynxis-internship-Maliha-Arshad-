import { Command } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-2 border-t border-border pt-6 pb-8">
      <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-linear-to-br from-primary to-secondary text-primary-foreground">
            <Command className="h-4 w-4" aria-hidden="true" />
          </span>
          <p className="truncate text-xs text-muted-foreground">
            Nebula Analytics · © {new Date().getFullYear()} · All systems operational
          </p>
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-5 gap-y-2 text-xs">
          {["Docs", "Changelog", "Status", "Privacy"].map((link) => (
            <a
              key={link}
              href="/"
              className="rounded text-muted-foreground transition-colors outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
            >
              {link}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}