import { motion } from "motion/react";
import { ArrowUpDown, Download } from "lucide-react";
import { useMemo, useState } from "react";
import { rowEnter, staggerGrid } from "@/animations/variants";
import { orders, type Order, type OrderStatus } from "@/utils/dashboard-data";
import { formatCurrency } from "@/utils/format";
import { Badge } from "@/components/ui-kit/Badge";
import { Button } from "@/components/ui-kit/Button";
import { SectionCard } from "@/components/dashboard/SectionCard";
import type { Tone } from "@/utils/tones";

const statusTone: Record<OrderStatus, Tone> = {
  Paid: "success",
  Pending: "warning",
  Refunded: "secondary",
  Failed: "danger",
};

type SortKey = "customer" | "amount" | "status";

export function OrdersTable({
  onExport,
  className,
}: {
  onExport: () => void;
  className?: string | undefined;
}) {
  const [sortKey, setSortKey] = useState<SortKey>("amount");
  const [asc, setAsc] = useState(false);

  const sorted = useMemo(() => {
    const copy = [...orders];
    copy.sort((a: Order, b: Order) => {
      const left = a[sortKey];
      const right = b[sortKey];
      if (typeof left === "number" && typeof right === "number") return left - right;
      return String(left).localeCompare(String(right));
    });
    return asc ? copy : copy.reverse();
  }, [sortKey, asc]);

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) setAsc((v) => !v);
    else {
      setSortKey(key);
      setAsc(true);
    }
  };

  const headerButton = (key: SortKey, label: string, alignRight = false) => (
    <button
      type="button"
      onClick={() => toggleSort(key)}
      aria-label={`Sort by ${label}`}
      className={`inline-flex items-center gap-1.5 rounded-md text-xs font-semibold tracking-wide uppercase transition-colors outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring ${
        sortKey === key ? "text-foreground" : "text-muted-foreground"
      } ${alignRight ? "ml-auto" : ""}`}
    >
      {label}
      <motion.span
        animate={{ rotate: sortKey === key && !asc ? 180 : 0 }}
        transition={{ duration: 0.25 }}
        className="inline-flex"
      >
        <ArrowUpDown className="h-3.5 w-3.5" aria-hidden="true" />
      </motion.span>
    </button>
  );

  return (
    <SectionCard
      title="Recent orders"
      description="Latest invoices across every plan"
      action={
        <Button variant="outline" size="sm" onClick={onExport}>
          <Download className="h-4 w-4" />
          <span className="hidden sm:inline">Export</span>
        </Button>
      }
      bodyClassName="overflow-x-auto"
      className={className}
    >
      <table className="w-full min-w-[620px] border-collapse text-sm">
        <caption className="sr-only">Recent orders, sortable by customer, amount and status</caption>
        <thead>
          <tr className="border-b border-border">
            <th scope="col" className="pb-3 text-left">
              {headerButton("customer", "Customer")}
            </th>
            <th scope="col" className="pb-3 text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Plan
            </th>
            <th scope="col" className="pb-3 text-left">
              {headerButton("status", "Status")}
            </th>
            <th scope="col" className="pb-3 text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Date
            </th>
            <th scope="col" className="flex justify-end pb-3">
              {headerButton("amount", "Amount", true)}
            </th>
          </tr>
        </thead>
        <motion.tbody
          variants={staggerGrid}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
        >
          {sorted.map((order) => (
            <motion.tr
              key={order.id}
              variants={rowEnter}
              className="border-b border-border/60 transition-colors last:border-0 hover:bg-primary/6"
            >
              <td className="py-3.5 pr-4">
                <span className="block truncate font-medium text-foreground">{order.customer}</span>
                <span className="block truncate text-xs text-muted-foreground">{order.email}</span>
              </td>
              <td className="py-3.5 pr-4 text-muted-foreground">{order.plan}</td>
              <td className="py-3.5 pr-4">
                <Badge tone={statusTone[order.status]}>{order.status}</Badge>
              </td>
              <td className="py-3.5 pr-4 text-muted-foreground">{order.date}</td>
              <td className="py-3.5 text-right font-semibold text-foreground tabular-nums">
                {formatCurrency(order.amount)}
              </td>
            </motion.tr>
          ))}
        </motion.tbody>
      </table>
    </SectionCard>
  );
}