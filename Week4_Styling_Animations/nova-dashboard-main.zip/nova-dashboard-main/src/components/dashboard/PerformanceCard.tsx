import { motion } from "motion/react";
import { cardEnter, staggerGrid } from "@/animations/variants";
import { performanceMetrics } from "@/utils/dashboard-data";
import { ProgressRing } from "@/components/ui-kit/ProgressRing";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { Badge } from "@/components/ui-kit/Badge";
import { toneStyles } from "@/utils/tones";

const ringValue = (label: string, value: number) => {
  if (label === "Uptime") return value;
  if (label === "API latency") return Math.min(100, 100 - value / 5);
  if (label === "Error rate") return Math.max(6, 100 - value * 200);
  return value * 100;
};

export function PerformanceCard() {
  return (
    <SectionCard
      title="Performance metrics"
      description="Rolling 24-hour service health"
      action={<Badge tone="success" pulse>Healthy</Badge>}
    >
      <motion.ul
        variants={staggerGrid}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
        className="grid grid-cols-2 gap-4"
      >
        {performanceMetrics.map((metric) => (
          <motion.li
            key={metric.label}
            variants={cardEnter}
            whileHover={{ y: -4 }}
            className="flex flex-col items-center gap-3 rounded-2xl border border-border/70 p-4 text-center transition-colors hover:border-primary/40"
          >
            <ProgressRing
              value={ringValue(metric.label, metric.value)}
              tone={metric.tone}
              size={88}
              label={`${metric.label}: ${metric.value}${metric.suffix}`}
            >
              <span className={`text-sm font-bold tabular-nums ${toneStyles[metric.tone].text}`}>
                {metric.value}
                {metric.suffix}
              </span>
            </ProgressRing>
            <span className="text-xs font-medium text-muted-foreground">{metric.label}</span>
          </motion.li>
        ))}
      </motion.ul>
    </SectionCard>
  );
}