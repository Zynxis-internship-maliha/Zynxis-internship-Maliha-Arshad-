import { motion } from "motion/react";
import { useState } from "react";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { cn } from "@/lib/utils";

const settings = [
  { id: "weekly", label: "Weekly digest", hint: "Every Monday at 8:00", on: true },
  { id: "anomaly", label: "Anomaly alerts", hint: "Notify on unusual revenue swings", on: true },
  { id: "beta", label: "Beta features", hint: "Opt into experimental dashboards", on: false },
];

export function SettingsCard() {
  const [state, setState] = useState(() =>
    Object.fromEntries(settings.map((s) => [s.id, s.on])) as Record<string, boolean>,
  );

  return (
    <SectionCard title="Settings" description="Workspace notification preferences">
      <ul className="space-y-3">
        {settings.map((setting) => {
          const on = state[setting.id];
          return (
            <li
              key={setting.id}
              className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 rounded-2xl border border-border/70 p-3.5"
            >
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium text-foreground">
                  {setting.label}
                </span>
                <span className="block truncate text-xs text-muted-foreground">{setting.hint}</span>
              </span>
              <button
                type="button"
                role="switch"
                aria-checked={on}
                aria-label={setting.label}
                onClick={() => setState((prev) => ({ ...prev, [setting.id]: !prev[setting.id] }))}
                className={cn(
                  "relative h-6 w-11 shrink-0 rounded-full transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                  on ? "bg-linear-to-r from-primary to-secondary" : "bg-foreground/15",
                )}
              >
                <motion.span
                  layout
                  transition={{ type: "spring", stiffness: 500, damping: 32 }}
                  className={cn(
                    "absolute top-1 h-4 w-4 rounded-full bg-foreground shadow",
                    on ? "left-6" : "left-1",
                  )}
                />
              </button>
            </li>
          );
        })}
      </ul>
    </SectionCard>
  );
}