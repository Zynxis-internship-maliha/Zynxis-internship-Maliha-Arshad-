import { motion } from "motion/react";
import { sectionReveal, revealOnce } from "@/animations/variants";
import { cn } from "@/lib/utils";

type SectionCardProps = {
  title: string;
  description?: string | undefined;
  action?: React.ReactNode | undefined;
  children: React.ReactNode;
  className?: string | undefined;
  bodyClassName?: string | undefined;
};

/** Glass panel wrapper: reveals once on scroll and owns the shared header layout. */
export function SectionCard({
  title,
  description,
  action,
  children,
  className,
  bodyClassName,
}: SectionCardProps) {
  return (
    <motion.section
      variants={sectionReveal}
      initial="hidden"
      whileInView="visible"
      viewport={revealOnce}
      className={cn(
        "glass gradient-border flex flex-col rounded-3xl p-5 transition-shadow duration-300 hover:shadow-[0_28px_60px_-40px_var(--color-primary)] sm:p-6",
        className,
      )}
    >
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <h2 className="truncate text-base font-semibold text-foreground sm:text-lg">{title}</h2>
          {description ? (
            <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{description}</p>
          ) : null}
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </header>
      <div className={cn("mt-5 min-w-0 flex-1", bodyClassName)}>{children}</div>
    </motion.section>
  );
}