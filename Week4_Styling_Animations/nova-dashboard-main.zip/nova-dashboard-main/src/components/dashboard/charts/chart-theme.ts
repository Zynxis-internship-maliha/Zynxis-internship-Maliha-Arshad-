export const axisStyle = {
  stroke: "var(--color-border)",
  tick: { fill: "var(--color-muted-foreground)", fontSize: 12 },
  tickLine: false,
  axisLine: false,
} as const;

export const chartTooltipStyle = {
  cursor: { stroke: "var(--color-primary)", strokeOpacity: 0.35 },
  contentStyle: {
    background: "color-mix(in oklab, var(--color-surface) 92%, transparent)",
    border: "1px solid var(--color-border)",
    borderRadius: "0.875rem",
    color: "var(--color-foreground)",
    fontSize: 12,
    boxShadow: "0 18px 40px -24px rgb(0 0 0 / 0.8)",
  },
  labelStyle: { color: "var(--color-muted-foreground)", marginBottom: 4 },
  itemStyle: { color: "var(--color-foreground)" },
} as const;