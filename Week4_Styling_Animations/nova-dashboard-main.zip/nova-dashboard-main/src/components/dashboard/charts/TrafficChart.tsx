import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip as ReTooltip } from "recharts";
import { trafficSources } from "@/utils/dashboard-data";
import { chartTooltipStyle } from "./chart-theme";

export default function TrafficChart() {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <PieChart>
        <ReTooltip {...chartTooltipStyle} formatter={(value: number) => [`${value}%`, "Share"]} />
        <Pie
          data={trafficSources}
          dataKey="value"
          nameKey="name"
          innerRadius={62}
          outerRadius={92}
          paddingAngle={3}
          stroke="transparent"
        >
          {trafficSources.map((source) => (
            <Cell key={source.name} fill={source.color} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );
}