import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { revenueSeries } from "@/utils/dashboard-data";
import { formatCompact } from "@/utils/format";
import { chartTooltipStyle, axisStyle } from "./chart-theme";

export default function RevenueChart() {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={revenueSeries} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
        <defs>
          <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.5} />
            <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="forecastFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-secondary)" stopOpacity={0.25} />
            <stop offset="100%" stopColor="var(--color-secondary)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="4 6" stroke="var(--color-border)" vertical={false} />
        <XAxis dataKey="month" {...axisStyle} />
        <YAxis tickFormatter={(v: number) => formatCompact(v)} {...axisStyle} />
        <ReTooltip
          {...chartTooltipStyle}
          formatter={(value: number, name: string) => [formatCompact(value), name]}
        />
        <Area
          type="monotone"
          dataKey="forecast"
          name="Forecast"
          stroke="var(--color-secondary)"
          strokeDasharray="5 5"
          strokeWidth={2}
          fill="url(#forecastFill)"
        />
        <Area
          type="monotone"
          dataKey="revenue"
          name="Revenue"
          stroke="var(--color-primary)"
          strokeWidth={2.5}
          fill="url(#revenueFill)"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}