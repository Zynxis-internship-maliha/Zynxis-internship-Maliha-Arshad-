import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { salesSeries } from "@/utils/dashboard-data";
import { formatCompact } from "@/utils/format";
import { axisStyle, chartTooltipStyle } from "./chart-theme";

export default function SalesChart() {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={salesSeries} margin={{ top: 10, right: 8, left: -18, bottom: 0 }} barGap={6}>
        <CartesianGrid strokeDasharray="4 6" stroke="var(--color-border)" vertical={false} />
        <XAxis dataKey="day" {...axisStyle} />
        <YAxis tickFormatter={(v: number) => formatCompact(v)} {...axisStyle} />
        <ReTooltip
          {...chartTooltipStyle}
          cursor={{ fill: "color-mix(in oklab, var(--color-primary) 10%, transparent)" }}
          formatter={(value: number, name: string) => [formatCompact(value), name]}
        />
        <Legend
          wrapperStyle={{ fontSize: 12, color: "var(--color-muted-foreground)", paddingTop: 8 }}
        />
        <Bar dataKey="online" name="Online" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
        <Bar dataKey="retail" name="Retail" fill="var(--color-secondary)" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}