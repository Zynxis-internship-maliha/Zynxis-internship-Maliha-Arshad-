import { motion } from "motion/react";
import { TrendingDown, TrendingUp } from "lucide-react";
import { useRef } from "react";
import { cardEnter } from "@/animations/variants";
import { useCountUp } from "@/hooks/useCountUp";
import { formatNumber } from "@/utils/format";
import { toneStyles } from "@/utils/tones";
import { Tooltip } from "@/components/ui-kit/Tooltip";
import type { Stat } from "@/utils/dashboard-data";

export function StatCard({ stat }: { stat: Stat }) {
  const ref = useRef<HTMLDivElement>(null);
  const decimals = stat.decimals ?? 0;
  const animated = useCountUp(stat.value, ref, { decimals });
  const tone = toneStyles[stat.tone];
  const positive = stat.delta >= 0;
  const Trend = positive ? TrendingUp : TrendingDown;

  return (
    <motion.article
      ref={ref}
      variants={cardEnter}
      whileHover={{ scale: 1.04, y: -6 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="glass gradient-border group relative overflow-hidden rounded-3xl p-5 hover:shadow-[0_26px_60px_-30px_var(--color-primary)]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium tracking-wide text-muted-foreground uppercase">
            {stat.label}
          </p>
          <p className="mt-2 text-2xl font-bold text-foreground tabular-nums sm:text-3xl">
            {stat.prefix}
            {decimals > 0 ? animated.toFixed(decimals) : formatNumber(Math.round(animated))}
            {stat.suffix}
          </p>
        </div>
        <Tooltip label={stat.hint}>
          <motion.span
            whileHover={{ rotate: 8, scale: 1.1 }}
            className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ring-1 ring-inset ${tone.bg} ${tone.text} ${tone.ring}`}
          >
            <stat.icon className="h-5 w-5" aria-hidden="true" />
          </motion.span>
        </Tooltip>
      </div>

      <div className="mt-4 flex items-center gap-2 text-xs">
        <span
          className={`inline-flex items-center gap-1 rounded-full px-2 py-1 font-semibold ${
            positive ? "bg-success/12 text-success" : "bg-destructive/12 text-destructive"
          }`}
        >
          <Trend className="h-3.5 w-3.5" aria-hidden="true" />
          {positive ? "+" : ""}
          {stat.delta}%
        </span>
        <span className="truncate text-muted-foreground">vs last quarter</span>
      </div>

      <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-foreground/8">
        <motion.div
          className="h-full rounded-full bg-linear-to-r from-primary to-secondary"
          initial={{ width: 0 }}
          whileInView={{ width: `${stat.progress}%` }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
        />
      </div>
    </motion.article>
  );
}