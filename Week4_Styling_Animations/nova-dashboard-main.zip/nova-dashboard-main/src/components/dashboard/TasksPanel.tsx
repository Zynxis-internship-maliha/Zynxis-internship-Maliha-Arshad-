import { AnimatePresence, motion } from "motion/react";
import { Check, Plus } from "lucide-react";
import { useState } from "react";
import { initialTasks } from "@/utils/dashboard-data";
import { Button } from "@/components/ui-kit/Button";
import { SectionCard } from "@/components/dashboard/SectionCard";
import { cn } from "@/lib/utils";

export function TasksPanel() {
  const [tasks, setTasks] = useState(initialTasks);
  const done = tasks.filter((t) => t.done).length;

  const toggle = (id: string) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));

  return (
    <SectionCard
      title="Tasks"
      description={`${done} of ${tasks.length} complete`}
      action={
        <Button variant="ghost" size="icon" aria-label="Add task">
          <Plus className="h-4 w-4" />
        </Button>
      }
    >
      <ul className="space-y-2">
        {tasks.map((task) => (
          <li key={task.id}>
            <label
              className={cn(
                "flex min-h-11 cursor-pointer items-center gap-3 rounded-2xl border border-border/70 px-3 py-2.5 transition-colors hover:border-primary/40 hover:bg-primary/6",
                task.done && "opacity-70",
              )}
            >
              <input
                type="checkbox"
                checked={task.done}
                onChange={() => toggle(task.id)}
                className="peer sr-only"
              />
              <motion.span
                whileTap={{ scale: 0.86 }}
                className={cn(
                  "grid h-5 w-5 shrink-0 place-items-center rounded-md border transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-ring",
                  task.done ? "border-success bg-success/20 text-success" : "border-border text-transparent",
                )}
              >
                <AnimatePresence>
                  {task.done && (
                    <motion.span
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                      transition={{ type: "spring", stiffness: 500, damping: 20 }}
                    >
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                    </motion.span>
                  )}
                </AnimatePresence>
              </motion.span>
              <span className="min-w-0 flex-1">
                <span
                  className={cn(
                    "block truncate text-sm font-medium text-foreground",
                    task.done && "line-through decoration-muted-foreground",
                  )}
                >
                  {task.title}
                </span>
              </span>
              <span className="shrink-0 text-xs text-muted-foreground">{task.due}</span>
            </label>
          </li>
        ))}
      </ul>
    </SectionCard>
  );
}