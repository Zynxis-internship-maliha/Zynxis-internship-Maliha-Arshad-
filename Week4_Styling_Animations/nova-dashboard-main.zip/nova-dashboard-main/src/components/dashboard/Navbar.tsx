import { motion, useAnimationControls } from "motion/react";
import { Bell, ChevronDown, CreditCard, LogOut, Menu, Plus, Settings, User } from "lucide-react";
import { navbarEnter } from "@/animations/variants";
import { Button } from "@/components/ui-kit/Button";
import { Dropdown, DropdownItem } from "@/components/ui-kit/Dropdown";
import { SearchBar } from "@/components/dashboard/SearchBar";
import { Tooltip } from "@/components/ui-kit/Tooltip";

const notifications = [
  { title: "Invoice INV-2481 paid", meta: "Northwind Labs · 2m ago" },
  { title: "Quota warning on Atlas", meta: "80% of monthly usage · 1h ago" },
  { title: "New teammate joined", meta: "Ravi added to Growth · 4h ago" },
];

type NavbarProps = {
  onMenuClick: () => void;
  onNewReport: () => void;
};

export function Navbar({ onMenuClick, onNewReport }: NavbarProps) {
  const bellControls = useAnimationControls();

  const shakeBell = () => {
    void bellControls.start({
      rotate: [0, -14, 12, -8, 6, 0],
      transition: { duration: 0.55, ease: "easeInOut" },
    });
  };

  return (
    <motion.header
      variants={navbarEnter}
      initial="hidden"
      animate="visible"
      className="sticky top-0 z-80 border-b border-border bg-background/70 backdrop-blur-xl"
    >
      <div className="flex items-center gap-2 px-4 py-3 sm:gap-3 sm:px-6">
        <Button
          variant="outline"
          size="icon"
          aria-label="Open navigation"
          onClick={onMenuClick}
          className="lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </Button>

        <SearchBar />

        <div className="ml-auto flex shrink-0 items-center gap-2">
          <Button variant="gradient" size="sm" className="hidden sm:inline-flex" onClick={onNewReport}>
            <Plus className="h-4 w-4" />
            New report
          </Button>

          <Dropdown
            label="Notifications"
            trigger={({ toggle, open }) => (
              <Tooltip label="Notifications">
                <motion.button
                  type="button"
                  aria-label="Notifications"
                  aria-expanded={open}
                  onClick={() => {
                    shakeBell();
                    toggle();
                  }}
                  whileTap={{ scale: 0.94 }}
                  className="relative grid h-11 w-11 place-items-center rounded-xl border border-border bg-surface/60 text-muted-foreground transition-colors outline-none hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <motion.span animate={bellControls}>
                    <Bell className="h-5 w-5" aria-hidden="true" />
                  </motion.span>
                  <span className="absolute top-2.5 right-2.5 h-2 w-2 rounded-full bg-destructive ring-2 ring-background" />
                </motion.button>
              </Tooltip>
            )}
          >
            {(close) => (
              <div className="space-y-1">
                <p className="px-3 py-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  Notifications
                </p>
                {notifications.map((n) => (
                  <button
                    key={n.title}
                    type="button"
                    role="menuitem"
                    onClick={close}
                    className="w-full rounded-xl px-3 py-2.5 text-left transition-colors outline-none hover:bg-primary/10 focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <span className="block truncate text-sm font-medium text-foreground">{n.title}</span>
                    <span className="block truncate text-xs text-muted-foreground">{n.meta}</span>
                  </button>
                ))}
              </div>
            )}
          </Dropdown>

          <Dropdown
            label="Profile menu"
            trigger={({ toggle, open }) => (
              <motion.button
                type="button"
                onClick={toggle}
                aria-expanded={open}
                aria-label="Open profile menu"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.96 }}
                className="flex min-h-11 items-center gap-2 rounded-xl border border-border bg-surface/60 py-1.5 pr-2 pl-1.5 transition-colors outline-none hover:border-primary/40 focus-visible:ring-2 focus-visible:ring-ring"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-linear-to-br from-primary to-secondary text-xs font-bold text-primary-foreground">
                  AK
                </span>
                <span className="hidden min-w-0 text-left sm:block">
                  <span className="block truncate text-xs font-semibold text-foreground">Aisha Karim</span>
                  <span className="block truncate text-[11px] text-muted-foreground">Admin</span>
                </span>
                <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              </motion.button>
            )}
          >
            {(close) => (
              <div className="space-y-0.5">
                <DropdownItem icon={User} onSelect={close}>
                  Profile
                </DropdownItem>
                <DropdownItem icon={CreditCard} onSelect={close}>
                  Billing
                </DropdownItem>
                <DropdownItem icon={Settings} onSelect={close}>
                  Preferences
                </DropdownItem>
                <div className="my-1 h-px bg-border" />
                <DropdownItem icon={LogOut} onSelect={close}>
                  Sign out
                </DropdownItem>
              </div>
            )}
          </Dropdown>
        </div>
      </div>
    </motion.header>
  );
}