import { motion } from "motion/react";
import { Search } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

/** Expands on focus to signal command-palette style search. */
export function SearchBar({ className }: { className?: string }) {
  const [focused, setFocused] = useState(false);

  return (
    <motion.div
      animate={{ scale: focused ? 1.02 : 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 24 }}
      className={cn(
        "relative flex min-w-0 flex-1 items-center rounded-xl border bg-surface/70 transition-[max-width,box-shadow,border-color] duration-300",
        focused
          ? "max-w-full border-primary/50 shadow-[0_0_0_4px_color-mix(in_oklab,var(--color-primary)_18%,transparent)]"
          : "max-w-md border-border",
        className,
      )}
    >
      <Search className="pointer-events-none absolute left-3.5 h-4 w-4 text-muted-foreground" aria-hidden="true" />
      <label className="sr-only" htmlFor="dashboard-search">
        Search the workspace
      </label>
      <input
        id="dashboard-search"
        type="search"
        placeholder="Search customers, invoices, metrics…"
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        className="h-11 w-full min-w-0 rounded-xl bg-transparent pr-16 pl-10 text-sm text-foreground outline-none placeholder:text-muted-foreground"
      />
      <kbd className="pointer-events-none absolute right-3 hidden rounded-md border border-border px-1.5 py-0.5 text-[11px] font-medium text-muted-foreground sm:block">
        ⌘K
      </kbd>
    </motion.div>
  );
}