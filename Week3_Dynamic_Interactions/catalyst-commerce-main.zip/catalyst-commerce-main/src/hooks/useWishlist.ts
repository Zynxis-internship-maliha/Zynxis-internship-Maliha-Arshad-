import { useCallback, useMemo } from "react";
import { toast } from "sonner";
import { useLocalStorage } from "./useLocalStorage";
import { PRODUCTS, type Product } from "@/data/products";

/** Favourite products persisted across sessions. */
export function useWishlist() {
  const [ids, setIds] = useLocalStorage<number[]>("catalog.wishlist", []);

  const isWishlisted = useCallback((id: number) => ids.includes(id), [ids]);

  const toggleWishlist = useCallback(
    (product: Product) => {
      setIds((current) => {
        const exists = current.includes(product.id);
        toast[exists ? "message" : "success"](
          exists ? "Removed from wishlist" : "Saved to wishlist",
          { description: product.title },
        );
        return exists ? current.filter((id) => id !== product.id) : [...current, product.id];
      });
    },
    [setIds],
  );

  const items = useMemo(
    () => ids.flatMap((id) => PRODUCTS.filter((product) => product.id === id)),
    [ids],
  );

  const clearWishlist = useCallback(() => setIds([]), [setIds]);

  return { ids, items, count: ids.length, isWishlisted, toggleWishlist, clearWishlist };
}
