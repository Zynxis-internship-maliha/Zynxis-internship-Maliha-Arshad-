import { useCallback, useMemo } from "react";
import { useLocalStorage } from "./useLocalStorage";
import { PRODUCTS, type Product } from "@/data/products";

const MAX_ITEMS = 8;

/** Keeps a short, most-recent-first history of viewed products. */
export function useRecentlyViewed() {
  const [ids, setIds] = useLocalStorage<number[]>("catalog.recentlyViewed", []);

  const trackView = useCallback(
    (product: Product) =>
      setIds((current) => [product.id, ...current.filter((id) => id !== product.id)].slice(0, MAX_ITEMS)),
    [setIds],
  );

  const items = useMemo(
    () => ids.flatMap((id) => PRODUCTS.filter((product) => product.id === id)),
    [ids],
  );

  return { items, trackView };
}
