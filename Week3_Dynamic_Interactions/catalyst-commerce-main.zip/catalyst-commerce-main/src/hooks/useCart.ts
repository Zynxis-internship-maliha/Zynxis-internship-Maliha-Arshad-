import { useCallback, useMemo } from "react";
import { toast } from "sonner";
import { useLocalStorage } from "./useLocalStorage";
import { finalPrice, PRODUCTS, type Product } from "@/data/products";

export interface CartLine {
  id: number;
  quantity: number;
}

export interface CartItem extends CartLine {
  product: Product;
  lineTotal: number;
}

/** Shopping cart state persisted across sessions. */
export function useCart() {
  const [lines, setLines] = useLocalStorage<CartLine[]>("catalog.cart", []);

  const addToCart = useCallback(
    (product: Product, quantity = 1) => {
      setLines((current) => {
        const existing = current.find((line) => line.id === product.id);
        if (existing) {
          return current.map((line) =>
            line.id === product.id
              ? { ...line, quantity: Math.min(line.quantity + quantity, product.stock || 99) }
              : line,
          );
        }
        return [...current, { id: product.id, quantity }];
      });
      toast.success("Added to cart", { description: `${product.title} × ${quantity}` });
    },
    [setLines],
  );

  const updateQuantity = useCallback(
    (id: number, quantity: number) =>
      setLines((current) =>
        quantity <= 0
          ? current.filter((line) => line.id !== id)
          : current.map((line) => (line.id === id ? { ...line, quantity } : line)),
      ),
    [setLines],
  );

  const removeFromCart = useCallback(
    (id: number) => setLines((current) => current.filter((line) => line.id !== id)),
    [setLines],
  );

  const clearCart = useCallback(() => setLines([]), [setLines]);

  const items = useMemo<CartItem[]>(
    () =>
      lines.flatMap((line) => {
        const product = PRODUCTS.find((candidate) => candidate.id === line.id);
        if (!product) return [];
        return [{ ...line, product, lineTotal: finalPrice(product) * line.quantity }];
      }),
    [lines],
  );

  const count = useMemo(() => items.reduce((sum, item) => sum + item.quantity, 0), [items]);
  const subtotal = useMemo(() => items.reduce((sum, item) => sum + item.lineTotal, 0), [items]);

  return { items, count, subtotal, addToCart, updateQuantity, removeFromCart, clearCart };
}
