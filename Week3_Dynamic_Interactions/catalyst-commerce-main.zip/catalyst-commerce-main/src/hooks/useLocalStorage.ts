import { useCallback, useEffect, useRef, useState } from "react";

/**
 * SSR-safe localStorage-backed state.
 * Reads happen after hydration to avoid server/client markup mismatches.
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(initialValue);
  const [hydrated, setHydrated] = useState(false);
  const keyRef = useRef(key);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(keyRef.current);
      if (stored !== null) setValue(JSON.parse(stored) as T);
    } catch {
      /* corrupted or unavailable storage — fall back to the initial value */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(keyRef.current, JSON.stringify(value));
    } catch {
      /* quota exceeded or private mode — ignore */
    }
  }, [value, hydrated]);

  const reset = useCallback(() => setValue(initialValue), [initialValue]);

  return [value, setValue, { hydrated, reset }] as const;
}
