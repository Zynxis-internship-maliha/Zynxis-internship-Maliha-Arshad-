import { useEffect, useMemo, useState } from "react";
import { useDebounce } from "./useDebounce";
import { finalPrice, MAX_PRICE, PRODUCTS, type Brand, type Category, type Product } from "@/data/products";

export type SortKey =
  | "newest"
  | "oldest"
  | "price-asc"
  | "price-desc"
  | "rating"
  | "best-selling"
  | "az"
  | "za";

export const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "newest", label: "Newest" },
  { value: "oldest", label: "Oldest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Highest Rating" },
  { value: "best-selling", label: "Best Selling" },
  { value: "az", label: "Alphabetical A–Z" },
  { value: "za", label: "Alphabetical Z–A" },
];

export interface Filters {
  categories: Category[];
  brands: Brand[];
  priceRange: [number, number];
  minRating: number;
  inStockOnly: boolean;
  featuredOnly: boolean;
  discountedOnly: boolean;
}

export const DEFAULT_FILTERS: Filters = {
  categories: [],
  brands: [],
  priceRange: [0, MAX_PRICE],
  minRating: 0,
  inStockOnly: false,
  featuredOnly: false,
  discountedOnly: false,
};

const PAGE_SIZE = 12;

const matchesSearch = (product: Product, query: string) => {
  if (!query) return true;
  const haystack = [
    product.title,
    product.brand,
    product.category,
    product.description,
    product.color,
    ...product.tags,
  ]
    .join(" ")
    .toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((token) => haystack.includes(token));
};

const sorters: Record<SortKey, (a: Product, b: Product) => number> = {
  newest: (a, b) => b.dateAdded.localeCompare(a.dateAdded),
  oldest: (a, b) => a.dateAdded.localeCompare(b.dateAdded),
  "price-asc": (a, b) => finalPrice(a) - finalPrice(b),
  "price-desc": (a, b) => finalPrice(b) - finalPrice(a),
  rating: (a, b) => b.rating - a.rating,
  "best-selling": (a, b) => b.sold - a.sold,
  az: (a, b) => a.title.localeCompare(b.title),
  za: (a, b) => b.title.localeCompare(a.title),
};

/**
 * Owns the catalog pipeline: async load → search → filter → sort → paginate.
 * Pure derivations are memoized so typing stays smooth on large lists.
 */
export function useCatalog() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortKey>("newest");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebounce(search, 250);

  // Simulate loading the local product dataset so skeletons are exercised.
  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(() => {
      if (!active) return;
      setProducts(PRODUCTS);
      setIsLoading(false);
    }, 700);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, []);

  const filtered = useMemo(() => {
    const [min, max] = filters.priceRange;
    return products.filter((product) => {
      const price = finalPrice(product);
      if (!matchesSearch(product, debouncedSearch)) return false;
      if (filters.categories.length && !filters.categories.includes(product.category)) return false;
      if (filters.brands.length && !filters.brands.includes(product.brand)) return false;
      if (price < min || price > max) return false;
      if (product.rating < filters.minRating) return false;
      if (filters.inStockOnly && product.stock === 0) return false;
      if (filters.featuredOnly && !product.featured) return false;
      if (filters.discountedOnly && product.discount === 0) return false;
      return true;
    });
  }, [products, debouncedSearch, filters]);

  const sorted = useMemo(() => [...filtered].sort(sorters[sort]), [filtered, sort]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const paginated = useMemo(
    () => sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE),
    [sorted, currentPage],
  );

  // Any change to the result set should bring the user back to page one.
  useEffect(() => setPage(1), [debouncedSearch, filters, sort]);

  const activeFilterCount =
    filters.categories.length +
    filters.brands.length +
    (filters.minRating > 0 ? 1 : 0) +
    (filters.inStockOnly ? 1 : 0) +
    (filters.featuredOnly ? 1 : 0) +
    (filters.discountedOnly ? 1 : 0) +
    (filters.priceRange[0] !== 0 || filters.priceRange[1] !== MAX_PRICE ? 1 : 0) +
    (search ? 1 : 0);

  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
    setSearch("");
    setSort("newest");
  };

  return {
    products,
    isLoading,
    search,
    setSearch,
    filters,
    setFilters,
    sort,
    setSort,
    results: sorted,
    paginated,
    page: currentPage,
    setPage,
    pageCount,
    pageSize: PAGE_SIZE,
    activeFilterCount,
    resetFilters,
  };
}
