export const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);

export const formatCompact = (value: number) =>
  new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(value);

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

export const stockLabel = (stock: number) => {
  if (stock === 0) return { label: "Out of stock", tone: "out" as const };
  if (stock <= 10) return { label: `Only ${stock} left`, tone: "low" as const };
  return { label: "In stock", tone: "in" as const };
};
