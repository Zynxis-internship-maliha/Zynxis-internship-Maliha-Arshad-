import { createFileRoute } from "@tanstack/react-router";
import { CatalogPage } from "@/pages/CatalogPage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nexora — Premium Technology Product Catalog" },
      {
        name: "description",
        content:
          "Browse 48 premium phones, laptops, headphones, wearables and gaming gear with live search, multi-filter, sorting, wishlist and cart.",
      },
      { property: "og:title", content: "Nexora — Premium Technology Product Catalog" },
      {
        property: "og:description",
        content:
          "A premium dark-theme product catalog with real-time search, composable filters, sorting, wishlist and a persistent cart.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CatalogPage,
});
