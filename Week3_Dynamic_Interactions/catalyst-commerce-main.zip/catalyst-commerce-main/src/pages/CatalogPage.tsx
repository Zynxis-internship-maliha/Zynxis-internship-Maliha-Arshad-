import { useCallback, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Toaster } from "sonner";

import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/Hero";
import { FilterToolbar } from "@/components/FilterToolbar";
import { ProductCard } from "@/components/ProductCard";
import { ProductRail } from "@/components/ProductRail";
import { ProductModal } from "@/components/ProductModal";
import { CartDrawer } from "@/components/CartDrawer";
import { WishlistDrawer } from "@/components/WishlistDrawer";
import { SkeletonGrid } from "@/components/SkeletonCard";
import { EmptyState } from "@/components/EmptyState";
import { Pagination } from "@/components/Pagination";
import { BackToTop, ScrollProgress } from "@/components/ScrollUtilities";

import { useCatalog } from "@/hooks/useCatalog";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import { useTheme } from "@/hooks/useTheme";
import type { Product } from "@/data/products";

export function CatalogPage() {
  const catalog = useCatalog();
  const cart = useCart();
  const wishlist = useWishlist();
  const recentlyViewed = useRecentlyViewed();
  const { theme, toggleTheme } = useTheme();

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);

  const openQuickView = useCallback(
    (product: Product) => {
      setSelectedProduct(product);
      recentlyViewed.trackView(product);
    },
    [recentlyViewed],
  );

  const addToCart = useCallback(
    (product: Product, quantity = 1) => cart.addToCart(product, quantity),
    [cart],
  );

  const featured = useMemo(
    () => catalog.products.filter((product) => product.featured).slice(0, 10),
    [catalog.products],
  );

  const trending = useMemo(
    () => [...catalog.products].sort((a, b) => b.sold - a.sold).slice(0, 10),
    [catalog.products],
  );

  return (
    <div className="min-h-screen">
      <ScrollProgress />
      <Toaster theme={theme} position="bottom-left" richColors closeButton />

      <Navbar
        search={catalog.search}
        onSearchChange={catalog.setSearch}
        wishlistCount={wishlist.count}
        cartCount={cart.count}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenWishlist={() => setWishlistOpen(true)}
        onOpenCart={() => setCartOpen(true)}
      />

      <main>
        <Hero />

        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div id="featured" className="scroll-mt-32">
            <ProductRail
              title="Featured Selection"
              subtitle="Hand-picked hardware our team actually uses."
              products={featured}
              variant="featured"
              onSelect={openQuickView}
            />
          </div>

          <div id="trending" className="scroll-mt-32">
            <ProductRail
              title="Trending Now"
              subtitle="Most ordered across the catalog this month."
              products={trending}
              variant="trending"
              onSelect={openQuickView}
            />
          </div>

          <section id="catalog" className="mt-20 scroll-mt-24">
            <header className="mb-6 max-w-2xl">
              <h2 className="text-2xl font-bold sm:text-3xl">The full catalog</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Search, filter and sort {catalog.products.length || 48} products. Every control
                below composes — combine them freely.
              </p>
            </header>

            <FilterToolbar
              search={catalog.search}
              onSearchChange={catalog.setSearch}
              filters={catalog.filters}
              onFiltersChange={catalog.setFilters}
              sort={catalog.sort}
              onSortChange={catalog.setSort}
              resultCount={catalog.results.length}
              activeFilterCount={catalog.activeFilterCount}
              onReset={catalog.resetFilters}
            />

            <div className="mt-8">
              {catalog.isLoading ? (
                <SkeletonGrid count={catalog.pageSize} />
              ) : catalog.results.length === 0 ? (
                <EmptyState onClear={catalog.resetFilters} />
              ) : (
                <motion.div
                  layout
                  className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                >
                  <AnimatePresence mode="popLayout">
                    {catalog.paginated.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        isWishlisted={wishlist.isWishlisted(product.id)}
                        onToggleWishlist={wishlist.toggleWishlist}
                        onQuickView={openQuickView}
                        onAddToCart={addToCart}
                      />
                    ))}
                  </AnimatePresence>
                </motion.div>
              )}
            </div>

            {!catalog.isLoading && (
              <Pagination page={catalog.page} pageCount={catalog.pageCount} onChange={catalog.setPage} />
            )}
          </section>

          <ProductRail
            title="Recently Viewed"
            subtitle="Pick up where you left off."
            products={recentlyViewed.items}
            variant="recent"
            onSelect={openQuickView}
          />
        </div>
      </main>

      <Footer />
      <BackToTop />

      <ProductModal
        product={selectedProduct}
        isWishlisted={selectedProduct ? wishlist.isWishlisted(selectedProduct.id) : false}
        onClose={() => setSelectedProduct(null)}
        onToggleWishlist={wishlist.toggleWishlist}
        onAddToCart={(product, quantity) => addToCart(product, quantity)}
      />

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart.items}
        subtotal={cart.subtotal}
        onUpdateQuantity={cart.updateQuantity}
        onRemove={cart.removeFromCart}
        onClear={cart.clearCart}
      />

      <WishlistDrawer
        open={wishlistOpen}
        onClose={() => setWishlistOpen(false)}
        items={wishlist.items}
        onToggleWishlist={wishlist.toggleWishlist}
        onAddToCart={(product) => addToCart(product)}
      />
    </div>
  );
}
