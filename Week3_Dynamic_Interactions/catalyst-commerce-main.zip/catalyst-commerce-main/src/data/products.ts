import phoneImg from "@/assets/p-phone.jpg";
import laptopImg from "@/assets/p-laptop.jpg";
import headphonesImg from "@/assets/p-headphones.jpg";
import watchImg from "@/assets/p-watch.jpg";
import gamingImg from "@/assets/p-gaming.jpg";
import accessoryImg from "@/assets/p-accessory.jpg";

export type Category =
  | "Phones"
  | "Laptops"
  | "Accessories"
  | "Gaming"
  | "Smart Watches"
  | "Headphones";

export type Brand =
  | "Apple"
  | "Samsung"
  | "Sony"
  | "Dell"
  | "HP"
  | "Asus"
  | "Lenovo"
  | "Logitech";

export interface Product {
  id: number;
  title: string;
  category: Category;
  brand: Brand;
  description: string;
  price: number;
  discount: number;
  rating: number;
  reviews: number;
  sold: number;
  stock: number;
  image: string;
  color: string;
  tags: string[];
  featured: boolean;
  dateAdded: string;
  specs: Record<string, string>;
}

export const CATEGORIES: Category[] = [
  "Phones",
  "Laptops",
  "Accessories",
  "Gaming",
  "Smart Watches",
  "Headphones",
];

export const BRANDS: Brand[] = [
  "Apple",
  "Samsung",
  "Sony",
  "Dell",
  "HP",
  "Asus",
  "Lenovo",
  "Logitech",
];

const CATEGORY_IMAGE: Record<Category, string> = {
  Phones: phoneImg,
  Laptops: laptopImg,
  Accessories: accessoryImg,
  Gaming: gamingImg,
  "Smart Watches": watchImg,
  Headphones: headphonesImg,
};

const CATEGORY_SPECS: Record<Category, (seed: number) => Record<string, string>> = {
  Phones: (s) => ({
    Display: `${(6.1 + (s % 4) * 0.2).toFixed(1)}" OLED 120Hz`,
    Storage: `${[128, 256, 512, 1024][s % 4]} GB`,
    Camera: `${[48, 50, 108, 200][s % 4]} MP triple`,
    Battery: `${4000 + (s % 5) * 300} mAh`,
    Connectivity: "5G · Wi-Fi 6E · NFC",
  }),
  Laptops: (s) => ({
    Processor: ["M3 Pro", "Intel Core Ultra 7", "AMD Ryzen 9", "Intel Core i7"][s % 4],
    Memory: `${[16, 24, 32, 64][s % 4]} GB unified`,
    Storage: `${[512, 1024, 2048][s % 3]} GB NVMe`,
    Display: `${(13.6 + (s % 3) * 1.2).toFixed(1)}" Retina-class`,
    Battery: `${14 + (s % 6)} h typical`,
  }),
  Accessories: (s) => ({
    Connection: ["USB-C", "Bluetooth 5.3", "2.4GHz + BT", "Thunderbolt 4"][s % 4],
    Compatibility: "macOS · Windows · iPadOS",
    Battery: `${20 + (s % 8) * 10} h`,
    Material: ["Anodized aluminium", "Recycled polymer", "Woven fabric"][s % 3],
    Warranty: "2 years",
  }),
  Gaming: (s) => ({
    Refresh: `${[144, 165, 240, 360][s % 4]} Hz`,
    Latency: `${(0.8 + (s % 4) * 0.3).toFixed(1)} ms`,
    Lighting: "16.8M RGB zones",
    Connection: ["Wired", "Wireless 2.4GHz", "Hybrid"][s % 3],
    Warranty: "2 years",
  }),
  "Smart Watches": (s) => ({
    Display: `${(1.4 + (s % 4) * 0.1).toFixed(1)}" AMOLED always-on`,
    Battery: `${18 + (s % 5) * 12} h`,
    Sensors: "ECG · SpO₂ · Temp · GPS",
    "Water rating": "10 ATM / IP68",
    Case: ["Titanium", "Aluminium", "Stainless steel"][s % 3],
  }),
  Headphones: (s) => ({
    Drivers: `${[40, 42, 50][s % 3]} mm dynamic`,
    ANC: "Adaptive hybrid noise cancelling",
    Battery: `${24 + (s % 6) * 6} h`,
    Codecs: "LDAC · AAC · SBC",
    Weight: `${210 + (s % 5) * 12} g`,
  }),
};

type Seed = [
  title: string,
  category: Category,
  brand: Brand,
  price: number,
  color: string,
  tags: string,
];

const SEEDS: Seed[] = [
  ["Aurora Pro Max 15", "Phones", "Apple", 1299, "Titanium Black", "flagship,camera,5g,pro"],
  ["Aurora 15", "Phones", "Apple", 899, "Starlight", "flagship,5g,compact"],
  ["Galaxy Nova Ultra", "Phones", "Samsung", 1199, "Phantom Grey", "flagship,stylus,camera,5g"],
  ["Galaxy Nova Flip", "Phones", "Samsung", 999, "Mint", "foldable,compact,5g"],
  ["Xperia Vision V", "Phones", "Sony", 949, "Deep Blue", "camera,cinema,5g"],
  ["ZenPhone Edge 9", "Phones", "Asus", 749, "Graphite", "gaming,performance,5g"],
  ["Legion Phone Duel", "Phones", "Lenovo", 699, "Shadow", "gaming,performance,cooling"],
  ["Vertex Lite 5G", "Phones", "HP", 429, "Silver", "budget,5g,everyday"],

  ["Aurora Book Pro 16", "Laptops", "Apple", 2499, "Space Black", "creator,pro,retina,performance"],
  ["Aurora Book Air 13", "Laptops", "Apple", 1199, "Midnight", "ultrabook,portable,silent"],
  ["XPS Vertex 15", "Laptops", "Dell", 1899, "Platinum", "creator,oled,performance"],
  ["Inspiron Flow 14", "Laptops", "Dell", 899, "Graphite", "2-in-1,student,portable"],
  ["Spectre Fold 14", "Laptops", "HP", 1699, "Nightfall", "2-in-1,oled,premium"],
  ["Pavilion Studio 15", "Laptops", "HP", 749, "Silver", "student,everyday,budget"],
  ["ZenBook Duo 14", "Laptops", "Asus", 1549, "Ink Blue", "dual-screen,creator,portable"],
  ["ROG Strike 18", "Laptops", "Asus", 2299, "Eclipse", "gaming,rtx,240hz,performance"],
  ["ThinkPad Carbon X1", "Laptops", "Lenovo", 1749, "Carbon", "business,durable,lightweight"],
  ["Yoga Slim Air", "Laptops", "Lenovo", 1099, "Storm Grey", "ultrabook,oled,portable"],

  ["MagDock Pro Charger", "Accessories", "Apple", 129, "White", "charging,magsafe,desk"],
  ["Aurora Pencil 2", "Accessories", "Apple", 149, "White", "stylus,creator,precision"],
  ["MX Master 4S", "Accessories", "Logitech", 119, "Graphite", "mouse,ergonomic,productivity"],
  ["MX Keys Mini", "Accessories", "Logitech", 109, "Pale Grey", "keyboard,compact,backlit"],
  ["Litra Beam Light", "Accessories", "Logitech", 99, "Slate", "streaming,lighting,desk"],
  ["UltraSharp Hub 8K", "Accessories", "Dell", 249, "Platinum", "dock,thunderbolt,desk"],
  ["Thunder Dock 12", "Accessories", "HP", 199, "Black", "dock,usb-c,office"],
  ["ThinkPlus Sleeve 16", "Accessories", "Lenovo", 79, "Charcoal", "case,travel,protection"],
  ["ProArt Pad XL", "Accessories", "Asus", 59, "Black", "desk,creator,mousepad"],
  ["Galaxy Power Bank 20K", "Accessories", "Samsung", 89, "Beige", "charging,travel,battery"],

  ["ROG Raptor Mouse", "Gaming", "Asus", 149, "Black", "mouse,esports,wireless"],
  ["ROG Azoth Keyboard", "Gaming", "Asus", 249, "Moonlight", "keyboard,mechanical,rgb"],
  ["Legion Vantage Monitor", "Gaming", "Lenovo", 549, "Storm", "monitor,240hz,gaming"],
  ["G Pro X Superlight 3", "Gaming", "Logitech", 159, "White", "mouse,esports,lightweight"],
  ["Astro A50 X Headset", "Gaming", "Logitech", 379, "Black", "headset,wireless,surround"],
  ["Odyssey Curve 49", "Gaming", "Samsung", 1299, "Silver", "monitor,ultrawide,oled"],
  ["DualSense Elite Pad", "Gaming", "Sony", 199, "Midnight", "controller,haptics,pro"],
  ["Omen Blast 27", "Gaming", "HP", 429, "Black", "monitor,165hz,gaming"],

  ["Aurora Watch Ultra 3", "Smart Watches", "Apple", 799, "Natural Titanium", "fitness,gps,premium"],
  ["Aurora Watch SE", "Smart Watches", "Apple", 279, "Starlight", "fitness,everyday,budget"],
  ["Galaxy Watch 7 Pro", "Smart Watches", "Samsung", 449, "Black Titanium", "fitness,ecg,gps"],
  ["Galaxy Fit Band 4", "Smart Watches", "Samsung", 89, "Graphite", "fitness,band,budget"],
  ["Wena Hybrid Watch", "Smart Watches", "Sony", 359, "Silver", "hybrid,classic,fitness"],
  ["VivoTrack Sport", "Smart Watches", "Asus", 179, "Sky", "fitness,running,gps"],

  ["WH-1000XM6", "Headphones", "Sony", 429, "Midnight Blue", "anc,over-ear,travel,hifi"],
  ["WF-1000XM5 Buds", "Headphones", "Sony", 279, "Silver", "anc,earbuds,compact"],
  ["Aurora Pods Max", "Headphones", "Apple", 549, "Space Grey", "anc,over-ear,spatial"],
  ["Aurora Pods Pro 3", "Headphones", "Apple", 249, "White", "anc,earbuds,spatial"],
  ["Galaxy Buds Ultra", "Headphones", "Samsung", 199, "Titanium", "anc,earbuds,hifi"],
  ["Zone Vibe Wireless", "Headphones", "Logitech", 129, "Rose", "office,calls,lightweight"],
];

const DESCRIPTIONS: Record<Category, string> = {
  Phones:
    "A flagship-grade handset engineered around a brighter adaptive display, a computational camera system tuned for low light, and all-day battery life in a precision-machined frame.",
  Laptops:
    "A thin-and-light powerhouse with a colour-accurate panel, sustained multi-core performance and a keyboard tuned for long writing sessions — built for people who ship work.",
  Accessories:
    "A considered desk companion designed to disappear into your workflow: precise materials, quiet mechanics and effortless multi-device pairing.",
  Gaming:
    "Competitive-grade hardware with ultra-low latency, tournament-tested sensors and customisable lighting — tuned for players who count milliseconds.",
  "Smart Watches":
    "An always-on health companion tracking heart rhythm, sleep, recovery and training load, wrapped in a durable case that survives real life.",
  Headphones:
    "Adaptive noise cancelling, hi-res wireless codecs and a tuned soundstage that keeps vocals forward and bass controlled, with plush all-day comfort.",
};

/** Deterministic pseudo-random helper so data stays stable between renders/SSR. */
const pseudo = (seed: number, mod: number) => (seed * 9301 + 49297) % mod;

export const PRODUCTS: Product[] = SEEDS.map(([title, category, brand, price, color, tags], i) => {
  const seed = i + 1;
  const discount = [0, 0, 5, 10, 15, 20, 25, 30][pseudo(seed, 8)];
  const stock = [0, 3, 7, 12, 24, 48, 95, 140][pseudo(seed + 3, 8)];
  const rating = Number((3.5 + pseudo(seed + 7, 15) / 10).toFixed(1));
  const day = 1 + pseudo(seed + 11, 28);
  const month = 1 + pseudo(seed + 5, 12);

  return {
    id: seed,
    title,
    category,
    brand,
    description: `${DESCRIPTIONS[category]} The ${title} by ${brand} finishes it in ${color}.`,
    price,
    discount,
    rating: Math.min(rating, 5),
    reviews: 40 + pseudo(seed + 2, 900),
    sold: 25 + pseudo(seed + 13, 4200),
    stock,
    image: CATEGORY_IMAGE[category],
    color,
    tags: tags.split(","),
    featured: pseudo(seed + 17, 5) === 0,
    dateAdded: `2025-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
    specs: CATEGORY_SPECS[category](seed),
  };
});

export const finalPrice = (product: Pick<Product, "price" | "discount">) =>
  Math.round(product.price * (1 - product.discount / 100));

export const MAX_PRICE = Math.max(...PRODUCTS.map((p) => p.price));
