import { motion } from "framer-motion";
import { FiMinus, FiPlus, FiTrash2, FiShoppingBag } from "react-icons/fi";
import { toast } from "sonner";
import { SideDrawer } from "./SideDrawer";
import { formatCurrency } from "@/utils/format";
import { finalPrice } from "@/data/products";
import type { CartItem } from "@/hooks/useCart";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
  subtotal: number;
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemove: (id: number) => void;
  onClear: () => void;
}

export function CartDrawer({
  open,
  onClose,
  items,
  subtotal,
  onUpdateQuantity,
  onRemove,
  onClear,
}: CartDrawerProps) {
  const shipping = subtotal > 0 && subtotal < 500 ? 19 : 0;

  return (
    <SideDrawer
      open={open}
      title={`Cart (${items.length})`}
      onClose={onClose}
      footer={
        items.length > 0 && (
          <div className="space-y-3">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Subtotal</span>
              <span className="font-medium text-foreground">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Shipping</span>
              <span className="font-medium text-foreground">
                {shipping === 0 ? "Free" : formatCurrency(shipping)}
              </span>
            </div>
            <div className="flex justify-between border-t border-border pt-3 text-base font-bold">
              <span>Total</span>
              <span>{formatCurrency(subtotal + shipping)}</span>
            </div>
            <button
              onClick={() => {
                toast.success("Checkout started", {
                  description: "This demo stops here — no payment is taken.",
                });
                onClear();
                onClose();
              }}
              className="w-full rounded-xl bg-gradient-primary py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.02]"
            >
              Checkout
            </button>
          </div>
        )
      }
    >
      {items.length === 0 ? (
        <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
          <span className="glass grid h-16 w-16 place-items-center rounded-2xl">
            <FiShoppingBag className="text-primary" size={24} />
          </span>
          <p className="text-sm text-muted-foreground">Your cart is empty.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {items.map((item) => (
            <motion.li
              key={item.id}
              layout
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="surface-card flex gap-3 rounded-2xl p-3"
            >
              <img
                src={item.product.image}
                alt={item.product.title}
                loading="lazy"
                className="h-20 w-20 shrink-0 rounded-xl bg-elevated object-cover"
              />
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{item.product.title}</p>
                    <p className="text-xs text-muted-foreground">{item.product.brand}</p>
                  </div>
                  <button
                    onClick={() => onRemove(item.id)}
                    aria-label={`Remove ${item.product.title}`}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-destructive"
                  >
                    <FiTrash2 size={14} />
                  </button>
                </div>
                <div className="mt-auto flex items-center justify-between gap-2 pt-2">
                  <div className="flex items-center gap-1 rounded-lg bg-elevated p-1">
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                      aria-label="Decrease quantity"
                      className="grid h-7 w-7 place-items-center rounded-md transition-colors hover:bg-accent"
                    >
                      <FiMinus size={12} />
                    </button>
                    <span className="w-6 text-center text-xs font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      aria-label="Increase quantity"
                      className="grid h-7 w-7 place-items-center rounded-md transition-colors hover:bg-accent"
                    >
                      <FiPlus size={12} />
                    </button>
                  </div>
                  <span className="text-sm font-bold">
                    {formatCurrency(finalPrice(item.product) * item.quantity)}
                  </span>
                </div>
              </div>
            </motion.li>
          ))}
        </ul>
      )}
    </SideDrawer>
  );
}
