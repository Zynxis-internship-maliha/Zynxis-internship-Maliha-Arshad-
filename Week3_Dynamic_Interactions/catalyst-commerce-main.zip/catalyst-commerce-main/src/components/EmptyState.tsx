import { motion } from "framer-motion";
import { FiSearch, FiRefreshCcw } from "react-icons/fi";

export function EmptyState({ onClear }: { onClear: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="surface-card flex flex-col items-center rounded-3xl px-6 py-16 text-center"
    >
      <div className="relative mb-6 grid h-28 w-28 place-items-center">
        <span className="halo absolute inset-0 rounded-full" />
        <motion.span
          animate={{ scale: [1, 1.06, 1] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="glass grid h-24 w-24 place-items-center rounded-3xl"
        >
          <FiSearch className="text-primary" size={34} />
        </motion.span>
      </div>
      <h3 className="text-xl font-semibold">No products found.</h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">
        Nothing matches this combination of search terms and filters. Try widening the price range
        or clearing a few filters.
      </p>
      <button
        onClick={onClear}
        className="mt-6 inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.03]"
      >
        <FiRefreshCcw /> Clear Filters
      </button>
    </motion.div>
  );
}
