import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FiX, FiMinus, FiPlus, FiHeart, FiShoppingBag, FiTruck, FiShield } from "react-icons/fi";
import { useState } from "react";
import type { Product } from "@/data/products";
import { finalPrice } from "@/data/products";
import { formatCurrency, formatDate, stockLabel } from "@/utils/format";
import { StarRating } from "./StarRating";

interface ProductModalProps {
  product: Product | null;
  isWishlisted: boolean;
  onClose: () => void;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

const REVIEWS = [
  { name: "Amara O.", rating: 5, text: "Build quality is genuinely excellent — feels a tier above the price." },
  { name: "Julian R.", rating: 4, text: "Great daily driver. Battery easily lasts a full working day." },
  { name: "Sofia M.", rating: 5, text: "Shipped fast and the finish is exactly as pictured. No complaints." },
];

export function ProductModal({
  product,
  isWishlisted,
  onClose,
  onToggleWishlist,
  onAddToCart,
}: ProductModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    setQuantity(1);
    setActiveImage(0);
  }, [product?.id]);

  useEffect(() => {
    if (!product) return;
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [product, onClose]);

  const stock = product ? stockLabel(product.stock) : null;

  return (
    <AnimatePresence>
      {product && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-end justify-center p-0 sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-background/80 backdrop-blur-md"
            onClick={onClose}
            aria-hidden
          />

          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={product.title}
            initial={{ y: 40, scale: 0.96, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 30, scale: 0.97, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="surface-card relative z-10 max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-t-3xl sm:rounded-3xl"
          >
            <button
              onClick={onClose}
              aria-label="Close product details"
              className="glass absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-xl text-foreground transition-colors hover:bg-accent"
            >
              <FiX />
            </button>

            <div className="grid gap-8 p-5 sm:p-8 lg:grid-cols-2">
              <div>
                <motion.img
                  key={activeImage}
                  initial={{ opacity: 0, scale: 1.02 }}
                  animate={{ opacity: 1, scale: 1 }}
                  src={product.image}
                  alt={product.title}
                  width={800}
                  height={800}
                  className="aspect-square w-full rounded-2xl bg-elevated object-cover"
                />
                <div className="mt-3 flex gap-3">
                  {[0, 1, 2, 3].map((index) => (
                    <button
                      key={index}
                      onClick={() => setActiveImage(index)}
                      aria-label={`View image ${index + 1}`}
                      className={`h-16 w-16 overflow-hidden rounded-xl border transition-all ${
                        activeImage === index
                          ? "border-primary shadow-[var(--shadow-glow)]"
                          : "border-border opacity-60 hover:opacity-100"
                      }`}
                    >
                      <img
                        src={product.image}
                        alt=""
                        loading="lazy"
                        className="h-full w-full object-cover"
                        style={{ transform: `scale(${1 + index * 0.15})` }}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-secondary-foreground">
                    {product.category}
                  </span>
                  <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
                    {product.brand}
                  </span>
                  {product.featured && (
                    <span className="rounded-full bg-gradient-primary px-2.5 py-1 text-[11px] font-semibold text-primary-foreground">
                      Featured
                    </span>
                  )}
                </div>

                <h2 className="mt-3 text-2xl font-bold sm:text-3xl">{product.title}</h2>
                <div className="mt-2">
                  <StarRating rating={product.rating} reviews={product.reviews} size={16} />
                </div>

                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {product.description}
                </p>

                <div className="mt-5 flex items-end gap-3">
                  <span className="text-3xl font-bold tracking-tight">
                    {formatCurrency(finalPrice(product))}
                  </span>
                  {product.discount > 0 && (
                    <>
                      <span className="pb-1 text-sm text-muted-foreground line-through">
                        {formatCurrency(product.price)}
                      </span>
                      <span className="mb-1 rounded-full bg-destructive px-2 py-0.5 text-[11px] font-bold text-destructive-foreground">
                        −{product.discount}%
                      </span>
                    </>
                  )}
                </div>

                <p
                  className={`mt-2 text-xs font-medium ${
                    stock?.tone === "out"
                      ? "text-destructive"
                      : stock?.tone === "low"
                        ? "text-warning"
                        : "text-success"
                  }`}
                >
                  {stock?.label} · Added {formatDate(product.dateAdded)}
                </p>

                <dl className="mt-6 grid grid-cols-1 gap-x-6 gap-y-2 rounded-2xl bg-elevated p-4 text-sm sm:grid-cols-2">
                  {Object.entries(product.specs).map(([key, value]) => (
                    <div key={key} className="flex justify-between gap-3 border-b border-border py-1.5 last:border-0">
                      <dt className="text-muted-foreground">{key}</dt>
                      <dd className="text-right font-medium">{value}</dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <div className="glass flex items-center gap-1 rounded-xl p-1">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      aria-label="Decrease quantity"
                      className="grid h-9 w-9 place-items-center rounded-lg transition-colors hover:bg-accent"
                    >
                      <FiMinus size={14} />
                    </button>
                    <span className="w-8 text-center text-sm font-semibold" aria-live="polite">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(product.stock || 1, q + 1))}
                      aria-label="Increase quantity"
                      className="grid h-9 w-9 place-items-center rounded-lg transition-colors hover:bg-accent"
                    >
                      <FiPlus size={14} />
                    </button>
                  </div>

                  <button
                    onClick={() => onAddToCart(product, quantity)}
                    disabled={product.stock === 0}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] disabled:opacity-40 disabled:hover:scale-100"
                  >
                    <FiShoppingBag /> Add to Cart
                  </button>

                  <button
                    onClick={() => onToggleWishlist(product)}
                    aria-pressed={isWishlisted}
                    aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
                    className="glass grid h-12 w-12 place-items-center rounded-xl transition-colors hover:bg-accent"
                  >
                    <FiHeart className={isWishlisted ? "fill-current text-destructive" : ""} />
                  </button>
                </div>

                <div className="mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-2">
                    <FiTruck /> Free 2-day delivery
                  </span>
                  <span className="inline-flex items-center gap-2">
                    <FiShield /> 2-year warranty
                  </span>
                </div>

                <section className="mt-8">
                  <h3 className="text-sm font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Reviews
                  </h3>
                  <ul className="mt-3 space-y-3">
                    {REVIEWS.map((review) => (
                      <li key={review.name} className="rounded-2xl bg-elevated p-4">
                        <div className="flex items-center justify-between gap-3">
                          <span className="text-sm font-semibold">{review.name}</span>
                          <StarRating rating={review.rating} showValue={false} size={12} />
                        </div>
                        <p className="mt-1.5 text-sm text-muted-foreground">{review.text}</p>
                      </li>
                    ))}
                  </ul>
                </section>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
