export function SkeletonCard() {
  return (
    <div className="surface-card overflow-hidden rounded-2xl p-3" aria-hidden>
      <div className="shimmer aspect-4/3 w-full rounded-xl" />
      <div className="space-y-3 p-3">
        <div className="shimmer h-3 w-1/3 rounded-full" />
        <div className="shimmer h-4 w-4/5 rounded-full" />
        <div className="shimmer h-3 w-1/2 rounded-full" />
        <div className="flex items-center justify-between pt-2">
          <div className="shimmer h-5 w-20 rounded-full" />
          <div className="shimmer h-9 w-24 rounded-xl" />
        </div>
      </div>
    </div>
  );
}

export function SkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: count }).map((_, index) => (
        <SkeletonCard key={index} />
      ))}
    </div>
  );
}
