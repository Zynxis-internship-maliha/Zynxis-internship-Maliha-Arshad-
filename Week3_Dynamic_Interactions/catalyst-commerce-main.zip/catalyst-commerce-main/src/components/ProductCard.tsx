import { memo } from "react";
import { motion } from "framer-motion";
import { FiHeart, FiEye, FiShoppingBag } from "react-icons/fi";
import type { Product } from "@/data/products";
import { finalPrice } from "@/data/products";
import { formatCurrency, stockLabel } from "@/utils/format";
import { StarRating } from "./StarRating";

export interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

const stockTone: Record<"in" | "low" | "out", string> = {
  in: "text-success",
  low: "text-warning",
  out: "text-destructive",
};

function ProductCardComponent({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
}: ProductCardProps) {
  const price = finalPrice(product);
  const stock = stockLabel(product.stock);
  const soldOut = product.stock === 0;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className="surface-card group relative flex flex-col overflow-hidden rounded-2xl transition-shadow duration-300 hover:shadow-[var(--shadow-glow)]"
    >
      <div className="relative m-3 overflow-hidden rounded-xl bg-elevated">
        <img
          src={product.image}
          alt={product.title}
          loading="lazy"
          width={800}
          height={600}
          className="aspect-4/3 w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />

        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          <span className="glass rounded-full px-2.5 py-1 text-[11px] font-medium text-foreground/90">
            {product.category}
          </span>
          {product.featured && (
            <span className="rounded-full bg-gradient-primary px-2.5 py-1 text-[11px] font-semibold text-primary-foreground">
              Featured
            </span>
          )}
        </div>

        {product.discount > 0 && (
          <span className="absolute right-3 top-3 rounded-full bg-destructive px-2.5 py-1 text-[11px] font-bold text-destructive-foreground">
            −{product.discount}%
          </span>
        )}

        <div className="pointer-events-none absolute inset-x-3 bottom-3 flex gap-2 opacity-0 transition-all duration-300 group-hover:pointer-events-auto group-hover:opacity-100 focus-within:pointer-events-auto focus-within:opacity-100">
          <button
            onClick={() => onQuickView(product)}
            className="glass flex flex-1 items-center justify-center gap-2 rounded-xl py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
          >
            <FiEye /> Quick View
          </button>
          <button
            onClick={() => onToggleWishlist(product)}
            aria-pressed={isWishlisted}
            aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
            className="glass grid h-9 w-9 shrink-0 place-items-center rounded-xl transition-colors hover:bg-accent"
          >
            <FiHeart className={isWishlisted ? "fill-current text-destructive" : "text-foreground"} />
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-2 px-4 pb-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
            {product.brand}
          </span>
          <span className={`text-[11px] font-medium ${stockTone[stock.tone]}`}>{stock.label}</span>
        </div>

        <h3 className="truncate text-[15px] font-semibold" title={product.title}>
          {product.title}
        </h3>

        <StarRating rating={product.rating} reviews={product.reviews} />

        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <div className="min-w-0">
            <p className="text-lg font-bold tracking-tight">{formatCurrency(price)}</p>
            {product.discount > 0 && (
              <p className="text-xs text-muted-foreground line-through">
                {formatCurrency(product.price)}
              </p>
            )}
          </div>
          <button
            onClick={() => onAddToCart(product)}
            disabled={soldOut}
            className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-gradient-primary px-3.5 py-2.5 text-xs font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.04] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
          >
            <FiShoppingBag size={14} /> Add
          </button>
        </div>
      </div>
    </motion.article>
  );
}

export const ProductCard = memo(ProductCardComponent);
