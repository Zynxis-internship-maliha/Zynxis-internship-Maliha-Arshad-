import { FiStar } from "react-icons/fi";

interface StarRatingProps {
  rating: number;
  size?: number;
  showValue?: boolean;
  reviews?: number;
}

export function StarRating({ rating, size = 14, showValue = true, reviews }: StarRatingProps) {
  return (
    <div
      className="flex items-center gap-1.5"
      aria-label={`Rated ${rating.toFixed(1)} out of 5`}
      role="img"
    >
      <span className="flex items-center gap-0.5" aria-hidden>
        {[0, 1, 2, 3, 4].map((index) => (
          <FiStar
            key={index}
            size={size}
            className={
              index < Math.round(rating)
                ? "fill-current text-warning"
                : "text-muted-foreground/40"
            }
          />
        ))}
      </span>
      {showValue && (
        <span className="text-xs font-medium text-muted-foreground">
          {rating.toFixed(1)}
          {reviews !== undefined && ` (${reviews})`}
        </span>
      )}
    </div>
  );
}
