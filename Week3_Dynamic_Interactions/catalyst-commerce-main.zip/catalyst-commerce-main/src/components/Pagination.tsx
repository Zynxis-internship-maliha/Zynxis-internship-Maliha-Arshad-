import { FiChevronLeft, FiChevronRight } from "react-icons/fi";

interface PaginationProps {
  page: number;
  pageCount: number;
  onChange: (page: number) => void;
}

export function Pagination({ page, pageCount, onChange }: PaginationProps) {
  if (pageCount <= 1) return null;

  const pages = Array.from({ length: pageCount }, (_, index) => index + 1).filter(
    (candidate) =>
      candidate === 1 ||
      candidate === pageCount ||
      Math.abs(candidate - page) <= 1,
  );

  const go = (next: number) => {
    onChange(Math.min(Math.max(next, 1), pageCount));
    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <nav className="mt-12 flex items-center justify-center gap-2" aria-label="Pagination">
      <button
        onClick={() => go(page - 1)}
        disabled={page === 1}
        aria-label="Previous page"
        className="glass grid h-10 w-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
      >
        <FiChevronLeft />
      </button>

      {pages.map((candidate, index) => (
        <span key={candidate} className="flex items-center gap-2">
          {index > 0 && candidate - pages[index - 1] > 1 && (
            <span className="px-1 text-muted-foreground">…</span>
          )}
          <button
            onClick={() => go(candidate)}
            aria-current={candidate === page ? "page" : undefined}
            className={`h-10 min-w-10 rounded-xl px-3 text-sm font-semibold transition-all duration-200 ${
              candidate === page
                ? "bg-gradient-primary text-primary-foreground shadow-[var(--shadow-glow)]"
                : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {candidate}
          </button>
        </span>
      ))}

      <button
        onClick={() => go(page + 1)}
        disabled={page === pageCount}
        aria-label="Next page"
        className="glass grid h-10 w-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
      >
        <FiChevronRight />
      </button>
    </nav>
  );
}
