import { motion } from "framer-motion";
import { FiArrowRight, FiZap } from "react-icons/fi";
import heroImage from "@/assets/hero.jpg";
import { AnimatedCounter } from "./AnimatedCounter";

const STATS = [
  { value: 48, suffix: "+", label: "Curated products" },
  { value: 8, suffix: "", label: "Premium brands" },
  { value: 24, suffix: "h", label: "Avg. dispatch" },
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="halo pointer-events-none absolute inset-x-0 -top-40 h-[520px]" aria-hidden />
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 pb-16 pt-14 sm:px-6 lg:grid-cols-2 lg:pb-24 lg:pt-20">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="min-w-0"
        >
          <span className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-medium text-muted-foreground">
            <FiZap className="text-primary" /> New season hardware, live now
          </span>

          <h1 className="mt-5 text-4xl font-black leading-[1.05] sm:text-5xl lg:text-6xl">
            Discover <span className="text-gradient">Premium</span> Technology
          </h1>

          <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground">
            Phones, laptops, audio and wearables from the brands worth owning — filtered, sorted and
            compared in a catalog built for people who research before they buy.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#catalog"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-[1.03]"
            >
              Shop Now <FiArrowRight />
            </a>
            <a
              href="#featured"
              className="glass inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-colors hover:bg-accent"
            >
              Browse featured
            </a>
          </div>

          <dl className="mt-12 grid max-w-md grid-cols-3 gap-4">
            {STATS.map((stat) => (
              <div key={stat.label} className="min-w-0">
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-display text-2xl font-bold sm:text-3xl">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </dd>
                <p className="mt-1 text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </dl>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="relative min-w-0"
        >
          <div className="animate-float surface-card overflow-hidden rounded-[2rem] p-2">
            <img
              src={heroImage}
              alt="Abstract render of glowing glass panels representing premium technology"
              width={1400}
              height={1000}
              className="w-full rounded-[1.6rem] object-cover"
            />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass absolute -bottom-6 left-4 rounded-2xl px-4 py-3 sm:left-8"
          >
            <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Free shipping</p>
            <p className="text-sm font-semibold">On every order over $500</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
