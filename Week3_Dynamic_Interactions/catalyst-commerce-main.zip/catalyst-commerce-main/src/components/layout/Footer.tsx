import { FiGithub, FiTwitter, FiLinkedin } from "react-icons/fi";
import { CATEGORIES } from "@/data/products";

const COLUMNS = [
  { title: "Shop", links: CATEGORIES },
  { title: "Company", links: ["About", "Careers", "Press", "Sustainability"] },
  { title: "Support", links: ["Shipping", "Returns", "Warranty", "Contact"] },
];

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-card/40">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary text-sm font-black text-primary-foreground">
              N
            </span>
            <span className="font-display text-lg font-bold">Nexora</span>
          </div>
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">
            A premium technology catalog — curated hardware, honest specs and a checkout that
            respects your time.
          </p>
          <div className="mt-5 flex gap-2">
            {[FiTwitter, FiGithub, FiLinkedin].map((Icon, index) => (
              <a
                key={index}
                href="#top"
                aria-label="Social link"
                className="glass grid h-9 w-9 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground"
              >
                <Icon size={15} />
              </a>
            ))}
          </div>
        </div>

        {COLUMNS.map((column) => (
          <div key={column.title} className="min-w-0">
            <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              {column.title}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {column.links.map((link) => (
                <li key={link}>
                  <a href="#catalog" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground sm:px-6">
        © {new Date().getFullYear()} Nexora. Built as a frontend engineering showcase.
      </div>
    </footer>
  );
}
