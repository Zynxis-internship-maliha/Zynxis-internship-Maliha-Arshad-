import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { FiHeart, FiShoppingBag, FiSun, FiMoon, FiSearch, FiMenu, FiX } from "react-icons/fi";

interface NavbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  wishlistCount: number;
  cartCount: number;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onOpenWishlist: () => void;
  onOpenCart: () => void;
}

const LINKS = [
  { label: "Catalog", href: "#catalog" },
  { label: "Featured", href: "#featured" },
  { label: "Trending", href: "#trending" },
];

export function Navbar({
  search,
  onSearchChange,
  wishlistCount,
  cartCount,
  theme,
  onToggleTheme,
  onOpenWishlist,
  onOpenCart,
}: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [elevated, setElevated] = useState(false);

  useEffect(() => {
    const onScroll = () => setElevated(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const iconButton =
    "relative grid h-10 w-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground";

  const badge = (count: number) =>
    count > 0 && (
      <motion.span
        key={count}
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-gradient-primary px-1 text-[10px] font-bold text-primary-foreground"
      >
        {count}
      </motion.span>
    );

  return (
    <header
      className={`glass sticky top-0 z-50 transition-shadow duration-300 ${
        elevated ? "shadow-[var(--shadow-soft)]" : ""
      }`}
    >
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-3 sm:px-6 lg:grid-cols-[auto_minmax(0,1fr)_auto]">
        <a href="#top" className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-primary text-sm font-black text-primary-foreground">
            N
          </span>
          <span className="truncate font-display text-lg font-bold tracking-tight">Nexora</span>
        </a>

        <div className="hidden items-center gap-6 lg:flex">
          <nav aria-label="Main" className="flex items-center gap-5">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="relative min-w-0 flex-1">
            <FiSearch className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={search}
              onChange={(event) => onSearchChange(event.target.value)}
              placeholder="Search the catalog…"
              aria-label="Search the catalog"
              className="h-10 w-full rounded-xl border border-input bg-elevated pl-10 pr-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary"
            />
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          <button onClick={onToggleTheme} className={iconButton} aria-label="Toggle dark mode">
            {theme === "dark" ? <FiSun /> : <FiMoon />}
          </button>
          <button onClick={onOpenWishlist} className={iconButton} aria-label={`Wishlist, ${wishlistCount} items`}>
            <FiHeart />
            {badge(wishlistCount)}
          </button>
          <button onClick={onOpenCart} className={iconButton} aria-label={`Cart, ${cartCount} items`}>
            <FiShoppingBag />
            {badge(cartCount)}
          </button>
          <button
            onClick={() => setMenuOpen((open) => !open)}
            className={`${iconButton} lg:hidden`}
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
          >
            {menuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          className="overflow-hidden border-t border-border px-4 pb-4 lg:hidden"
        >
          <div className="relative mt-3">
            <FiSearch className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={search}
              onChange={(event) => onSearchChange(event.target.value)}
              placeholder="Search the catalog…"
              aria-label="Search the catalog"
              className="h-10 w-full rounded-xl border border-input bg-elevated pl-10 pr-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <nav aria-label="Mobile" className="mt-3 flex flex-col">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-2 py-2.5 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </motion.div>
      )}
    </header>
  );
}
