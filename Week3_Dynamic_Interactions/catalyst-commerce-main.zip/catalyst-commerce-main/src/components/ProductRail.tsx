import { motion } from "framer-motion";
import { FiArrowUpRight, FiTrendingUp, FiClock } from "react-icons/fi";
import { finalPrice, type Product } from "@/data/products";
import { formatCurrency, formatCompact } from "@/utils/format";
import { StarRating } from "./StarRating";

interface RailProps {
  title: string;
  subtitle?: string;
  products: Product[];
  variant?: "featured" | "trending" | "recent";
  onSelect: (product: Product) => void;
}

const ICONS = {
  featured: FiArrowUpRight,
  trending: FiTrendingUp,
  recent: FiClock,
};

export function ProductRail({ title, subtitle, products, variant = "featured", onSelect }: RailProps) {
  if (products.length === 0) return null;
  const Icon = ICONS[variant];

  return (
    <section className="mt-16" aria-label={title}>
      <header className="mb-5 flex items-end justify-between gap-4">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
            <Icon className="text-primary" /> {title}
          </h2>
          {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </header>

      <div className="no-scrollbar -mx-1 flex snap-x snap-mandatory gap-4 overflow-x-auto px-1 pb-2">
        {products.map((product, index) => (
          <motion.button
            key={product.id}
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.4, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
            whileHover={{ y: -5 }}
            onClick={() => onSelect(product)}
            className="surface-card group w-[260px] shrink-0 snap-start overflow-hidden rounded-2xl p-3 text-left transition-shadow hover:shadow-[var(--shadow-glow)]"
          >
            <img
              src={product.image}
              alt={product.title}
              loading="lazy"
              className="aspect-4/3 w-full rounded-xl bg-elevated object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="px-1 pt-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
                {product.brand}
              </p>
              <p className="mt-1 truncate text-sm font-semibold">{product.title}</p>
              <div className="mt-1.5">
                <StarRating rating={product.rating} showValue={false} size={12} />
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-base font-bold">{formatCurrency(finalPrice(product))}</span>
                <span className="text-[11px] text-muted-foreground">
                  {formatCompact(product.sold)} sold
                </span>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </section>
  );
}
