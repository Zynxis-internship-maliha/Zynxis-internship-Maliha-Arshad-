import { motion, AnimatePresence } from "framer-motion";
import { FiSearch, FiSliders, FiX, FiChevronDown } from "react-icons/fi";
import { useState } from "react";
import { BRANDS, CATEGORIES, MAX_PRICE, type Brand, type Category } from "@/data/products";
import { SORT_OPTIONS, type Filters, type SortKey } from "@/hooks/useCatalog";
import { formatCurrency } from "@/utils/format";

interface FilterToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  filters: Filters;
  onFiltersChange: (updater: (current: Filters) => Filters) => void;
  sort: SortKey;
  onSortChange: (sort: SortKey) => void;
  resultCount: number;
  activeFilterCount: number;
  onReset: () => void;
}

const toggleValue = <T,>(list: T[], value: T) =>
  list.includes(value) ? list.filter((item) => item !== value) : [...list, value];

export function FilterToolbar({
  search,
  onSearchChange,
  filters,
  onFiltersChange,
  sort,
  onSortChange,
  resultCount,
  activeFilterCount,
  onReset,
}: FilterToolbarProps) {
  const [panelOpen, setPanelOpen] = useState(false);

  const chip = (active: boolean) =>
    `rounded-full px-4 py-2 text-xs font-semibold transition-all duration-200 ${
      active
        ? "bg-gradient-primary text-primary-foreground shadow-[var(--shadow-glow)]"
        : "glass text-muted-foreground hover:text-foreground"
    }`;

  return (
    <section className="surface-card sticky top-[72px] z-40 rounded-3xl p-4 sm:p-5" aria-label="Search and filters">
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_auto_auto]">
        <div className="relative min-w-0">
          <FiSearch className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="search"
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search products, brands, tags…"
            aria-label="Search products"
            className="h-11 w-full rounded-xl border border-input bg-elevated pl-11 pr-10 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary"
          />
          {search && (
            <button
              onClick={() => onSearchChange("")}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
            >
              <FiX size={14} />
            </button>
          )}
        </div>

        <div className="relative">
          <select
            value={sort}
            onChange={(event) => onSortChange(event.target.value as SortKey)}
            aria-label="Sort products"
            className="h-11 w-full min-w-[190px] appearance-none rounded-xl border border-input bg-elevated pl-4 pr-10 text-sm outline-none transition-colors focus:border-primary"
          >
            {SORT_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <FiChevronDown className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
        </div>

        <button
          onClick={() => setPanelOpen((open) => !open)}
          aria-expanded={panelOpen}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-input bg-elevated px-4 text-sm font-semibold transition-colors hover:border-primary"
        >
          <FiSliders /> Filters
          {activeFilterCount > 0 && (
            <span className="grid h-5 min-w-5 place-items-center rounded-full bg-gradient-primary px-1.5 text-[11px] text-primary-foreground">
              {activeFilterCount}
            </span>
          )}
        </button>
      </div>

      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => onFiltersChange((current) => ({ ...current, categories: [] }))}
          className={chip(filters.categories.length === 0)}
        >
          All
        </button>
        {CATEGORIES.map((category) => (
          <button
            key={category}
            onClick={() =>
              onFiltersChange((current) => ({
                ...current,
                categories: toggleValue<Category>(current.categories, category),
              }))
            }
            aria-pressed={filters.categories.includes(category)}
            className={`${chip(filters.categories.includes(category))} whitespace-nowrap`}
          >
            {category}
          </button>
        ))}
      </div>

      <AnimatePresence initial={false}>
        {panelOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="mt-4 grid gap-6 border-t border-border pt-5 md:grid-cols-3">
              <fieldset className="min-w-0">
                <legend className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Brand
                </legend>
                <div className="flex flex-wrap gap-2">
                  {BRANDS.map((brand) => (
                    <button
                      key={brand}
                      onClick={() =>
                        onFiltersChange((current) => ({
                          ...current,
                          brands: toggleValue<Brand>(current.brands, brand),
                        }))
                      }
                      aria-pressed={filters.brands.includes(brand)}
                      className={chip(filters.brands.includes(brand))}
                    >
                      {brand}
                    </button>
                  ))}
                </div>
              </fieldset>

              <div className="min-w-0">
                <p className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Price range
                </p>
                <div className="space-y-3">
                  <input
                    type="range"
                    min={0}
                    max={MAX_PRICE}
                    step={50}
                    value={filters.priceRange[1]}
                    aria-label="Maximum price"
                    onChange={(event) =>
                      onFiltersChange((current) => ({
                        ...current,
                        priceRange: [current.priceRange[0], Number(event.target.value)],
                      }))
                    }
                    className="w-full accent-[var(--primary)]"
                  />
                  <input
                    type="range"
                    min={0}
                    max={MAX_PRICE}
                    step={50}
                    value={filters.priceRange[0]}
                    aria-label="Minimum price"
                    onChange={(event) =>
                      onFiltersChange((current) => ({
                        ...current,
                        priceRange: [
                          Math.min(Number(event.target.value), current.priceRange[1]),
                          current.priceRange[1],
                        ],
                      }))
                    }
                    className="w-full accent-[var(--primary)]"
                  />
                  <p className="text-sm font-medium">
                    {formatCurrency(filters.priceRange[0])} – {formatCurrency(filters.priceRange[1])}
                  </p>
                </div>
              </div>

              <div className="min-w-0 space-y-4">
                <div>
                  <p className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Minimum rating
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {[0, 3, 4, 4.5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => onFiltersChange((current) => ({ ...current, minRating: rating }))}
                        aria-pressed={filters.minRating === rating}
                        className={chip(filters.minRating === rating)}
                      >
                        {rating === 0 ? "Any" : `${rating}+`}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {(
                    [
                      ["inStockOnly", "In stock"],
                      ["featuredOnly", "Featured"],
                      ["discountedOnly", "On sale"],
                    ] as const
                  ).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => onFiltersChange((current) => ({ ...current, [key]: !current[key] }))}
                      aria-pressed={filters[key]}
                      className={chip(filters[key])}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
        <p className="text-xs text-muted-foreground">
          <span className="font-semibold text-foreground">{resultCount}</span> products match your
          criteria
        </p>
        {activeFilterCount > 0 && (
          <button
            onClick={onReset}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"
          >
            <FiX size={13} /> Clear all filters
          </button>
        )}
      </div>
    </section>
  );
}
