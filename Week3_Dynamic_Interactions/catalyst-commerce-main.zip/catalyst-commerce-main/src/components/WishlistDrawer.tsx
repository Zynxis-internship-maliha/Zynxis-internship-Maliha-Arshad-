import { motion } from "framer-motion";
import { FiHeart, FiShoppingBag, FiTrash2 } from "react-icons/fi";
import { SideDrawer } from "./SideDrawer";
import { formatCurrency } from "@/utils/format";
import { finalPrice, type Product } from "@/data/products";

interface WishlistDrawerProps {
  open: boolean;
  onClose: () => void;
  items: Product[];
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export function WishlistDrawer({
  open,
  onClose,
  items,
  onToggleWishlist,
  onAddToCart,
}: WishlistDrawerProps) {
  return (
    <SideDrawer open={open} title={`Wishlist (${items.length})`} onClose={onClose}>
      {items.length === 0 ? (
        <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
          <span className="glass grid h-16 w-16 place-items-center rounded-2xl">
            <FiHeart className="text-destructive" size={24} />
          </span>
          <p className="text-sm text-muted-foreground">No saved products yet.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {items.map((product) => (
            <motion.li
              key={product.id}
              layout
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="surface-card flex gap-3 rounded-2xl p-3"
            >
              <img
                src={product.image}
                alt={product.title}
                loading="lazy"
                className="h-20 w-20 shrink-0 rounded-xl bg-elevated object-cover"
              />
              <div className="flex min-w-0 flex-1 flex-col">
                <p className="truncate text-sm font-semibold">{product.title}</p>
                <p className="text-xs text-muted-foreground">{product.brand}</p>
                <div className="mt-auto flex items-center justify-between gap-2 pt-2">
                  <span className="text-sm font-bold">{formatCurrency(finalPrice(product))}</span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => onAddToCart(product)}
                      disabled={product.stock === 0}
                      aria-label={`Add ${product.title} to cart`}
                      className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-primary text-primary-foreground transition-transform hover:scale-105 disabled:opacity-40"
                    >
                      <FiShoppingBag size={13} />
                    </button>
                    <button
                      onClick={() => onToggleWishlist(product)}
                      aria-label={`Remove ${product.title} from wishlist`}
                      className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-destructive"
                    >
                      <FiTrash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.li>
          ))}
        </ul>
      )}
    </SideDrawer>
  );
}
