import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import "../styles/flowsphere.css";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FlowSphere — AI-Powered Productivity for Modern Teams" },
      {
        name: "description",
        content:
          "FlowSphere is the AI productivity platform helping high-performing teams automate workflows, collaborate in real time, and ship faster.",
      },
      { property: "og:title", content: "FlowSphere — AI-Powered Productivity" },
      {
        property: "og:description",
        content:
          "Automate work, collaborate in real time, and unlock smarter analytics with FlowSphere.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: FlowSphereLanding,
});

/* ---------- Inline SVG icons (no external deps) ---------- */
const Icon = {
  Logo: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 12a8 8 0 1 1 16 0M4 12a8 8 0 0 0 16 0M4 12h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  Bolt: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>
  ),
  Chart: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 20V10m6 10V4m6 16v-7m6 7V8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
  ),
  Users: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="9" cy="8" r="3.5" stroke="currentColor" strokeWidth="1.8" /><path d="M2.5 20a6.5 6.5 0 0 1 13 0M17 11a3 3 0 1 0 0-6M22 20a6 6 0 0 0-4-5.66" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
  ),
  Flow: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="3" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.8" /><rect x="15" y="15" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.8" /><path d="M9 6h6a3 3 0 0 1 3 3v6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
  ),
  Cloud: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 18a4 4 0 0 1-.5-7.97A6 6 0 0 1 18 9.5a4.5 4.5 0 0 1-.5 8.5H7Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>
  ),
  Shield: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>
  ),
  Sparkle: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3v6m0 6v6m-9-9h6m6 0h6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
  ),
  Check: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12 5 5 9-11" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
  ),
  Twitter: () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18 3h3l-7 8 8 10h-6l-5-6-6 6H2l8-9L2 3h6l4 5 6-5Z" /></svg>),
  Github: () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48v-1.7c-2.78.6-3.37-1.34-3.37-1.34-.45-1.15-1.11-1.46-1.11-1.46-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.89 1.53 2.34 1.09 2.91.83.09-.65.35-1.1.63-1.35-2.22-.25-4.55-1.11-4.55-4.95 0-1.1.39-1.99 1.03-2.69-.1-.25-.45-1.27.1-2.65 0 0 .84-.27 2.75 1.03A9.5 9.5 0 0 1 12 6.8a9.5 9.5 0 0 1 2.5.34c1.9-1.3 2.74-1.03 2.74-1.03.55 1.38.2 2.4.1 2.65.64.7 1.03 1.59 1.03 2.69 0 3.85-2.34 4.7-4.57 4.95.36.31.68.92.68 1.85v2.75c0 .27.18.58.69.48A10 10 0 0 0 12 2Z" /></svg>),
  Linkedin: () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 4h4v4H4V4Zm0 6h4v10H4V10Zm6 0h4v1.6c.6-1 1.9-1.9 3.6-1.9 3 0 4.4 1.8 4.4 5V20h-4v-4.7c0-1.5-.5-2.5-1.9-2.5-1.3 0-2.1.9-2.1 2.5V20h-4V10Z" /></svg>),
};

function FlowSphereLanding() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="fs-root">
      {/* ============ NAV ============ */}
      <header className="fs-nav">
        <div className="fs-container fs-nav__inner">
          <a href="#top" className="fs-logo" aria-label="FlowSphere home">
            <span className="fs-logo__mark"><Icon.Logo /></span>
            FlowSphere
          </a>

          <nav aria-label="Primary">
            <ul className="fs-nav__links">
              <li><a href="#features">Features</a></li>
              <li><a href="#solutions">Solutions</a></li>
              <li><a href="#pricing">Pricing</a></li>
              <li><a href="#testimonials">Testimonials</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </nav>

          <div className="fs-nav__cta">
            <a href="#signin" className="fs-btn fs-btn--ghost">Sign in</a>
            <a href="#start" className="fs-btn fs-btn--primary">Start Free</a>
          </div>

          <button
            className="fs-nav__burger"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            aria-controls="fs-mobile-menu"
            onClick={() => setMenuOpen((v) => !v)}
          >
            <span className="fs-burger"><span /></span>
          </button>
        </div>

        <div id="fs-mobile-menu" className="fs-mobile" data-open={menuOpen}>
          <ul className="fs-mobile__list">
            <li><a href="#features" onClick={closeMenu}>Features</a></li>
            <li><a href="#solutions" onClick={closeMenu}>Solutions</a></li>
            <li><a href="#pricing" onClick={closeMenu}>Pricing</a></li>
            <li><a href="#testimonials" onClick={closeMenu}>Testimonials</a></li>
            <li><a href="#contact" onClick={closeMenu}>Contact</a></li>
          </ul>
          <div className="fs-mobile__cta">
            <a href="#start" className="fs-btn fs-btn--primary" style={{ width: "100%" }}>Start Free</a>
          </div>
        </div>
      </header>

      <main id="top">
        {/* ============ HERO ============ */}
        <section className="fs-hero">
          <div className="fs-hero__bg" aria-hidden="true" />
          <div className="fs-hero__grid" aria-hidden="true" />
          <div className="fs-container">
            <div className="fs-hero__inner">
              <span className="fs-eyebrow">
                <span className="fs-eyebrow-dot" />
                New · FlowSphere AI 2.0
              </span>
              <h1 className="fs-hero__title">
                Work smarter with <em>AI-powered</em> productivity.
              </h1>
              <p className="fs-hero__sub">
                FlowSphere unifies your workflows, automations and analytics in a single
                workspace—so high-performing teams can ship better work, faster.
              </p>
              <div className="fs-hero__ctas">
                <a href="#start" className="fs-btn fs-btn--primary fs-btn--lg">Start free — no card</a>
                <a href="#demo" className="fs-btn fs-btn--outline fs-btn--lg">Watch demo</a>
              </div>
              <div className="fs-hero__meta">
                <span><span className="fs-check">✓</span> 14-day free trial</span>
                <span><span className="fs-check">✓</span> SOC 2 Type II</span>
                <span><span className="fs-check">✓</span> Cancel anytime</span>
              </div>
            </div>

            {/* Mockup */}
            <div className="fs-mock" role="img" aria-label="FlowSphere dashboard preview">
              <div className="fs-mock__bar">
                <span className="fs-mock__dot" /><span className="fs-mock__dot" /><span className="fs-mock__dot" />
              </div>
              <div className="fs-mock__body">
                <aside className="fs-mock__side">
                  <div className="fs-mock__item fs-mock__item--active" />
                  <div className="fs-mock__item" />
                  <div className="fs-mock__item" />
                  <div className="fs-mock__item" />
                  <div className="fs-mock__item" />
                </aside>
                <div className="fs-mock__main">
                  <div className="fs-mock__tile"><h4>Active users</h4><b>128,402</b></div>
                  <div className="fs-mock__tile"><h4>Automations</h4><b>4,287</b></div>
                  <div className="fs-mock__tile"><h4>Saved hours</h4><b>21,904</b></div>
                  <div className="fs-mock__chart" />
                </div>
              </div>

              <div className="fs-float fs-float--a">
                <span className="fs-float__icon"><Icon.Bolt /></span>
                <span>+34% velocity<small>this quarter</small></span>
              </div>
              <div className="fs-float fs-float--b">
                <span className="fs-float__icon"><Icon.Sparkle /></span>
                <span>AI suggested 12 tasks<small>just now</small></span>
              </div>
            </div>
          </div>
        </section>

        {/* ============ TRUSTED BY ============ */}
        <section className="fs-trusted" aria-label="Trusted by">
          <div className="fs-container">
            <p className="fs-trusted__label">Trusted by teams at</p>
            <div className="fs-logos">
              <span>Northwind</span>
              <span>Acme Co.</span>
              <span>Lumen</span>
              <span>Globex</span>
              <span>Stark</span>
              <span>Vertex</span>
            </div>
          </div>
        </section>

        {/* ============ FEATURES ============ */}
        <section id="features" className="fs-section fs-section--alt">
          <div className="fs-container">
            <header className="fs-section__head">
              <span className="fs-eyebrow"><span className="fs-eyebrow-dot" />Features</span>
              <h2>Everything your team needs to ship faster.</h2>
              <p>Built for modern operators, FlowSphere combines six powerful primitives into one calm, focused workspace.</p>
            </header>

            <div className="fs-features">
              {[
                { i: <Icon.Bolt />, t: "AI Automation", d: "Trigger multi-step workflows from natural language. Let AI handle the busywork." },
                { i: <Icon.Chart />, t: "Smart Analytics", d: "Real-time dashboards with anomaly detection and weekly AI-generated insights." },
                { i: <Icon.Users />, t: "Team Collaboration", d: "Live presence, threaded comments and inline reviews—designed for async teams." },
                { i: <Icon.Flow />, t: "Workflow Builder", d: "Drag-and-drop builder with 200+ integrations. From idea to production in minutes." },
                { i: <Icon.Cloud />, t: "Cloud Sync", d: "Edge-replicated storage keeps your team in sync across devices, instantly." },
                { i: <Icon.Shield />, t: "Advanced Security", d: "SOC 2 Type II, SAML SSO, SCIM provisioning and end-to-end audit logs out of the box." },
              ].map((f) => (
                <article className="fs-feature" key={f.t}>
                  <div className="fs-feature__icon">{f.i}</div>
                  <h3>{f.t}</h3>
                  <p>{f.d}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ============ SHOWCASE ============ */}
        <section id="solutions" className="fs-section">
          <div className="fs-container">
            <header className="fs-section__head">
              <span className="fs-eyebrow"><span className="fs-eyebrow-dot" />Platform</span>
              <h2>One workspace. Every workflow.</h2>
              <p>From planning to shipping, FlowSphere adapts to how your team actually works.</p>
            </header>

            <div className="fs-showcase">
              <div className="fs-show">
                <div className="fs-show__text">
                  <span className="fs-eyebrow"><Icon.Bolt /> Automation</span>
                  <h3>Automate the work nobody wants to do.</h3>
                  <p>Describe an outcome in plain English and FlowSphere generates the workflow, connects the apps, and runs it on autopilot.</p>
                  <ul className="fs-show__list">
                    <li>Natural-language workflow builder</li>
                    <li>200+ native integrations</li>
                    <li>Self-healing on API changes</li>
                  </ul>
                </div>
                <div className="fs-show__visual">
                  <div className="fs-show__panel">
                    <div className="fs-show__row"><span>When new lead</span><b>Trigger</b></div>
                    <div className="fs-show__row"><span>Enrich via AI</span><b>Step 1</b></div>
                    <div className="fs-show__row"><span>Notify #sales</span><b>Step 2</b></div>
                    <div className="fs-show__row"><span>Create CRM record</span><b>Step 3</b></div>
                  </div>
                </div>
              </div>

              <div className="fs-show fs-show--reverse">
                <div className="fs-show__text">
                  <span className="fs-eyebrow"><Icon.Chart /> Analytics</span>
                  <h3>See what matters. Skip what doesn't.</h3>
                  <p>Dashboards that tell stories—curated weekly by FlowSphere AI so your team always knows what changed and why.</p>
                  <ul className="fs-show__list">
                    <li>Anomaly detection out of the box</li>
                    <li>Weekly executive summaries</li>
                    <li>Connect any warehouse in minutes</li>
                  </ul>
                </div>
                <div className="fs-show__visual">
                  <div className="fs-show__panel">
                    <div className="fs-show__row"><span>MRR growth</span><b>+18.4%</b></div>
                    <div className="fs-show__row"><span>Activation rate</span><b>62%</b></div>
                    <div className="fs-show__row"><span>Churn (30d)</span><b>1.2%</b></div>
                    <div className="fs-show__row"><span>NPS</span><b>68</b></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ============ STATS ============ */}
        <section className="fs-section fs-section--alt">
          <div className="fs-container">
            <div className="fs-stats">
              {[
                { n: "100K+", l: "Active users" },
                { n: "500M", l: "Tasks automated" },
                { n: "99.9%", l: "Platform uptime" },
                { n: "120+", l: "Countries served" },
              ].map((s) => (
                <div className="fs-stat" key={s.l}>
                  <div className="fs-stat__num">{s.n}</div>
                  <div className="fs-stat__label">{s.l}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ============ TESTIMONIALS ============ */}
        <section id="testimonials" className="fs-section">
          <div className="fs-container">
            <header className="fs-section__head">
              <span className="fs-eyebrow"><span className="fs-eyebrow-dot" />Loved by teams</span>
              <h2>The productivity stack of choice.</h2>
              <p>Operators, founders and product teams use FlowSphere to move faster without losing context.</p>
            </header>

            <div className="fs-testis">
              {[
                { q: "FlowSphere replaced four tools for us. Our ops team has reclaimed entire days every week.", n: "Sarah Chen", r: "Head of Operations, Northwind", a: "SC" },
                { q: "The AI workflow builder feels like magic. We shipped automations in an afternoon that used to take sprints.", n: "Marcus Lee", r: "Engineering Lead, Lumen", a: "ML" },
                { q: "Beautiful, fast, and genuinely thoughtful product. Our entire org adopted it in a week.", n: "Priya Raman", r: "VP Product, Vertex", a: "PR" },
              ].map((t) => (
                <article className="fs-testi" key={t.n}>
                  <div className="fs-stars" aria-label="5 out of 5 stars">★★★★★</div>
                  <p className="fs-testi__quote">"{t.q}"</p>
                  <div className="fs-testi__author">
                    <div className="fs-avatar" aria-hidden="true">{t.a}</div>
                    <div>
                      <div className="fs-testi__name">{t.n}</div>
                      <div className="fs-testi__role">{t.r}</div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ============ PRICING ============ */}
        <section id="pricing" className="fs-section fs-section--alt">
          <div className="fs-container">
            <header className="fs-section__head">
              <span className="fs-eyebrow"><span className="fs-eyebrow-dot" />Pricing</span>
              <h2>Simple, transparent pricing.</h2>
              <p>Start free. Upgrade when your team is ready. Enterprise-ready at every tier.</p>
            </header>

            <div className="fs-prices">
              <article className="fs-price">
                <div className="fs-price__name">Starter</div>
                <div className="fs-price__amount">$0<span className="fs-price__period">/mo</span></div>
                <p className="fs-price__desc">For individuals exploring the platform.</p>
                <ul className="fs-price__list">
                  <li>Up to 3 workflows</li>
                  <li>Basic analytics</li>
                  <li>Community support</li>
                </ul>
                <a href="#start" className="fs-btn fs-btn--outline">Get started</a>
              </article>

              <article className="fs-price fs-price--feat">
                <span className="fs-badge">Most popular</span>
                <div className="fs-price__name">Professional</div>
                <div className="fs-price__amount">$29<span className="fs-price__period">/user / mo</span></div>
                <p className="fs-price__desc">For growing teams that need to ship.</p>
                <ul className="fs-price__list">
                  <li>Unlimited workflows</li>
                  <li>Advanced analytics & AI insights</li>
                  <li>200+ integrations</li>
                  <li>Priority support</li>
                </ul>
                <a href="#start" className="fs-btn fs-btn--onbrand">Start 14-day trial</a>
              </article>

              <article className="fs-price">
                <div className="fs-price__name">Enterprise</div>
                <div className="fs-price__amount">Custom</div>
                <p className="fs-price__desc">For organizations with advanced needs.</p>
                <ul className="fs-price__list">
                  <li>SSO, SCIM, audit logs</li>
                  <li>Dedicated success manager</li>
                  <li>Custom data residency</li>
                  <li>99.99% SLA</li>
                </ul>
                <a href="#contact" className="fs-btn fs-btn--outline">Contact sales</a>
              </article>
            </div>
          </div>
        </section>

        {/* ============ FAQ ============ */}
        <section className="fs-section">
          <div className="fs-container">
            <header className="fs-section__head">
              <span className="fs-eyebrow"><span className="fs-eyebrow-dot" />FAQ</span>
              <h2>Questions, answered.</h2>
            </header>
            <div className="fs-faq">
              {[
                { q: "How does the free trial work?", a: "All paid plans include a 14-day free trial. No credit card required, and you can cancel anytime—your data stays exportable." },
                { q: "Is my data secure?", a: "FlowSphere is SOC 2 Type II certified, supports SAML SSO, SCIM provisioning and offers end-to-end audit logs for every plan." },
                { q: "Can I integrate FlowSphere with my existing tools?", a: "Yes—we ship 200+ native integrations and offer a fully-typed API plus webhooks for anything custom." },
                { q: "Do you offer discounts for startups or non-profits?", a: "We offer 50% off the Professional plan for eligible startups and qualified non-profits. Reach out via the contact form." },
                { q: "What kind of support is included?", a: "Starter plans include community support. Professional gets priority email support, and Enterprise comes with a dedicated success manager." },
              ].map((f) => (
                <details key={f.q}>
                  <summary>{f.q}</summary>
                  <p>{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ============ CTA ============ */}
        <section className="fs-cta" id="start">
          <div className="fs-container">
            <div className="fs-cta__inner">
              <h2>Ready to flow?</h2>
              <p>Join 100,000+ teams using FlowSphere to automate the boring stuff and focus on the work that matters.</p>
              <div className="fs-cta__btns">
                <a href="#trial" className="fs-btn fs-btn--onbrand fs-btn--lg">Start your free trial</a>
                <a href="#demo" className="fs-btn fs-btn--onbrand-ghost fs-btn--lg">Book a demo</a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ============ FOOTER ============ */}
      <footer className="fs-footer" id="contact">
        <div className="fs-container">
          <div className="fs-footer__grid">
            <div className="fs-footer__brand">
              <a href="#top" className="fs-logo" style={{ color: "#fff" }}>
                <span className="fs-logo__mark"><Icon.Logo /></span>
                FlowSphere
              </a>
              <p>The AI productivity platform for high-performing teams. Build, automate, and ship—calmly.</p>
              <form className="fs-newsletter" onSubmit={(e) => e.preventDefault()} aria-label="Newsletter signup">
                <label htmlFor="fs-newsletter-email" className="sr-only" style={{ position: "absolute", left: "-9999px" }}>Email</label>
                <input id="fs-newsletter-email" type="email" placeholder="you@company.com" required />
                <button type="submit">Subscribe</button>
              </form>
              <div className="fs-social">
                <a href="#" aria-label="Twitter"><Icon.Twitter /></a>
                <a href="#" aria-label="GitHub"><Icon.Github /></a>
                <a href="#" aria-label="LinkedIn"><Icon.Linkedin /></a>
              </div>
            </div>

            <div>
              <h4>Company</h4>
              <ul>
                <li><a href="#">About</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Press</a></li>
                <li><a href="#">Brand</a></li>
              </ul>
            </div>
            <div>
              <h4>Resources</h4>
              <ul>
                <li><a href="#">Docs</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Changelog</a></li>
                <li><a href="#">Community</a></li>
              </ul>
            </div>
            <div>
              <h4>Legal</h4>
              <ul>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Security</a></li>
                <li><a href="#">DPA</a></li>
              </ul>
            </div>
            <div>
              <h4>Product</h4>
              <ul>
                <li><a href="#features">Features</a></li>
                <li><a href="#pricing">Pricing</a></li>
                <li><a href="#solutions">Solutions</a></li>
                <li><a href="#">Integrations</a></li>
              </ul>
            </div>
          </div>

          <div className="fs-footer__bottom">
            <span>© {new Date().getFullYear()} FlowSphere Labs, Inc. All rights reserved.</span>
            <span>Made with care · San Francisco</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
