import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/PageHeader";
import { ErrorState } from "@/components/error/ErrorState";
import { TableSkeleton } from "@/components/skeleton/Skeletons";
import { Button } from "@/components/ui/button";
import { useUsers } from "@/hooks/useUsers";
import { formatNumber, uniqueCount } from "@/utils/analytics";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports — Nexus Analytics" },
      {
        name: "description",
        content: "Generated summaries of the live user dataset, ready to export as CSV.",
      },
      { property: "og:title", content: "Reports — Nexus Analytics" },
      {
        property: "og:description",
        content: "Exportable summaries generated from the live user dataset.",
      },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const { data, isPending, isError, error, refetch } = useUsers();

  if (isPending) return <TableSkeleton rows={6} />;
  if (isError) return <ErrorState error={error} onRetry={() => refetch()} />;

  const users = data.users;
  const reports = [
    { name: "Workforce overview", rows: users.length },
    { name: "Company breakdown", rows: uniqueCount(users, (user) => user.company.name) },
    { name: "Geographic coverage", rows: uniqueCount(users, (user) => user.address.city) },
    { name: "Role & permissions audit", rows: uniqueCount(users, (user) => user.role) },
  ];

  function exportCsv(name: string) {
    const csv = [
      "id,name,email,company,city,age",
      ...users.map((user) =>
        [
          user.id,
          `${user.firstName} ${user.lastName}`,
          user.email,
          user.company.name,
          user.address.city,
          user.age,
        ].join(","),
      ),
    ].join("\n");

    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `${name.toLowerCase().replace(/\s+/g, "-")}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Report exported", { description: `${name} downloaded as CSV.` });
  }

  return (
    <div className="mx-auto w-full max-w-5xl space-y-6">
      <PageHeader title="Reports" description="Export snapshots of the live dataset." />
      <div className="grid gap-4 sm:grid-cols-2">
        {reports.map((report) => (
          <article key={report.name} className="glass-panel gradient-border p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="truncate text-sm font-semibold">{report.name}</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  {formatNumber(report.rows)} records
                </p>
              </div>
              <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary/12 text-primary">
                <FileText className="size-4" aria-hidden="true" />
              </span>
            </div>
            <Button
              variant="secondary"
              size="sm"
              className="mt-4"
              onClick={() => exportCsv(report.name)}
            >
              <Download className="size-4" aria-hidden="true" />
              Export CSV
            </Button>
          </article>
        ))}
      </div>
    </div>
  );
}