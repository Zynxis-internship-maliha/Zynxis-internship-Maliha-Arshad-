import { createFileRoute } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/PageHeader";
import { ApiStatusWidget } from "@/components/dashboard/ApiStatusWidget";
import { RecentApiCalls } from "@/components/dashboard/RecentApiCalls";
import { useUsers } from "@/hooks/useUsers";

export const Route = createFileRoute("/api-status")({
  head: () => ({
    meta: [
      { title: "API Status — Nexus Analytics" },
      {
        name: "description",
        content:
          "Live connection health, response time, status codes and the retry policy applied to every request.",
      },
      { property: "og:title", content: "API Status — Nexus Analytics" },
      {
        property: "og:description",
        content: "Connection health, latency and retry policy for the live REST API.",
      },
    ],
  }),
  component: ApiStatusPage,
});

const ERROR_MATRIX = [
  ["No internet", "Offline card, toast, automatic retry once the connection returns"],
  ["Timeout (>10s)", "Request aborted by Axios, retried up to 3x with backoff"],
  ["500 / 503", "Server error card, 3 automatic retries, manual retry button"],
  ["404", "Not-found card, retries suppressed (never recoverable)"],
  ["429", "Rate-limit card advising a short wait before retrying"],
  ["Invalid payload", "Schema guard rejects the response, retries suppressed"],
];

function ApiStatusPage() {
  const { data, isError } = useUsers();

  return (
    <div className="mx-auto w-full max-w-5xl space-y-6">
      <PageHeader
        title="API status"
        description="Health of the https://dummyjson.com/users integration."
      />
      <div className="grid gap-5 md:grid-cols-2">
        <ApiStatusWidget meta={data?.meta} isError={isError} />
        <RecentApiCalls meta={data?.meta} isError={isError} />
      </div>
      <section className="glass-panel p-5">
        <h2 className="text-sm font-semibold tracking-tight">Error handling matrix</h2>
        <ul className="mt-4 space-y-2.5 text-sm">
          {ERROR_MATRIX.map(([scenario, behaviour]) => (
            <li
              key={scenario}
              className="grid gap-1 rounded-xl border border-border/50 bg-muted/20 p-3 sm:grid-cols-[12rem_minmax(0,1fr)] sm:gap-4"
            >
              <span className="font-medium">{scenario}</span>
              <span className="text-muted-foreground">{behaviour}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}