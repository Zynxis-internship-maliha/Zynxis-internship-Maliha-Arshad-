import { createFileRoute } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/PageHeader";
import { DashboardCharts } from "@/components/dashboard/charts/DashboardCharts";
import { ErrorState } from "@/components/error/ErrorState";
import { ChartsSkeleton } from "@/components/skeleton/Skeletons";
import { useUsers } from "@/hooks/useUsers";

export const Route = createFileRoute("/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — Nexus Analytics" },
      {
        name: "description",
        content:
          "Animated Recharts visualisations of company, city, registration and gender distribution.",
      },
      { property: "og:title", content: "Analytics — Nexus Analytics" },
      {
        property: "og:description",
        content: "Company, city, registration and gender distribution charts.",
      },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const { data, isPending, isError, error, refetch } = useUsers();

  return (
    <div className="mx-auto w-full max-w-[100rem] space-y-6">
      <PageHeader
        title="Analytics"
        description="Distribution insights derived from the live user dataset."
      />
      {isPending ? (
        <ChartsSkeleton />
      ) : isError ? (
        <ErrorState error={error} onRetry={() => refetch()} />
      ) : (
        <DashboardCharts users={data.users} />
      )}
    </div>
  );
}