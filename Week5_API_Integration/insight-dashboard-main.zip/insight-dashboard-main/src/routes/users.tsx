import { createFileRoute } from "@tanstack/react-router";
import { RefreshCw } from "lucide-react";

import { PageHeader } from "@/components/common/PageHeader";
import { UsersTable } from "@/components/dashboard/table/UsersTable";
import { ErrorState } from "@/components/error/ErrorState";
import { TableSkeleton } from "@/components/skeleton/Skeletons";
import { Button } from "@/components/ui/button";
import { useUsers } from "@/hooks/useUsers";

export const Route = createFileRoute("/users")({
  head: () => ({
    meta: [
      { title: "Users — Nexus Analytics" },
      {
        name: "description",
        content:
          "Searchable, sortable and filterable directory of every user returned by the live REST API.",
      },
      { property: "og:title", content: "Users — Nexus Analytics" },
      {
        property: "og:description",
        content: "Search, filter, sort and inspect users from the live REST API.",
      },
    ],
  }),
  component: UsersPage,
});

function UsersPage() {
  const { data, isPending, isError, error, refetch, isFetching } = useUsers();

  return (
    <div className="mx-auto w-full max-w-[100rem] space-y-6">
      <PageHeader
        title="Users"
        description="Every account returned by the API, with instant search and filters."
        actions={
          <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw
              className={isFetching ? "size-4 animate-spin" : "size-4"}
              aria-hidden="true"
            />
            Refresh
          </Button>
        }
      />
      {isPending ? (
        <TableSkeleton rows={10} />
      ) : isError ? (
        <ErrorState error={error} onRetry={() => refetch()} />
      ) : (
        <UsersTable users={data.users} onRefresh={() => refetch()} />
      )}
    </div>
  );
}