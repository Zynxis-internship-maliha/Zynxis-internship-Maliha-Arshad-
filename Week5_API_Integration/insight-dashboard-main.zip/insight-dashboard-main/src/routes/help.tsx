import { createFileRoute } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/PageHeader";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help — Nexus Analytics" },
      {
        name: "description",
        content:
          "How the dashboard fetches data, handles loading, empty and error states, and retries failed requests.",
      },
      { property: "og:title", content: "Help — Nexus Analytics" },
      {
        property: "og:description",
        content: "Documentation for data fetching, states and retry behaviour.",
      },
    ],
  }),
  component: HelpPage,
});

const FAQ = [
  {
    question: "Where does the data come from?",
    answer:
      "Every metric on this dashboard is fetched live from https://dummyjson.com/users through a shared Axios client with request/response interceptors and a 10 second timeout.",
  },
  {
    question: "What happens while data is loading?",
    answer:
      "Skeleton components that mirror the final layout render with a shimmer animation. There is never a plain loading message.",
  },
  {
    question: "What happens when a search returns nothing?",
    answer:
      "An illustrated empty state appears with 'No users found.' plus reset-filters and refresh actions.",
  },
  {
    question: "How are failures handled?",
    answer:
      "Failures are normalised into typed ApiError objects (offline, timeout, 404, 429, 5xx, invalid payload). Recoverable errors retry automatically three times with exponential backoff before an error card with retry, refresh and back-to-dashboard actions is shown.",
  },
  {
    question: "How fresh is the data?",
    answer:
      "Responses are cached for 60 seconds, refetched in the background every 60 seconds, and refreshed whenever the window regains focus.",
  },
];

function HelpPage() {
  return (
    <div className="mx-auto w-full max-w-3xl space-y-6">
      <PageHeader title="Help" description="How this dashboard consumes and protects its API." />
      <section className="glass-panel p-5">
        <Accordion type="single" collapsible>
          {FAQ.map((item) => (
            <AccordionItem key={item.question} value={item.question}>
              <AccordionTrigger className="text-left text-sm">{item.question}</AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </div>
  );
}