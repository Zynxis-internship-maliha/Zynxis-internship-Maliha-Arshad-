import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/PageHeader";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Nexus Analytics" },
      {
        name: "description",
        content: "Configure polling, retries, notifications and data preferences for the dashboard.",
      },
      { property: "og:title", content: "Settings — Nexus Analytics" },
      {
        property: "og:description",
        content: "Polling, retry and notification preferences for your dashboard.",
      },
    ],
  }),
  component: SettingsPage,
});

const OPTIONS = [
  {
    id: "polling",
    label: "Background polling",
    hint: "Refetch the users endpoint every 60 seconds.",
    defaultOn: true,
  },
  {
    id: "retries",
    label: "Automatic retries",
    hint: "Retry failed requests 3 times with exponential backoff.",
    defaultOn: true,
  },
  {
    id: "toasts",
    label: "Toast notifications",
    hint: "Surface success, warning and error states as toasts.",
    defaultOn: true,
  },
  {
    id: "focus",
    label: "Refetch on window focus",
    hint: "Keep metrics fresh when you return to the tab.",
    defaultOn: true,
  },
];

function SettingsPage() {
  return (
    <div className="mx-auto w-full max-w-3xl space-y-6">
      <PageHeader title="Settings" description="Tune how the dashboard talks to the API." />
      <section className="glass-panel divide-y divide-border/50">
        {OPTIONS.map((option) => (
          <div key={option.id} className="flex items-center justify-between gap-4 p-5">
            <div className="min-w-0">
              <Label htmlFor={option.id} className="text-sm font-medium">
                {option.label}
              </Label>
              <p className="mt-1 text-xs text-muted-foreground">{option.hint}</p>
            </div>
            <Switch
              id={option.id}
              defaultChecked={option.defaultOn}
              onCheckedChange={(checked) =>
                toast.info(`${option.label} ${checked ? "enabled" : "disabled"}`)
              }
            />
          </div>
        ))}
      </section>
    </div>
  );
}