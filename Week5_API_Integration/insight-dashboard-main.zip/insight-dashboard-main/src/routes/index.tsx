import { createFileRoute } from "@tanstack/react-router";
import { Building2, Gauge, Globe2, RefreshCw, ShieldCheck, UserCheck, Users } from "lucide-react";
import { useMemo } from "react";

import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { ApiStatusWidget } from "@/components/dashboard/ApiStatusWidget";
import { RecentApiCalls } from "@/components/dashboard/RecentApiCalls";
import { StatCard } from "@/components/dashboard/cards/StatCard";
import { DashboardCharts } from "@/components/dashboard/charts/DashboardCharts";
import { UsersTable } from "@/components/dashboard/table/UsersTable";
import { PageHeader } from "@/components/common/PageHeader";
import { ErrorState } from "@/components/error/ErrorState";
import { DashboardSkeleton } from "@/components/skeleton/Skeletons";
import { Button } from "@/components/ui/button";
import { useUsers } from "@/hooks/useUsers";
import { activeUsers, formatNumber, uniqueCount } from "@/utils/analytics";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nexus Analytics — Live API Dashboard" },
      {
        name: "description",
        content:
          "Live REST API dashboard with real-time metrics, charts, loading skeletons, empty states and resilient error handling.",
      },
      { property: "og:title", content: "Nexus Analytics — Live API Dashboard" },
      {
        property: "og:description",
        content: "Real-time user metrics, charts and API health from a live REST API.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { data, isPending, isError, error, refetch, isFetching } = useUsers();
  const users = useMemo(() => data?.users ?? [], [data]);

  const stats = useMemo(() => {
    if (users.length === 0) return [];
    const active = activeUsers(users);
    return [
      {
        label: "Total users",
        value: formatNumber(data?.total ?? users.length),
        delta: "Synced from /users",
        icon: Users,
        tone: "primary" as const,
      },
      {
        label: "Active users",
        value: formatNumber(active),
        delta: `${Math.round((active / users.length) * 100)}% of all accounts`,
        icon: UserCheck,
        tone: "success" as const,
      },
      {
        label: "Companies",
        value: formatNumber(uniqueCount(users, (user) => user.company.name)),
        delta: "Unique employers",
        icon: Building2,
        tone: "accent" as const,
      },
      {
        label: "Countries",
        value: formatNumber(uniqueCount(users, (user) => user.address.country)),
        delta: "Geographic coverage",
        icon: Globe2,
        tone: "primary" as const,
      },
      {
        label: "API response time",
        value: `${data?.meta.durationMs ?? 0} ms`,
        delta: "Last request round-trip",
        icon: Gauge,
        tone: "warning" as const,
      },
      {
        label: "Success rate",
        value: isError ? "0%" : "100%",
        delta: "Rolling request window",
        icon: ShieldCheck,
        tone: "success" as const,
      },
    ];
  }, [users, data, isError]);

  return (
    <div className="mx-auto w-full max-w-[100rem] space-y-6">
      <PageHeader
        title="Dashboard"
        description="Live metrics streamed from the DummyJSON REST API."
        actions={
          <>
            <ApiStatusWidget meta={data?.meta} isError={isError} compact />
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              disabled={isFetching}
              aria-label="Refresh data"
            >
              <RefreshCw
                className={isFetching ? "size-4 animate-spin" : "size-4"}
                aria-hidden="true"
              />
              Refresh
            </Button>
          </>
        }
      />

      {isPending ? (
        <DashboardSkeleton />
      ) : isError ? (
        <ErrorState error={error} onRetry={() => refetch()} showHomeLink={false} />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {stats.map((stat, index) => (
              <StatCard key={stat.label} index={index} {...stat} />
            ))}
          </div>

          <DashboardCharts users={users} />

          <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_20rem]">
            <UsersTable users={users} onRefresh={() => refetch()} />
            <div className="space-y-5">
              <ApiStatusWidget meta={data?.meta} isError={isError} />
              <ActivityFeed users={users} />
              <RecentApiCalls meta={data?.meta} isError={isError} />
            </div>
          </div>
        </>
      )}
    </div>
  );
}