import axios, { AxiosError, type AxiosInstance, type InternalAxiosRequestConfig } from "axios";

/**
 * Centralised HTTP client.
 * Every request is timed (used by the API Status widget) and every failure is
 * normalised into an `ApiError` so the UI never branches on transport details.
 * See README "Error Logic" for the full matrix.
 */
export type ApiErrorKind =
  | "offline"
  | "timeout"
  | "not_found"
  | "rate_limited"
  | "server"
  | "client"
  | "invalid_response"
  | "unknown";

export class ApiError extends Error {
  readonly kind: ApiErrorKind;
  readonly status?: number | undefined;
  readonly hint: string;

  constructor(kind: ApiErrorKind, message: string, hint: string, status?: number) {
    super(message);
    this.name = "ApiError";
    this.kind = kind;
    this.hint = hint;
    this.status = status;
  }

  /** Retrying a 404 or a malformed payload will never succeed. */
  get retryable(): boolean {
    return this.kind !== "not_found" && this.kind !== "invalid_response";
  }
}

type TimedConfig = InternalAxiosRequestConfig & { metadata?: { start: number } };

export const apiClient: AxiosInstance = axios.create({
  baseURL: "https://dummyjson.com",
  timeout: 10_000,
  headers: { "Content-Type": "application/json", Accept: "application/json" },
});

apiClient.interceptors.request.use((config: TimedConfig) => {
  config.metadata = { start: Date.now() };
  return config;
});

apiClient.interceptors.response.use(
  (response) => {
    const config = response.config as TimedConfig;
    response.headers["x-duration-ms"] = String(Date.now() - (config.metadata?.start ?? Date.now()));
    return response;
  },
  (error: AxiosError) => Promise.reject(toApiError(error)),
);

export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error;

  if (axios.isAxiosError(error)) {
    if (error.code === "ECONNABORTED" || error.code === "ETIMEDOUT") {
      return new ApiError(
        "timeout",
        "The request took too long to complete.",
        "The service is responding slowly. Retrying usually resolves this.",
      );
    }

    if (!error.response) {
      const offline = typeof navigator !== "undefined" && navigator.onLine === false;
      return offline
        ? new ApiError(
            "offline",
            "You appear to be offline.",
            "Check your internet connection, then retry.",
          )
        : new ApiError(
            "unknown",
            "The network request failed.",
            "We could not reach the API. Please retry in a moment.",
          );
    }

    const status = error.response.status;
    if (status === 404) {
      return new ApiError(
        "not_found",
        "The requested resource was not found.",
        "The endpoint may have moved. Head back to the dashboard.",
        status,
      );
    }
    if (status === 429) {
      return new ApiError(
        "rate_limited",
        "API rate limit reached.",
        "Too many requests were made. Wait a few seconds and retry.",
        status,
      );
    }
    if (status >= 500) {
      return new ApiError(
        "server",
        "The API returned a server error.",
        "This is a problem on the provider's side. Automatic retries are running.",
        status,
      );
    }
    return new ApiError(
      "client",
      `Request rejected with status ${status}.`,
      "The request could not be processed as sent.",
      status,
    );
  }

  return new ApiError(
    "unknown",
    error instanceof Error ? error.message : "An unexpected error occurred.",
    "Something unexpected happened. Please retry.",
  );
}