import { apiClient, ApiError } from "./api";
import type { User, UsersResponse, UsersResult } from "@/types/user";

const USER_FIELDS =
  "firstName,lastName,age,gender,email,phone,username,birthDate,image,role,address,company,university,bloodGroup";

function isUser(value: unknown): value is User {
  const candidate = value as User | null;
  return Boolean(candidate && typeof candidate.id === "number" && candidate.company);
}

/** Fetches the full user dataset in a single call and validates the payload shape. */
export async function fetchUsers(): Promise<UsersResult> {
  const response = await apiClient.get<UsersResponse>("/users", {
    params: { limit: 208, select: USER_FIELDS },
  });

  const payload = response.data;
  if (!payload || !Array.isArray(payload.users) || !payload.users.every(isUser)) {
    throw new ApiError(
      "invalid_response",
      "The API returned data in an unexpected format.",
      "The response did not match the expected schema, so it was rejected.",
      response.status,
    );
  }

  return {
    users: payload.users,
    total: payload.total ?? payload.users.length,
    meta: {
      durationMs: Number(response.headers["x-duration-ms"] ?? 0),
      status: response.status,
      receivedAt: Date.now(),
    },
  };
}