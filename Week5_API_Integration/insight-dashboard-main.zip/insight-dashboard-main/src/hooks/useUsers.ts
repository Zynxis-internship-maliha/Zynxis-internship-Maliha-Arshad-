import { useQuery, type UseQueryResult } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { toast } from "sonner";

import { fetchUsers } from "@/services/users.service";
import { ApiError } from "@/services/api";
import type { UsersResult } from "@/types/user";

export const usersQueryKey = ["users"] as const;

/**
 * Live users query.
 * Retries transient failures 3x with exponential backoff, keeps data fresh for
 * 60s, refetches in the background every 60s, and surfaces toasts on state
 * transitions (success / failure) without duplicating them on every render.
 */
export function useUsers(): UseQueryResult<UsersResult, ApiError> {
  const query = useQuery<UsersResult, ApiError>({
    queryKey: usersQueryKey,
    queryFn: fetchUsers,
    staleTime: 60_000,
    gcTime: 5 * 60_000,
    refetchInterval: 60_000,
    refetchOnWindowFocus: true,
    retry: (failureCount, error) => error.retryable && failureCount < 3,
    retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 8000),
  });

  const notified = useRef<"success" | "error" | null>(null);
  const { isSuccess, isError, error, dataUpdatedAt } = query;

  useEffect(() => {
    if (isSuccess && notified.current !== "success") {
      notified.current = "success";
      toast.success("Data loaded successfully", {
        description: "Live user metrics are up to date.",
      });
    }
    if (isError && notified.current !== "error") {
      notified.current = "error";
      toast.error("Unable to fetch data", { description: error?.hint });
    }
  }, [isSuccess, isError, error, dataUpdatedAt]);

  return query;
}