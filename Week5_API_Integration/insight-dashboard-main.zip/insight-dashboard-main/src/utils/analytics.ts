import type { User } from "@/types/user";

export interface ChartDatum {
  name: string;
  value: number;
}

function topCounts(values: string[], limit: number): ChartDatum[] {
  const counts = new Map<string, number>();
  for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
  return [...counts.entries()]
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, limit);
}

export function usersByCompany(users: User[], limit = 8): ChartDatum[] {
  return topCounts(
    users.map((user) => user.company.name),
    limit,
  );
}

export function usersByCity(users: User[], limit = 8): ChartDatum[] {
  return topCounts(
    users.map((user) => user.address.city),
    limit,
  );
}

export function usersByGender(users: User[]): ChartDatum[] {
  return topCounts(
    users.map((user) => (user.gender === "male" ? "Male" : "Female")),
    4,
  );
}

/** Registration distribution grouped by birth-year decade. */
export function registrationDistribution(users: User[]): ChartDatum[] {
  const buckets = new Map<string, number>();
  for (const user of users) {
    const year = new Date(user.birthDate).getFullYear();
    if (Number.isNaN(year)) continue;
    const decade = `${Math.floor(year / 10) * 10}s`;
    buckets.set(decade, (buckets.get(decade) ?? 0) + 1);
  }
  return [...buckets.entries()]
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export function uniqueCount(users: User[], pick: (user: User) => string): number {
  return new Set(users.map(pick)).size;
}

export function activeUsers(users: User[]): number {
  // The dataset has no session flag; treat working-age accounts as active.
  return users.filter((user) => user.age >= 21 && user.age <= 55).length;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-US").format(value);
}

export function initials(first: string, last: string): string {
  return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
}