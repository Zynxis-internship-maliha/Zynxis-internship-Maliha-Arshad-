import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Search } from "lucide-react";
import { useCallback, useMemo, useState } from "react";

import { EmptyState } from "@/components/empty/EmptyState";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UserDetailsModal } from "@/components/dashboard/modals/UserDetailsModal";
import { useDebouncedValue } from "@/hooks/useDebouncedValue";
import { cn } from "@/lib/utils";
import type { User } from "@/types/user";
import { initials } from "@/utils/analytics";

type SortKey = "name" | "age" | "company" | "city";
type SortDir = "asc" | "desc";

const PAGE_SIZE = 8;
const ALL = "all";

function sortValue(user: User, key: SortKey): string | number {
  switch (key) {
    case "age":
      return user.age;
    case "company":
      return user.company.name;
    case "city":
      return user.address.city;
    default:
      return `${user.firstName} ${user.lastName}`;
  }
}

export function UsersTable({ users, onRefresh }: { users: User[]; onRefresh: () => void }) {
  const [rawQuery, setRawQuery] = useState("");
  const [company, setCompany] = useState(ALL);
  const [gender, setGender] = useState(ALL);
  const [city, setCity] = useState(ALL);
  const [ageBand, setAgeBand] = useState(ALL);
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<User | null>(null);

  const query = useDebouncedValue(rawQuery, 250).trim().toLowerCase();

  const companies = useMemo(
    () => [...new Set(users.map((u) => u.company.name))].sort().slice(0, 40),
    [users],
  );
  const cities = useMemo(() => [...new Set(users.map((u) => u.address.city))].sort(), [users]);

  const filtered = useMemo(() => {
    const result = users.filter((user) => {
      const haystack =
        `${user.firstName} ${user.lastName} ${user.email} ${user.company.name} ${user.phone}`.toLowerCase();
      if (query && !haystack.includes(query)) return false;
      if (company !== ALL && user.company.name !== company) return false;
      if (gender !== ALL && user.gender !== gender) return false;
      if (city !== ALL && user.address.city !== city) return false;
      if (ageBand !== ALL) {
        const [min, max] = ageBand.split("-").map(Number);
        if (user.age < (min ?? 0) || user.age > (max ?? 200)) return false;
      }
      return true;
    });

    return result.sort((a, b) => {
      const left = sortValue(a, sortKey);
      const right = sortValue(b, sortKey);
      const comparison =
        typeof left === "number" && typeof right === "number"
          ? left - right
          : String(left).localeCompare(String(right));
      return sortDir === "asc" ? comparison : -comparison;
    });
  }, [users, query, company, gender, city, ageBand, sortKey, sortDir]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const rows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const resetFilters = useCallback(() => {
    setRawQuery("");
    setCompany(ALL);
    setGender(ALL);
    setCity(ALL);
    setAgeBand(ALL);
    setPage(1);
  }, []);

  const toggleSort = useCallback((key: SortKey) => {
    setSortKey((previous) => {
      setSortDir((dir) => (previous === key && dir === "asc" ? "desc" : "asc"));
      return key;
    });
    setPage(1);
  }, []);

  const SortButton = ({ label, sortKeyName }: { label: string; sortKeyName: SortKey }) => (
    <button
      type="button"
      onClick={() => toggleSort(sortKeyName)}
      className="inline-flex items-center gap-1 rounded-md text-xs font-medium tracking-wide text-muted-foreground uppercase transition-colors hover:text-foreground"
      aria-label={`Sort by ${label}`}
    >
      {label}
      {sortKey === sortKeyName ? (
        sortDir === "asc" ? (
          <ArrowUp className="size-3" aria-hidden="true" />
        ) : (
          <ArrowDown className="size-3" aria-hidden="true" />
        )
      ) : null}
    </button>
  );

  return (
    <section className="glass-panel overflow-hidden" aria-label="Users">
      <header className="grid gap-3 border-b border-border/60 p-4 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
        <div className="relative min-w-0">
          <Search
            className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            value={rawQuery}
            onChange={(event) => {
              setRawQuery(event.target.value);
              setPage(1);
            }}
            placeholder="Search name, email, company or phone"
            aria-label="Search users"
            className="h-10 pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Select
            value={company}
            onValueChange={(value) => {
              setCompany(value);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-10 w-[9.5rem]" aria-label="Filter by company">
              <SelectValue placeholder="Company" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All companies</SelectItem>
              {companies.map((name) => (
                <SelectItem key={name} value={name}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={city}
            onValueChange={(value) => {
              setCity(value);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-10 w-[8.5rem]" aria-label="Filter by city">
              <SelectValue placeholder="City" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All cities</SelectItem>
              {cities.map((name) => (
                <SelectItem key={name} value={name}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={gender}
            onValueChange={(value) => {
              setGender(value);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-10 w-[7.5rem]" aria-label="Filter by gender">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All genders</SelectItem>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={ageBand}
            onValueChange={(value) => {
              setAgeBand(value);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-10 w-[7.5rem]" aria-label="Filter by age">
              <SelectValue placeholder="Age" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>All ages</SelectItem>
              <SelectItem value="18-29">18 – 29</SelectItem>
              <SelectItem value="30-39">30 – 39</SelectItem>
              <SelectItem value="40-49">40 – 49</SelectItem>
              <SelectItem value="50-99">50+</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </header>

      {rows.length === 0 ? (
        <EmptyState onReset={resetFilters} onRefresh={onRefresh} />
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[46rem] border-collapse text-sm">
              <thead className="sticky top-0 z-10 bg-surface/85 backdrop-blur">
                <tr className="border-b border-border/60 text-left">
                  <th scope="col" className="px-4 py-3">
                    <SortButton label="User" sortKeyName="name" />
                  </th>
                  <th scope="col" className="px-4 py-3">
                    <SortButton label="Company" sortKeyName="company" />
                  </th>
                  <th scope="col" className="px-4 py-3">
                    <SortButton label="City" sortKeyName="city" />
                  </th>
                  <th scope="col" className="px-4 py-3">
                    <SortButton label="Age" sortKeyName="age" />
                  </th>
                  <th
                    scope="col"
                    className="px-4 py-3 text-xs font-medium tracking-wide text-muted-foreground uppercase"
                  >
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {rows.map((user) => (
                  <tr
                    key={user.id}
                    tabIndex={0}
                    role="button"
                    aria-label={`View details for ${user.firstName} ${user.lastName}`}
                    onClick={() => setSelected(user)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        setSelected(user);
                      }
                    }}
                    className={cn(
                      "cursor-pointer border-b border-border/40 transition-colors",
                      "hover:bg-muted/40 focus-visible:bg-muted/40",
                    )}
                  >
                    <td className="px-4 py-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <Avatar className="size-9 shrink-0 border border-border">
                          <AvatarImage src={user.image} alt="" loading="lazy" />
                          <AvatarFallback>{initials(user.firstName, user.lastName)}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="truncate font-medium">
                            {user.firstName} {user.lastName}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="secondary" className="max-w-40 truncate">
                        {user.company.name}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{user.address.city}</td>
                    <td className="px-4 py-3 tabular-nums">{user.age}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-success/12 px-2.5 py-1 text-xs font-medium text-success">
                        <span className="size-1.5 rounded-full bg-success" aria-hidden="true" />
                        {user.role === "admin" ? "Admin" : "Active"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-border/60 p-4">
            <p className="text-xs text-muted-foreground">
              Showing {(currentPage - 1) * PAGE_SIZE + 1}–
              {Math.min(currentPage * PAGE_SIZE, filtered.length)} of {filtered.length} users
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                aria-label="Previous page"
              >
                <ChevronLeft className="size-4" aria-hidden="true" />
              </Button>
              <span className="text-xs text-muted-foreground tabular-nums">
                Page {currentPage} / {pageCount}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
                disabled={currentPage === pageCount}
                aria-label="Next page"
              >
                <ChevronRight className="size-4" aria-hidden="true" />
              </Button>
            </div>
          </footer>
        </>
      )}

      <UserDetailsModal user={selected} onOpenChange={(open) => !open && setSelected(null)} />
    </section>
  );
}