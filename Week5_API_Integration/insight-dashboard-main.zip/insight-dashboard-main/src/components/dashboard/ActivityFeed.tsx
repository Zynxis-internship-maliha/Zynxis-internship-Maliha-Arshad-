import { motion } from "framer-motion";
import { memo } from "react";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { User } from "@/types/user";
import { initials } from "@/utils/analytics";

const EVENTS = [
  "signed in from a new device",
  "updated their profile details",
  "was granted API access",
  "exported an analytics report",
  "joined the workspace",
  "rotated their access token",
];

export const ActivityFeed = memo(function ActivityFeed({ users }: { users: User[] }) {
  const recent = users.slice(0, 6);

  return (
    <section className="glass-panel p-5" aria-label="Activity feed">
      <h3 className="text-sm font-semibold tracking-tight">Activity feed</h3>
      <ul className="mt-4 space-y-4">
        {recent.map((user, index) => (
          <motion.li
            key={user.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.35, delay: index * 0.05 }}
            className="flex min-w-0 items-center gap-3"
          >
            <Avatar className="size-8 shrink-0 border border-border">
              <AvatarImage src={user.image} alt="" loading="lazy" />
              <AvatarFallback>{initials(user.firstName, user.lastName)}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="truncate text-sm">
                <span className="font-medium">
                  {user.firstName} {user.lastName}
                </span>{" "}
                <span className="text-muted-foreground">{EVENTS[index % EVENTS.length]}</span>
              </p>
              <p className="text-xs text-muted-foreground">{(index + 1) * 4} minutes ago</p>
            </div>
          </motion.li>
        ))}
      </ul>
    </section>
  );
});