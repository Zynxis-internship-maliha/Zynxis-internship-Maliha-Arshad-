import { Activity, Clock, Wifi, WifiOff } from "lucide-react";

import { cn } from "@/lib/utils";
import type { ApiMeta } from "@/types/user";

export type ApiHealth = "connected" | "slow" | "disconnected";

export function resolveHealth(meta: ApiMeta | undefined, isError: boolean): ApiHealth {
  if (isError || !meta) return "disconnected";
  return meta.durationMs > 800 ? "slow" : "connected";
}

const HEALTH_COPY: Record<ApiHealth, { label: string; dot: string; text: string }> = {
  connected: { label: "Connected", dot: "bg-success", text: "text-success" },
  slow: { label: "Slow response", dot: "bg-warning", text: "text-warning" },
  disconnected: { label: "Disconnected", dot: "bg-destructive", text: "text-destructive" },
};

export function ApiStatusWidget({
  meta,
  isError,
  compact = false,
}: {
  meta?: ApiMeta | undefined;
  isError: boolean;
  compact?: boolean;
}) {
  const health = resolveHealth(meta, isError);
  const copy = HEALTH_COPY[health];

  if (compact) {
    return (
      <span
        className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1.5 text-xs font-medium"
        role="status"
      >
        <span className={cn("size-2 rounded-full", copy.dot)} aria-hidden="true" />
        <span className={copy.text}>{copy.label}</span>
        {meta ? (
          <span className="text-muted-foreground tabular-nums">{meta.durationMs} ms</span>
        ) : null}
      </span>
    );
  }

  return (
    <section className="glass-panel p-5" aria-label="API status">
      <header className="flex items-center justify-between">
        <h3 className="text-sm font-semibold tracking-tight">API status</h3>
        <span className={cn("flex items-center gap-2 text-xs font-medium", copy.text)}>
          <span className={cn("size-2 rounded-full", copy.dot)} aria-hidden="true" />
          {copy.label}
        </span>
      </header>
      <dl className="mt-4 space-y-3 text-sm">
        <div className="flex items-center justify-between">
          <dt className="flex items-center gap-2 text-muted-foreground">
            <Clock className="size-4" aria-hidden="true" /> Response time
          </dt>
          <dd className="tabular-nums">{meta ? `${meta.durationMs} ms` : "—"}</dd>
        </div>
        <div className="flex items-center justify-between">
          <dt className="flex items-center gap-2 text-muted-foreground">
            <Activity className="size-4" aria-hidden="true" /> Status code
          </dt>
          <dd className="tabular-nums">{meta?.status ?? "—"}</dd>
        </div>
        <div className="flex items-center justify-between">
          <dt className="flex items-center gap-2 text-muted-foreground">
            {health === "disconnected" ? (
              <WifiOff className="size-4" aria-hidden="true" />
            ) : (
              <Wifi className="size-4" aria-hidden="true" />
            )}
            Last updated
          </dt>
          <dd>{meta ? new Date(meta.receivedAt).toLocaleTimeString() : "—"}</dd>
        </div>
      </dl>
    </section>
  );
}