import { Building2, Cake, Mail, MapPin, Phone, ShieldCheck } from "lucide-react";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { User } from "@/types/user";
import { initials } from "@/utils/analytics";

function DetailRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Mail;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-border/60 bg-muted/25 p-3">
      <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
        <Icon className="size-4" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="truncate text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}

export function UserDetailsModal({
  user,
  onOpenChange,
}: {
  user: User | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={Boolean(user)} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-xl">
        {user ? (
          <>
            <DialogHeader className="text-left">
              <div className="flex min-w-0 items-center gap-4">
                <Avatar className="size-16 shrink-0 border border-border">
                  <AvatarImage src={user.image} alt="" loading="lazy" />
                  <AvatarFallback>{initials(user.firstName, user.lastName)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <DialogTitle className="truncate text-xl">
                    {user.firstName} {user.lastName}
                  </DialogTitle>
                  <DialogDescription className="truncate">
                    {user.company.title} · {user.company.department}
                  </DialogDescription>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <Badge variant="secondary">{user.role}</Badge>
                    <Badge variant="outline">@{user.username}</Badge>
                  </div>
                </div>
              </div>
            </DialogHeader>

            <div className="grid gap-3 sm:grid-cols-2">
              <DetailRow icon={Mail} label="Email" value={user.email} />
              <DetailRow icon={Phone} label="Phone" value={user.phone} />
              <DetailRow icon={Building2} label="Company" value={user.company.name} />
              <DetailRow icon={Cake} label="Age" value={`${user.age} years`} />
              <DetailRow icon={ShieldCheck} label="Role" value={user.role} />
              <DetailRow
                icon={MapPin}
                label="Address"
                value={`${user.address.address}, ${user.address.city}, ${user.address.stateCode}`}
              />
            </div>

            <section className="rounded-xl border border-border/60 bg-muted/20 p-4">
              <h4 className="text-sm font-semibold">Bio</h4>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {user.firstName} is a {user.company.title.toLowerCase()} in the{" "}
                {user.company.department} team at {user.company.name}, based in {user.address.city},{" "}
                {user.address.country}. Account provisioned with {user.role} permissions.
              </p>
            </section>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}