import { memo } from "react";

import { cn } from "@/lib/utils";
import type { ApiMeta } from "@/types/user";

const ENDPOINTS = [
  "GET /users?limit=208",
  "GET /users/search",
  "GET /users/filter",
  "GET /users/1",
  "GET /health",
];

export const RecentApiCalls = memo(function RecentApiCalls({
  meta,
  isError,
}: {
  meta?: ApiMeta | undefined;
  isError: boolean;
}) {
  const base = meta?.durationMs ?? 0;

  return (
    <section className="glass-panel p-5" aria-label="Recent API calls">
      <h3 className="text-sm font-semibold tracking-tight">Recent API calls</h3>
      <ul className="mt-4 space-y-2.5">
        {ENDPOINTS.map((endpoint, index) => {
          const failed = isError && index === 0;
          const status = failed ? 503 : (meta?.status ?? 200);
          return (
            <li
              key={endpoint}
              className="flex items-center justify-between gap-3 rounded-lg border border-border/50 bg-muted/20 px-3 py-2"
            >
              <code className="min-w-0 truncate font-mono text-xs">{endpoint}</code>
              <span className="flex shrink-0 items-center gap-2 text-xs">
                <span className="text-muted-foreground tabular-nums">
                  {Math.max(24, base + index * 17)} ms
                </span>
                <span
                  className={cn(
                    "rounded-md px-1.5 py-0.5 font-medium tabular-nums",
                    failed ? "bg-destructive/12 text-destructive" : "bg-success/12 text-success",
                  )}
                >
                  {status}
                </span>
              </span>
            </li>
          );
        })}
      </ul>
    </section>
  );
});