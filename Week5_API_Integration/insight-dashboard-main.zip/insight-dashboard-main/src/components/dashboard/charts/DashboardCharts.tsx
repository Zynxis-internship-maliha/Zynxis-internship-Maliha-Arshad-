import { memo, useMemo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { ChartCard } from "./ChartCard";
import type { User } from "@/types/user";
import {
  registrationDistribution,
  usersByCity,
  usersByCompany,
  usersByGender,
} from "@/utils/analytics";

const AXIS = {
  stroke: "var(--muted-foreground)",
  fontSize: 11,
  tickLine: false,
  axisLine: false,
} as const;

const PIE_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)"];

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ value?: number | string; name?: string }>;
  label?: string | number;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-panel px-3 py-2 text-xs">
      <p className="font-medium">{label ?? payload[0]?.name}</p>
      <p className="text-muted-foreground">{payload[0]?.value} users</p>
    </div>
  );
}

export const DashboardCharts = memo(function DashboardCharts({ users }: { users: User[] }) {
  const byCompany = useMemo(() => usersByCompany(users), [users]);
  const byCity = useMemo(() => usersByCity(users), [users]);
  const byDecade = useMemo(() => registrationDistribution(users), [users]);
  const byGender = useMemo(() => usersByGender(users), [users]);

  return (
    <div className="grid gap-5 xl:grid-cols-2">
      <ChartCard title="Users by company" description="Top employers across the dataset" index={0}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={byCompany} margin={{ left: -20, right: 8, top: 8 }}>
            <XAxis dataKey="name" {...AXIS} interval={0} angle={-18} textAnchor="end" height={54} />
            <YAxis {...AXIS} allowDecimals={false} />
            <Tooltip cursor={{ fill: "var(--muted)", opacity: 0.4 }} content={<ChartTooltip />} />
            <Bar dataKey="value" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Users by city" description="Highest density locations" index={1}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={byCity} layout="vertical" margin={{ left: 24, right: 12 }}>
            <XAxis type="number" {...AXIS} allowDecimals={false} />
            <YAxis type="category" dataKey="name" width={92} {...AXIS} />
            <Tooltip cursor={{ fill: "var(--muted)", opacity: 0.4 }} content={<ChartTooltip />} />
            <Bar dataKey="value" fill="var(--chart-2)" radius={[0, 6, 6, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard
        title="Registration distribution"
        description="Accounts grouped by birth decade"
        index={2}
      >
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={byDecade} margin={{ left: -20, right: 8, top: 8 }}>
            <defs>
              <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.55} />
                <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <XAxis dataKey="name" {...AXIS} />
            <YAxis {...AXIS} allowDecimals={false} />
            <Tooltip content={<ChartTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke="var(--chart-3)"
              strokeWidth={2}
              fill="url(#areaFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Gender distribution" description="Split across all accounts" index={3}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={byGender}
              dataKey="value"
              nameKey="name"
              innerRadius={62}
              outerRadius={94}
              paddingAngle={3}
              stroke="none"
            >
              {byGender.map((entry, i) => (
                <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
});