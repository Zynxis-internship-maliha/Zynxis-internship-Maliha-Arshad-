import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function ChartCard({
  title,
  description,
  children,
  index = 0,
}: {
  title: string;
  description: string;
  children: ReactNode;
  index?: number;
}) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: index * 0.06, ease: [0.22, 1, 0.36, 1] }}
      className="glass-panel p-5"
      aria-label={title}
    >
      <header className="mb-4">
        <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
        <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>
      </header>
      <div className="h-64 w-full">{children}</div>
    </motion.section>
  );
}