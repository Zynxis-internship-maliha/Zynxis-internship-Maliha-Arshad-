import { motion } from "framer-motion";
import { RefreshCw, SearchX } from "lucide-react";

import { Button } from "@/components/ui/button";

export function EmptyState({
  onReset,
  onRefresh,
  title = "No users found.",
  description = "Try adjusting your search or filters.",
}: {
  onReset: () => void;
  onRefresh: () => void;
  title?: string;
  description?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center justify-center px-6 py-16 text-center"
      role="status"
    >
      <div
        className="relative grid size-24 place-items-center rounded-3xl bg-primary/8"
        aria-hidden="true"
      >
        <div className="absolute inset-0 rounded-3xl bg-[var(--gradient-accent)] opacity-15 blur-xl" />
        <SearchX className="relative size-10 text-primary" />
      </div>
      <h3 className="mt-6 text-base font-semibold tracking-tight">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        <Button variant="secondary" onClick={onReset}>
          Reset filters
        </Button>
        <Button variant="outline" onClick={onRefresh}>
          <RefreshCw className="size-4" aria-hidden="true" />
          Refresh
        </Button>
      </div>
    </motion.div>
  );
}