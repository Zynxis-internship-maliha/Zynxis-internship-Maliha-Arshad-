import { Link, useRouterState } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  BarChart3,
  FileText,
  LayoutDashboard,
  LifeBuoy,
  PanelLeftClose,
  PanelLeftOpen,
  Settings,
  Signal,
  Users,
} from "lucide-react";

import { cn } from "@/lib/utils";

export const NAV_ITEMS = [
  { label: "Dashboard", to: "/", icon: LayoutDashboard },
  { label: "Users", to: "/users", icon: Users },
  { label: "Analytics", to: "/analytics", icon: BarChart3 },
  { label: "Reports", to: "/reports", icon: FileText },
  { label: "Settings", to: "/settings", icon: Settings },
  { label: "API Status", to: "/api-status", icon: Signal },
  { label: "Help", to: "/help", icon: LifeBuoy },
] as const;

export function Sidebar({
  collapsed,
  onToggle,
  onNavigate,
}: {
  collapsed: boolean;
  onToggle: () => void;
  onNavigate?: () => void;
}) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <nav
      aria-label="Primary"
      className="flex h-full flex-col border-r border-border/60 bg-sidebar/70 backdrop-blur-xl"
    >
      <div className="flex h-16 items-center gap-2 px-4">
        <span
          className="grid size-9 shrink-0 place-items-center rounded-xl bg-[var(--gradient-accent)] text-sm font-bold text-primary-foreground"
          aria-hidden="true"
        >
          N
        </span>
        {!collapsed && (
          <span className="min-w-0 truncate text-sm font-semibold tracking-tight">
            Nexus Analytics
          </span>
        )}
      </div>

      <ul className="flex-1 space-y-1 px-3 py-2">
        {NAV_ITEMS.map((item) => {
          const active = pathname === item.to;
          return (
            <li key={item.to}>
              <Link
                to={item.to}
                onClick={onNavigate}
                aria-current={active ? "page" : undefined}
                title={collapsed ? item.label : undefined}
                className={cn(
                  "relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all duration-200",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="sidebar-active"
                    className="absolute top-1/2 left-0 h-6 w-1 -translate-y-1/2 rounded-r-full bg-primary"
                    aria-hidden="true"
                  />
                )}
                <item.icon className="size-4 shrink-0" aria-hidden="true" />
                {!collapsed && <span className="min-w-0 truncate">{item.label}</span>}
              </Link>
            </li>
          );
        })}
      </ul>

      <div className="border-t border-border/60 p-3">
        <button
          type="button"
          onClick={onToggle}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
        >
          {collapsed ? (
            <PanelLeftOpen className="size-4 shrink-0" aria-hidden="true" />
          ) : (
            <PanelLeftClose className="size-4 shrink-0" aria-hidden="true" />
          )}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </nav>
  );
}