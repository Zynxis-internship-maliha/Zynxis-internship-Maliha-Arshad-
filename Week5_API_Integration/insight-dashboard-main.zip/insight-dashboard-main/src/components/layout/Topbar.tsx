import { Bell, Menu, Moon, Search, Sun } from "lucide-react";
import { useCallback, useEffect, useState } from "react";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Topbar({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  const [light, setLight] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
  }, [light]);

  const toggleTheme = useCallback(() => setLight((value) => !value), []);

  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="grid h-16 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-4 lg:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={onOpenSidebar}
            aria-label="Open navigation"
          >
            <Menu className="size-5" aria-hidden="true" />
          </Button>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold tracking-tight">Nexus Analytics</p>
            <p className="hidden truncate text-xs text-muted-foreground sm:block">
              Modern API Integration Dashboard
            </p>
          </div>
        </div>

        <div className="relative hidden min-w-0 md:block">
          <Search
            className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            placeholder="Search the workspace"
            aria-label="Global search"
            className="h-10 pl-9"
          />
        </div>
        <div className="md:hidden" />

        <div className="flex items-center gap-1.5">
          <Button variant="ghost" size="icon" aria-label="Notifications" className="relative">
            <Bell className="size-5" aria-hidden="true" />
            <span
              className="absolute top-2 right-2 size-2 rounded-full bg-primary"
              aria-hidden="true"
            />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label={light ? "Switch to dark theme" : "Switch to light theme"}
          >
            {light ? (
              <Moon className="size-5" aria-hidden="true" />
            ) : (
              <Sun className="size-5" aria-hidden="true" />
            )}
          </Button>
          <Avatar className="size-9 border border-border">
            <AvatarImage src="https://dummyjson.com/icon/emilys/128" alt="Your profile" />
            <AvatarFallback>EA</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}