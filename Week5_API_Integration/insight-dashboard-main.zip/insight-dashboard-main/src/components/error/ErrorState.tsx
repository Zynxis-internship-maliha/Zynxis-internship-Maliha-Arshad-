import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AlertTriangle, ArrowLeft, RefreshCw, RotateCw } from "lucide-react";

import { Button } from "@/components/ui/button";
import { ApiError } from "@/services/api";

export function ErrorState({
  error,
  onRetry,
  showHomeLink = true,
}: {
  error: unknown;
  onRetry: () => void;
  showHomeLink?: boolean;
}) {
  const apiError = error instanceof ApiError ? error : null;
  const title = apiError?.message ?? "Something went wrong while loading data.";
  const hint = apiError?.hint ?? "Please retry, or refresh the page.";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="glass-panel mx-auto flex max-w-lg flex-col items-center px-6 py-12 text-center"
      role="alert"
    >
      <div
        className="relative grid size-24 place-items-center rounded-3xl bg-destructive/10"
        aria-hidden="true"
      >
        <div className="absolute inset-0 rounded-3xl bg-destructive/20 blur-xl" />
        <AlertTriangle className="relative size-10 text-destructive" />
      </div>
      <p className="mt-6 text-xs font-medium tracking-widest text-destructive uppercase">
        {apiError?.status ? `Error ${apiError.status}` : (apiError?.kind ?? "error")}
      </p>
      <h3 className="mt-2 text-lg font-semibold tracking-tight">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{hint}</p>
      <p className="mt-3 text-xs text-muted-foreground">
        We already retried this request 3 times automatically.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        <Button onClick={onRetry}>
          <RotateCw className="size-4" aria-hidden="true" />
          Retry
        </Button>
        <Button variant="outline" onClick={() => window.location.reload()}>
          <RefreshCw className="size-4" aria-hidden="true" />
          Refresh page
        </Button>
        {showHomeLink ? (
          <Button variant="ghost" asChild>
            <Link to="/">
              <ArrowLeft className="size-4" aria-hidden="true" />
              Back to dashboard
            </Link>
          </Button>
        ) : null}
      </div>
    </motion.div>
  );
}