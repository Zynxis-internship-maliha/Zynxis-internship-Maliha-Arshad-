function Block({ className = "" }: { className?: string }) {
  return <div className={`shimmer rounded-lg bg-muted/60 ${className}`} />;
}

export function StatCardsSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="glass-panel p-5">
          <div className="flex items-start justify-between">
            <Block className="h-4 w-24" />
            <Block className="size-9 rounded-xl" />
          </div>
          <Block className="mt-5 h-8 w-28" />
          <Block className="mt-2 h-3 w-20" />
        </div>
      ))}
    </div>
  );
}

export function ChartsSkeleton() {
  return (
    <div className="grid gap-5 xl:grid-cols-2">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="glass-panel p-5">
          <Block className="h-4 w-40" />
          <Block className="mt-2 h-3 w-56" />
          <Block className="mt-5 h-56 w-full rounded-xl" />
        </div>
      ))}
    </div>
  );
}

export function TableSkeleton({ rows = 8 }: { rows?: number }) {
  return (
    <div className="glass-panel overflow-hidden p-5">
      <div className="flex flex-wrap items-center gap-3">
        <Block className="h-9 w-56" />
        <Block className="h-9 w-36" />
        <Block className="h-9 w-36" />
      </div>
      <div className="mt-5 space-y-3">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="grid grid-cols-[auto_1fr_1fr] items-center gap-4">
            <Block className="size-10 rounded-full" />
            <div className="space-y-2">
              <Block className="h-3.5 w-40" />
              <Block className="h-3 w-28" />
            </div>
            <Block className="h-3.5 w-full max-w-64 justify-self-end" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function ActivitySkeleton() {
  return (
    <div className="glass-panel space-y-4 p-5">
      <Block className="h-4 w-32" />
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3">
          <Block className="size-8 rounded-full" />
          <div className="flex-1 space-y-2">
            <Block className="h-3 w-3/4" />
            <Block className="h-2.5 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
      <StatCardsSkeleton />
      <ChartsSkeleton />
      <TableSkeleton />
    </div>
  );
}