export interface UserAddress {
  address: string;
  city: string;
  state: string;
  stateCode: string;
  postalCode: string;
  country: string;
}

export interface UserCompany {
  name: string;
  department: string;
  title: string;
  address: UserAddress;
}

export interface User {
  id: number;
  firstName: string;
  lastName: string;
  maidenName?: string;
  age: number;
  gender: string;
  email: string;
  phone: string;
  username: string;
  birthDate: string;
  image: string;
  bloodGroup?: string;
  height?: number;
  weight?: number;
  eyeColor?: string;
  university?: string;
  role: string;
  address: UserAddress;
  company: UserCompany;
}

export interface UsersResponse {
  users: User[];
  total: number;
  skip: number;
  limit: number;
}

export interface ApiMeta {
  /** Round-trip latency in milliseconds. */
  durationMs: number;
  status: number;
  receivedAt: number;
}

export interface UsersResult {
  users: User[];
  total: number;
  meta: ApiMeta;
}