# Insight Dashboard

Below is a senior-level Lovable prompt written as if by an experienced AI Product Designer and Prompt Engineer. It is designed to produce a production-ready, portfolio-quality project that fully satisfies your Week 5: API Consumption & Handling internship requirements while following modern UI/UX, clean architecture, and best React practices.

🚀 PRO-LEVEL LOVABLE PROMPT

Role

You are a Senior Frontend Engineer, Senior UI/UX Designer, and Product Designer with 15+ years of experience building enterprise SaaS dashboards.

Your task is to build a production-ready API Dashboard that demonstrates professional frontend engineering, exceptional UI/UX, clean architecture, accessibility, responsive design, and robust API handling.

This project must look like a premium product from companies such as Stripe, Linear, Vercel, Notion, Clerk, or Framer—not a beginner CRUD application.

Project Name

Nexus Analytics Dashboard

Tagline:

Modern API Integration Dashboard

Objective

Create a modern dashboard that consumes data from a REST API while handling every possible application state professionally.

The project must satisfy the following internship requirements:

Fetch data from a REST API

Loading Skeletons

Empty States

Error Handling

Live Data Dashboard

Error Logic Documentation

Build the project as if it were going into production.

Tech Stack

Use

React 19

Vite

TypeScript

Tailwind CSS

shadcn/ui

React Router

Axios

TanStack Query (React Query)

Framer Motion

Lucide Icons

Sonner Toast

Recharts

ESLint

Prettier

Design Language

Create a premium modern dashboard.

Design inspiration:

Stripe Dashboard

Vercel

Linear

Notion

Clerk

Raycast

Style

Dark Theme

Primary Background

Deep Charcoal (#0B0F19)

Surface

#131A27

Cards

Glassmorphism with subtle blur

Border

rgba(255,255,255,.06)

Accent Color

Electric Blue

Secondary Accent

Purple

Success

Emerald

Warning

Amber

Error

Rose Red

Radius

20px

Shadow

Very soft layered shadows

Spacing

Generous whitespace

Typography

Inter

Animations

Very smooth

Professional

Minimal

Elegant

Application Layout

Top Navigation

Contains

Logo

Dashboard Title

Search

Notifications

Theme Toggle

Profile Avatar

Left Sidebar

Animated collapse

Menu Items

Dashboard

Users

Analytics

Reports

Settings

API Status

Help

Active item indicator

Beautiful hover animations

Main Content

Dashboard Overview

Statistics

Charts

User Table

Activity Feed

Recent API Calls

Dashboard Cards

Display

Total Users

Active Users

Companies

Countries

API Response Time

Success Rate

Each card must

Animate on load

Hover effect

Small icon

Gradient border

Live numbers

Charts

Use Recharts

Create

Users by Company

Users by City

Registration Distribution

Gender Distribution

Animated charts

Beautiful tooltips

Responsive

REST API

Use

https://dummyjson.com/users

Fetch

Users

Company

Email

Phone

Address

Image

Age

Role

API Layer

Create

services/api.ts

Create reusable API client

Axios Instance

Base URL

Timeout

Headers

Request Interceptor

Response Interceptor

Centralized error handling

React Query

Use TanStack Query

Implement

Caching

Refetch

Retry

Stale Time

Loading

Error

Success

User Table

Professional Data Table

Features

Search

Filter

Sort

Pagination

Responsive

Sticky Header

Avatar

Company Badge

Status Badge

Hover Animation

Row Selection

Click Row

Open User Details Modal

User Details Modal

Display

Avatar

Full Name

Email

Phone

Company

Address

Age

Role

Bio Section

Animated Opening

Backdrop Blur

Close Animation

Search

Instant Search

Debounce

Search by

Name

Email

Company

Phone

Filters

Company

Age

Gender

City

Sort

Ascending

Descending

Loading State

DO NOT use text saying

Loading...

Instead create

Professional Skeleton UI

Skeleton Navbar

Skeleton Cards

Skeleton Table

Skeleton Charts

Smooth shimmer animation

Looks identical to final layout

Empty State

If no results found

Display beautiful illustration

Message

"No users found."

Description

Try adjusting your search or filters.

Buttons

Reset Filters

Refresh

Error Handling

Handle every scenario

No Internet

Server Error

404

500

Timeout

Invalid Response

API Limit

Show

Beautiful Error Card

Illustration

Friendly Message

Retry Button

Refresh Button

Back to Dashboard

Retry Logic

Retry automatically

3 times

If still fails

Show error page

Retry button

Toast notification

Toast Notifications

Show professional toasts

Success

Data Loaded Successfully

Error

Unable to fetch data

Warning

Connection Lost

Info

Refreshing Data

API Status Widget

Small widget

Green

Connected

Yellow

Slow Response

Red

Disconnected

Display

Response Time

Status Code

Last Updated

Performance

Optimize

Lazy Loading

Code Splitting

Memoization

React.memo

useMemo

useCallback

Image Lazy Loading

Dynamic Imports

Accessibility

Keyboard Navigation

ARIA Labels

Focus States

Screen Reader Support

High Contrast

Semantic HTML

Responsive Design

Perfect on

320px

480px

768px

1024px

1440px

1920px

No horizontal scrolling

Micro Interactions

Hover Animations

Button Ripple

Card Lift

Smooth Page Transition

Animated Sidebar

Animated Charts

Fade Sections

Floating Action Button

Folder Structure

src/

app/

components/

layout/

dashboard/

cards/

charts/

table/

modals/

common/

skeleton/

empty/

error/

hooks/

services/

api/

types/

utils/

assets/

pages/

routes/



Code Quality

Use

Reusable Components

SOLID Principles

DRY

Clean Architecture

Type Safety

No duplicated code

Meaningful names

Professional comments only where needed

Deliverables

Generate

Complete React Project

Responsive UI

Professional Dashboard

Working API Integration

Charts

Search

Filters

Pagination

Loading Skeletons

Empty State

Error State

Retry Logic

Dark Theme

Animations

Reusable Components

Production-ready Folder Structure

TypeScript Types

Professional README

Error Logic Documentation

Installation Guide

Deployment Ready

Final Goal

The finished application must look like a real enterprise SaaS dashboard suitable for a professional portfolio. Every screen, interaction, loading state, error state, and animation should feel polished and intentional. The codebase should reflect senior frontend engineering practices, emphasizing clean architecture, scalability, performance, accessibility, and maintainability while fully satisfying the Week 5 internship deliverable: Live Data Dashboard + Error Logic Note.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/9c69ef0f-7cf1-4358-b773-8908ec69c228).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
